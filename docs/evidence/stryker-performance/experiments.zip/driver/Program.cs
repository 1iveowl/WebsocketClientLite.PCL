using Pdd;
using System.Text.Json.Nodes;
using System.Diagnostics;
using System.Runtime.InteropServices;
var root = "/tmp/ws-stryker-performance";
var output = Path.GetFullPath(args[0]);
var extra = args.Skip(1).ToArray();
using var cancel = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) => { e.Cancel = true; cancel.Cancel(); };
using var term = PosixSignalRegistration.Create(PosixSignal.SIGTERM, c => { c.Cancel = true; cancel.Cancel(); });
var e = new Evidence(root);
var source = await e.Identity();
Data.Require(!source.DirtyWorktree, "Benchmark requires a clean worktree");
var commands = Evidence.Commands("stryker", output);
commands[1] = ("stryker", ["./scripts/stryker-close.sh", .. extra]);
var started = Data.Now();
var code = await e.Capture("stryker", output, 1800, cancel.Token, commands);
var trial = new JsonObject { ["source"] = Data.Node(source), ["arguments"] = Data.Node(extra), ["started_at"] = started, ["finished_at"] = Data.Now(), ["exit_code"] = code, ["status"] = "failed", ["processor_count"] = Environment.ProcessorCount };
try
{
    Data.Require(code == 0, "Capture did not complete successfully");
    var reports = Directory.GetFiles(Path.Combine(output, "reports"), "mutation-report.json", SearchOption.AllDirectories);
    Data.Require(reports.Length == 1, "Missing/ambiguous mutation report");
    var raw = Data.Read(reports[0]);
    var result = Evidence.TriageStryker(raw, Data.Read(Path.Combine(root, "verification/stryker-close-dispositions.json")), source.SourceHashes[Evidence.CloseSource]!);
    Data.Require(result["counts"]!["Timeout"]!.GetValue<int>() == 0, "Timeout is not acceptable for a performance candidate");
    trial["triage"] = result;
    var baseline = Data.Read("/tmp/ws-p3-e/artifacts/acceptance/stryker/reports/reports/mutation-report.json");
    JsonObject Outcomes(JsonNode report)
    {
        var file = report["files"]!.AsObject().Single(p => p.Key.Replace('\\', '/').EndsWith("Service/WebsocketConnectionHandler.cs"));
        var outcomes = new JsonObject();
        foreach (var m in file.Value!["mutants"]!.AsArray()) outcomes[Evidence.MutantKey(m!)] = m!["status"]!.DeepClone();
        return outcomes;
    }
    var expected = Outcomes(baseline); var actual = Outcomes(raw);
    trial["identical_outcomes"] = JsonNode.DeepEquals(expected, actual);
    var differences = new JsonArray();
    foreach (var item in expected)
    {
        if (JsonNode.DeepEquals(item.Value, actual[item.Key])) continue;
        differences.Add(new JsonObject { ["fingerprint"] = item.Key, ["baseline"] = item.Value!.DeepClone(), ["actual"] = actual[item.Key]?.DeepClone() });
        Data.Require(item.Key == "b0b3581ae9b5edc715f27733b23dd0b219cd949f7a59407630aaf6c7d39c864a" && item.Value!.GetValue<string>() == "Killed" && actual[item.Key]?.GetValue<string>() == "Survived", "Non-allowlisted fingerprint outcome changed");
    }
    Data.Require(expected.Count == actual.Count, "Fingerprint count changed");
    trial["outcome_differences"] = differences;
    trial["comparison_policy"] = "All fingerprints exact except pre-existing out-of-scope handshake throw Killed/Survived variability; critical gate unchanged";
    var job = Data.Read(Path.Combine(output, "job.json"));
    Data.Require(JsonNode.DeepEquals(job["source"], job["source_after"]), "Source changed during trial");
    trial["elapsed_seconds"] = Data.Read(Path.Combine(output, "commands/stryker/execution.json"))["elapsed_seconds"]!.DeepClone();
    trial["status"] = "passed";
}
catch (Exception error) { trial["reason"] = error.Message; code = 1; }
Data.Save(Path.Combine(output, "trial.json"), trial);
Console.WriteLine(trial.ToJsonString());
return code;

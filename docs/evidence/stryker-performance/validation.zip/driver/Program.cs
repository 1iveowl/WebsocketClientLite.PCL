using Pdd;
var root = "/tmp/ws-stryker-performance";
var output = Path.Combine(root, "artifacts/validation-clean/tests");
var e = new Evidence(root);
Data.Require(!(await e.Identity()).DirtyWorktree, "Requires clean source");
var commands = Evidence.Commands("tests", output);
commands[2] = ("matrix", ["bash", "/tmp/stryker-clean-matrix.sh"]);
return await e.Capture("tests", output, 1800, default, commands);

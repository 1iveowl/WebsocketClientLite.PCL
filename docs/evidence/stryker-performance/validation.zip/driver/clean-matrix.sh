#!/usr/bin/env bash
set -euo pipefail
for tfm in netstandard2.0 netstandard2.1 net8.0 net9.0 net10.0; do
  # Only the experiment's test-project outputs; prevent equal-size/mtime DLL reuse.
  rm -rf /tmp/ws-stryker-performance/src/main/WebsocketClientLiteTest/bin /tmp/ws-stryker-performance/src/main/WebsocketClientLiteTest/obj
  PDD_TEST_CONFIG=Release ./scripts/pdd.sh test-target --tfm "$tfm" --output "$PDD_TEST_RESULTS/$tfm"
done

import pathlib,json
root=pathlib.Path('/tmp/ws-stryker-performance')
a=json.load(open(root/'artifacts/implementation/stryker/reports/reports/mutation-report.json'))
b=json.load(open('/tmp/ws-p3-e/artifacts/acceptance/stryker/reports/reports/mutation-report.json'))
def selected(r):
 return next(f['mutants'] for p,f in r['files'].items() if p.replace('\\','/').endswith('Service/WebsocketConnectionHandler.cs'))
def key(m):return json.dumps([m['mutatorName'],m['replacement'],m['location']],sort_keys=True)
expected={key(m):m for m in selected(b)};actual={key(m):m for m in selected(a)}
assert expected.keys()==actual.keys()
diffs=[]
for k,m in actual.items():
 old=expected[k]
 assert m['status']!='Timeout'
 if m['status']!=old['status']:
  diffs.append({'id':m['id'],'location':m['location'],'baseline':old['status'],'actual':m['status']})
  assert m['location']['start']['line']==95 and m['replacement']==';' and old['status']=='Killed' and m['status']=='Survived'
r={'status':'passed','selected_count':len(actual),'identical_outcomes':not diffs,'differences':diffs,'zero_timeouts':True}
(root/'artifacts/implementation/comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(r)

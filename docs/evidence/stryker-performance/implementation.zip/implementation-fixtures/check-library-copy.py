import pathlib,subprocess,shutil,os,hashlib,json
root=pathlib.Path.cwd();project='src/main/WebsocketClientLiteTest/WebsocketClientLiteTest.csproj'
command=['dotnet','build',project,'-c','Release','-p:LibTfm=netstandard2.1','--nologo']
wrong=root/'src/main/WebsocketClientLite/bin/Release/netstandard2.0/WebsocketClientLite.dll'
correct=root/'src/main/WebsocketClientLite/bin/Release/netstandard2.1/WebsocketClientLite.dll'
dest=root/'src/main/WebsocketClientLiteTest/bin/Release/net10.0/WebsocketClientLite.dll'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert wrong.stat().st_size==correct.stat().st_size
assert sha(wrong)!=sha(correct)
shutil.copyfile(wrong,dest);os.utime(dest,ns=(correct.stat().st_atime_ns,correct.stat().st_mtime_ns))
before={'size_equal':dest.stat().st_size==correct.stat().st_size,'mtime_equal':dest.stat().st_mtime_ns==correct.stat().st_mtime_ns,'wrong_sha256':sha(dest),'expected_sha256':sha(correct)}
with open('artifacts/implementation-fixtures/build.log','w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
assert sha(dest)==sha(correct)
pathlib.Path('artifacts/implementation-fixtures/result.json').write_text(json.dumps({'before':before,'command':command,'after_sha256':sha(dest),'status':'passed'},indent=2)+'\n')
print('Equal-size/equal-timestamp wrong DLL replaced with resolved library: passed')

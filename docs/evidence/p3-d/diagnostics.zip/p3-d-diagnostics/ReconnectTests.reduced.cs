using System;
using System.Collections.Concurrent;
using System.Reflection;
using System.Threading;
using WebsocketClientLite.Service;
using System.Reactive.Linq;
using System.Threading.Tasks;
using IWebsocketClientLite;
using WebsocketClientLite;
using Xunit;

namespace WebsocketClientLiteTest;

public class ReconnectTests
{
    private static readonly TimeSpan Limit = TimeSpan.FromSeconds(15);

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task DisposedClientRejectsAdmission(bool asynchronous)
    {
        using var server = new LoopbackWebSocketServer();
        server.Start(LoopbackWebSocketServer.EchoLoopAsync);
        var client = new ClientWebSocketRx();
        if (asynchronous) await client.DisposeAsync(); else client.Dispose();
        var terminal = new TaskCompletionSource<Exception?>(TaskCreationOptions.RunContinuationsAsynchronously);
        using var subscription = client.WebsocketConnectWithStatusObservable(server.Uri).Subscribe(
            value => { if (value.state == ConnectionStatus.WebsocketConnected) terminal.TrySetResult(null); },
            error => terminal.TrySetResult(error));
        Assert.True(await terminal.Task.WaitAsync(Limit) is ObjectDisposedException,
            "Disposed client admitted a connection");
    }

    private static ConcurrentDictionary<WebsocketService, byte> Active(ClientWebSocketRx client) =>
        (ConcurrentDictionary<WebsocketService, byte>)typeof(ClientWebSocketRx)
            .GetField("_activeConnections", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(client)!;

    [Fact]
    public async Task TerminalCallbackSuccessorSurvivesOldCleanup()
    {
        using var first = new LoopbackWebSocketServer();
        using var second = new LoopbackWebSocketServer();
        var endFirst = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        first.Start(async (stream, ct) =>
        {
            await endFirst.Task.WaitAsync(ct);
            await LoopbackWebSocketServer.WriteFrameAsync(stream, 8, new byte[] { 3, 232 }, true, ct);
            await LoopbackWebSocketServer.ReadFrameAsync(stream, ct);
        });
        second.Start(LoopbackWebSocketServer.EchoLoopAsync);
        using var client = new ClientWebSocketRx();
        var firstReady = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var secondReady = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var oldTerminalReturned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var echo = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        bool connected = false;
        using var status = client.IsConnectedObservable.Subscribe(value => Volatile.Write(ref connected, value));
        IDisposable? successor = null;
        using var initial = client.WebsocketConnectWithStatusObservable(first.Uri).Subscribe(
            value => { if (value.state == ConnectionStatus.WebsocketConnected) firstReady.TrySetResult(); },
            ex => oldTerminalReturned.TrySetException(ex),
            () =>
            {
                successor = client.WebsocketConnectWithStatusObservable(second.Uri).Subscribe(value =>
                {
                    if (value.state == ConnectionStatus.WebsocketConnected) secondReady.TrySetResult();
                    if (value.state == ConnectionStatus.DataframeReceived) echo.TrySetResult();
                }, ex => echo.TrySetException(ex));
                // Hold the old terminal callback until the successor handshake finishes.
                if (!secondReady.Task.Wait(Limit)) oldTerminalReturned.TrySetException(new TimeoutException());
                else oldTerminalReturned.TrySetResult();
            });
        try
        {
            await firstReady.Task.WaitAsync(Limit);
            var oldSender = client.Sender!;
            var oldService = Assert.Single(Active(client)).Key;
            endFirst.TrySetResult();
            await oldTerminalReturned.Task.WaitAsync(Limit);
            // Dispose the old subscription explicitly to join its Finally cleanup.
            initial.Dispose();
            var close = (Lazy<Task>)typeof(WebsocketConnectionHandler).GetField("_closeHandshakeOnce", BindingFlags.Instance | BindingFlags.NonPublic)!
                .GetValue(oldService.WebsocketConnectionHandler)!;
            await close.Value.WaitAsync(Limit);
            Assert.DoesNotContain(oldService, Active(client).Keys);
            Assert.Single(Active(client));
            Assert.NotSame(oldSender, client.Sender);
            Assert.True(Volatile.Read(ref connected), "Old cleanup reset successor connectivity");
            await Assert.ThrowsAnyAsync<Exception>(() => oldSender.SendText("old"));
            await client.Sender!.SendText("new");
            await echo.Task.WaitAsync(Limit);
        }
        finally { successor?.Dispose(); }
        Assert.Empty(Active(client));
    }
}

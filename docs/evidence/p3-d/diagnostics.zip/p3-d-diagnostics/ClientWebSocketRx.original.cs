﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net.Security;
using System.Reactive;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Sockets;
using WebsocketClientLite.Factory;
using IWebsocketClientLite;
using WebsocketClientLite.Service;

namespace WebsocketClientLite;

public class ClientWebSocketRx : IWebSocketClientRx, IDisposable, IAsyncDisposable
{
    private readonly CompositeDisposable _disposables = [];
    private readonly IObserver<bool> _observerIsConnected;

    // Connections created by active subscriptions. Tracked so DisposeAsync can
    // give each one a graceful, awaited close handshake (and Dispose an abrupt
    // bounded one). Entries remove themselves on normal teardown (the Finally
    // around each connection).
    private readonly ConcurrentDictionary<WebsocketService, byte> _activeConnections = new();

    public bool HasTransferSocketLifeCycleOwnership { get; init; }

    /// <summary>
    /// Default value for <see cref="MaxFrameSize"/> (16 MiB).
    /// </summary>
    public const int DefaultMaxFrameSizeBytes = 16 * 1024 * 1024;

    /// <summary>
    /// Maximum payload size, in bytes, accepted for a single incoming frame and
    /// for a fully reassembled (fragmented) message. Frames or messages exceeding
    /// this are rejected and the connection is torn down, preventing
    /// memory-exhaustion from a malicious or misbehaving server. Defaults to
    /// <see cref="DefaultMaxFrameSizeBytes"/>. Set to 0 (or a negative value) to
    /// allow up to <see cref="int.MaxValue"/> bytes.
    /// </summary>
    public int MaxFrameSize { get; init; } = DefaultMaxFrameSizeBytes;

    /// <summary>
    /// Optional TCP client. When left null (recommended), a <see cref="TcpClient"/>
    /// is created internally with the address family matching the target URI and is
    /// disposed together with the connection.
    /// <para>
    /// Important: a supplied client can only serve the FIRST connection. Its socket
    /// is closed when the connection tears down and .NET sockets cannot be
    /// reconnected, so reconnect patterns (e.g. <c>Retry()</c>/<c>Repeat()</c>)
    /// require leaving this null so each attempt gets a fresh socket.
    /// </para>
    /// </summary>
    public TcpClient? TcpClient { get; init; }

    /// <summary>
    /// Websocket client connected observable.
    /// </summary>
    public IObservable<bool> IsConnectedObservable { get; }

    /// <summary>
    /// Get websocket client sender.
    /// </summary>
    /// <returns></returns>
    public ISender? Sender { get; private set; }

    /// <summary>
    /// Websocket client connected event.
    /// </summary>
    public string? Origin { get; init; }

    /// <summary>
    /// Http Headers
    /// </summary>
    public IDictionary<string, string>? Headers { get; init; }

    /// <summary>
    /// Websocket known subprotocols
    /// </summary>
    public IEnumerable<string>? Subprotocols { get; init; }

    /// <summary>
    /// The subprotocols the server accepted during the most recent successful
    /// handshake (the intersection with <see cref="Subprotocols"/>), or
    /// <see langword="null"/> when none were negotiated or no connection has
    /// been established yet.
    /// </summary>
    public IEnumerable<string>? NegotiatedSubprotocols { get; private set; }

    /// <summary>
    /// TLS protocol
    /// </summary>
    public SslProtocols TlsProtocolType { get; init; } = SslProtocols.None;

    /// <summary>
    /// Typically used with Slack. See documentation.
    /// </summary>
    public bool ExcludeZeroApplicationDataInPong { get; init; }

    /// <summary>
    /// Use with care. Ignores TLS/SSL certificate checks and errors. See documentation.
    /// </summary>
    public bool IgnoreServerCertificateErrors { get; init; }

    /// <summary>
    /// Whether to check the server certificate for revocation during the TLS
    /// handshake. Defaults to <see langword="true"/>. Set to <see langword="false"/>
    /// if your environment cannot reach the certificate's revocation (OCSP/CRL)
    /// endpoints, which would otherwise fail the handshake. Has no effect when
    /// <see cref="IgnoreServerCertificateErrors"/> is <see langword="true"/>.
    /// </summary>
    public bool CheckCertificateRevocation { get; init; } = true;

    /// <summary>
    /// X.509 certificate collection.
    /// </summary>
    public X509CertificateCollection? X509CertCollection { get; init; }

    /// <summary>
    /// Default constructor.
    /// </summary>
    public ClientWebSocketRx()
    {
        BehaviorSubject<bool> connectedBehavior = new(false);
        _observerIsConnected = connectedBehavior.AsObserver();

        IsConnectedObservable = connectedBehavior.AsObservable();

        // Register the BehaviorSubject with the disposer
        _disposables.Add(connectedBehavior);
    }

    // Connection teardown (an Rx Finally) reports IsConnected=false; if the
    // client was disposed first the BehaviorSubject is already disposed and
    // OnNext would throw ObjectDisposedException from inside the Finally action,
    // crashing teardown. Swallow exactly that race.
    private void SetIsConnected(bool isConnected)
    {
        try
        {
            _observerIsConnected.OnNext(isConnected);
        }
        catch (ObjectDisposedException)
        {
            // Client disposed while a connection was still winding down.
        }
    }


    /// <summary>
    /// Is using a secure connection scheme. Override for anything but default behavior.
    /// </summary>
    /// <param name="uri">Secure connection scheme method. Override for anything but default behavior.</param>
    /// <returns></returns>
    public virtual bool IsSecureConnectionScheme(Uri uri) =>
        uri?.Scheme switch
        {
            "ws" or "http" => false,
            "https" or "wss" => true,
            _ => throw new ArgumentException("Unknown Uri type.")
        };

    /// <summary>
    /// Server certificate validation. Override for anything but default behavior.
    /// </summary>
    /// <param name="senderObject">Sender object</param>
    /// <param name="certificate">X.509 Certificate</param>
    /// <param name="chain">X.509 Chain</param>
    /// <param name="TlsPolicyErrors"> TLS/SSL policy Errors</param>
    /// <returns></returns>
    public virtual bool ValidateServerCertificate(
        object senderObject,
        X509Certificate certificate,
        X509Chain chain,
        SslPolicyErrors TlsPolicyErrors)
    {
        if (IgnoreServerCertificateErrors) return true;

        return TlsPolicyErrors switch
        {
            SslPolicyErrors.None => true,
            SslPolicyErrors.RemoteCertificateChainErrors =>
                throw new AuthenticationException($"SSL/TLS error: {SslPolicyErrors.RemoteCertificateChainErrors}"),
            SslPolicyErrors.RemoteCertificateNameMismatch =>
                throw new AuthenticationException($"SSL/TLS error: {SslPolicyErrors.RemoteCertificateNameMismatch}"),
            SslPolicyErrors.RemoteCertificateNotAvailable =>
                throw new AuthenticationException($"SSL/TLS error: {SslPolicyErrors.RemoteCertificateNotAvailable}"),
            _ => throw new ArgumentOutOfRangeException(nameof(TlsPolicyErrors), TlsPolicyErrors, null),
        };
    }

    /// <summary>
    /// Websocket Connection Observable.
    /// </summary>
    /// <param name="uri">Websocket Server Endpoint (URI).</param>
    /// <param name="hasClientPing">Set to true to have the client send ping messages to server.</param>
    /// <param name="clientPingInterval">Specific client ping interval. Default is 30 seconds.</param>
    /// <param name="clientPingMessage">Default none. Specific client message. Will stay constant and can only be a <see langword="string"/>. For more advanced scenarios use <see cref="ISender.SendPing"/></param>
    /// <param name="handshaketimeout">Specific time out for client trying to connect (aka handshake). Default is 30 seconds.</param>
    /// <returns></returns>
    public IObservable<IDataframe?> WebsocketConnectObservable(
        Uri uri,
        bool hasClientPing = false,
        TimeSpan clientPingInterval = default,
        string? clientPingMessage = default,
        TimeSpan handshaketimeout = default,
        CancellationToken cancellationToken = default) =>
            WebsocketConnectWithStatusObservable(uri, hasClientPing, clientPingInterval, clientPingMessage, handshaketimeout, cancellationToken)
                .Where(tuple => tuple.state is ConnectionStatus.DataframeReceived)
                .Select(tuple => tuple.dataframe);

    /// <summary>
    /// Websocket Connection Observable with status.
    /// </summary>
    /// <param name="uri">Websocket Server Endpoint (URI).</param>
    /// <param name="hasClientPing">Set to true to have the client send ping messages to server.</param>
    /// <param name="clientPingInterval">Specific client ping interval. Default is 30 seconds will be used.</param>
    /// <param name="clientPingMessage">Specific client message. Default none. Will stay constant and can only be a <see langword="string"/>. For more advanced scenarios use <see cref="ISender.SendPing"/></param>
    /// <param name="handshaketimeout">Specific time out for client trying to connect (aka handshake). Default is 30 seconds.</param>
    /// <returns></returns>
    public IObservable<(IDataframe? dataframe, ConnectionStatus state)>
        WebsocketConnectWithStatusObservable(
            Uri uri,
            bool hasClientPing = false,
            TimeSpan clientPingInterval = default,
            string? clientPingMessage = default,
            TimeSpan handshaketimeout = default,
            CancellationToken cancellationToken = default)
    {
        if (handshaketimeout == default)
        {
            handshaketimeout = TimeSpan.FromSeconds(30);
        }

        void initSender(ISender sender, IEnumerable<string>? negotiatedSubprotocols)
        {
            Sender = sender;
            NegotiatedSubprotocols = negotiatedSubprotocols;
            SetIsConnected(true);
        }

        return Observable.Create<(IDataframe? dataframe, ConnectionStatus state)>(obsTuple =>
            Observable.Create<ConnectionStatus>(async obsStatus =>
            {
                obsStatus.OnNext(ConnectionStatus.Initialized);

                return await Observable.FromAsync<WebsocketService>(_ => WebsocketClientFactory.Create(
                            () => IsSecureConnectionScheme(uri),
                            ValidateServerCertificate,
                            obsStatus,
                            this))
                        .Do(ws => _activeConnections.TryAdd(ws, 0))
                        .Select(ws => Observable.FromAsync<IObservable<IDataframe?>>(ct => ConnectWebsocket(ws, ct))
                            .Concat()
                            .Finally(() =>
                            {
                                _activeConnections.TryRemove(ws, out _);
                                ws.Dispose();
                            })
                            .Subscribe(
                                dataframe => { obsTuple.OnNext((dataframe, ConnectionStatus.DataframeReceived)); },
                                ex => { obsTuple.OnError(ex); },
                                () => { obsTuple.OnCompleted(); }));
            })
            .Finally(() => SetIsConnected(false))
            .Subscribe(
                state => { obsTuple.OnNext((null, state)); },
                ex => { obsTuple.OnError(ex); },
                () => { obsTuple.OnCompleted(); })
            );

        async Task<IObservable<IDataframe?>> ConnectWebsocket(WebsocketService ws, CancellationToken ct) =>
            await ws.WebsocketConnectionHandler.ConnectWebsocket(
                uri,
                X509CertCollection,
                TlsProtocolType,
                initSender,
                hasClientPing,
                clientPingInterval,
                clientPingMessage,
                handshaketimeout,
                Origin,
                Headers,
                Subprotocols,
                ct,
                cancellationToken).ConfigureAwait(false);
    }

    // Add a protected virtual Dispose(bool disposing) method
    protected virtual void Dispose(bool disposing)
    {
        if (disposing)
        {
            // Abrupt teardown of any still-active connection: the close
            // handshake is attempted best-effort within a bound (see
            // WebsocketConnectionHandler.Dispose). Prefer DisposeAsync /
            // `await using` for a fully awaited close.
            foreach (var ws in _activeConnections.Keys)
            {
                if (_activeConnections.TryRemove(ws, out _))
                {
                    ws.Dispose();
                }
            }

            _disposables.Dispose();
        }
    }

    /// <summary>
    /// Disposes the client abruptly: any still-active connection gets a bounded
    /// best-effort close handshake before its socket is torn down. Prefer
    /// <see cref="DisposeAsync"/> (<c>await using</c>) for a graceful close that
    /// is fully awaited.
    /// </summary>
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    /// <summary>
    /// Disposes the client gracefully: the RFC 6455 close handshake of any
    /// still-active connection is awaited (bounded internally) before the
    /// underlying socket and the client's resources are released. The
    /// asynchronous counterpart to <see cref="Dispose()"/>.
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        foreach (var ws in _activeConnections.Keys)
        {
            if (_activeConnections.TryRemove(ws, out _))
            {
                await ws.DisposeAsync().ConfigureAwait(false);
            }
        }

        Dispose(true);
        GC.SuppressFinalize(this);
    }
}

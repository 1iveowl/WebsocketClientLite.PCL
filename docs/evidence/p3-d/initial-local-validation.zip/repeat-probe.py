import subprocess,json,time,pathlib,hashlib,datetime
root=pathlib.Path('/tmp/p3-d-repeat'); out=pathlib.Path('/tmp/p3-d-accepted/repetitions');out.mkdir()
def identity():
 paths=subprocess.check_output(['git','ls-files','-z','src','tools','verification','scripts'],cwd=root).decode().split('\0')
 return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=root).decode(),'hashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if p}}
report={'source':identity(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[]}
try:
 for n in range(10):
  dest=out/str(n);dest.mkdir();cmd=['dotnet','test','src/main/WebsocketClientLiteTest','-c','Release','--no-build','--filter','FullyQualifiedName~ReconnectTests|FullyQualifiedName~RecordHostRuntime','--logger','trx;LogFileName=results.trx','--results-directory',str(dest)]
  start=time.monotonic()
  with (dest/'output.log').open('w') as log: result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  report['runs'].append({'command':cmd,'exit_code':result.returncode,'seconds':time.monotonic()-start})
  if result.returncode: break
finally:
 report['source_after']=identity();(out/'results.json').write_text(json.dumps(report,indent=2))
print([(r['exit_code'],round(r['seconds'],2)) for r in report['runs']])

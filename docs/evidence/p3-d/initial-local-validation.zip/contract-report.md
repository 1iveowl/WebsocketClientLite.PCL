# Contract-change review report

- Target commit: `6709c99e83e65de0c6f42110c47182e62f2bc4ff`
- Compared head: `b297a44ebf99250008d1f4952fd6d85f5405689e`
- Merge base: `6709c99e83e65de0c6f42110c47182e62f2bc4ff`

**Semantic review required.**

This is a textual comparison, not a proof of equivalence or a weakening detector. Review stronger preconditions, weaker postconditions, helper definitions and expanded trust. Normal PR review must record the accepted decision and reviewed head revision; a committed approval flag is not evidence.

Only committed trees are compared. Uncommitted/untracked files are excluded. The full source diff includes changes outside the summaries. No verifier or tests run here.

## Requirement intent

```diff
diff --git abase/verification/requirements.json bhead/verification/requirements.json
index e043ad1..794bf88 100644
--- abase/verification/requirements.json
+++ bhead/verification/requirements.json
@@ -50,5 +50,9 @@
   {
     "id": "LEASE-001",
     "intent": "Selected sender paths retain each rented frame until its write Task settles and return it exactly once with clearing requested; only initialized bytes reach the delegate. Tested C# ownership, not a Dafny proof."
+  },
+  {
+    "id": "EPOCH-001",
+    "intent": "Sequential reconnect uses distinct owned services and sockets; old cleanup cannot reset successor connectivity or dispose its transport. Permanent disposal rejects new admission. Selected C# schedules, tested-only."
   }
 ]
```


## Boundary register

```diff
diff --git a/verification/boundaries.json b/verification/boundaries.json
index bd8bdfb..264c3da 100644
--- a/verification/boundaries.json
+++ b/verification/boundaries.json
@@ -340,6 +340,26 @@
       "exclusions": [
         "Abort does not cancel arbitrary in-flight delegates or guarantee delivery. Tests establish selected finite schedules, not unconditional liveness."
       ]
+    },
+    {
+      "id": "EPOCH-PROGRESS",
+      "assumption": "Callbacks return and external connect/handshake/I/O settle; finite retry and internal sockets are used. Rx disposal and terminal routing remain trusted.",
+      "review_anchor": "boundary-epoch-progress",
+      "owners": [
+        {
+          "file": "src/main/WebsocketClientLite/ClientWebSocketRx.cs",
+          "symbol": "WebsocketClientLite.ClientWebSocketRx.DisposeAsync"
+        }
+      ],
+      "requirements": [
+        "EPOCH-001"
+      ],
+      "test_obligations": [
+        "EPOCH-001-TEST"
+      ],
+      "exclusions": [
+        "Finite loopback schedules do not establish arbitrary concurrency, a wall-clock deadline or simultaneous-subscription public semantics."
+      ]
     }
   ]
 }
```


## Machine-compared external-contract audit

No textual changes.

## Full source diff

```diff
diff --git a/README.md b/README.md
index 5f392bd..8fe33ad 100644
--- a/README.md
+++ b/README.md
@@ -247,6 +247,17 @@ var client = new ClientWebSocketRx { TcpClient = tcpClient, HasTransferSocketLif
 > - The TcpClient will not be disposed automatically when passed in using the constructor unless `HasTransferSocketLifeCycleOwnership = true` is set.
 > - **A supplied `TcpClient` can only serve one connection.** Its socket is closed when the connection tears down, and .NET sockets cannot be reconnected. If you use reconnect patterns such as `Retry()`/`Repeat()`, leave `TcpClient` unset so every attempt gets a fresh socket.
 
+Sequential reconnect with `Retry`/`Repeat` creates a new internal socket and Sender
+for each attempt. A cached old `Sender` remains tied to its old connection and
+fails sends after teardown; obtain `client.Sender` again after reconnecting.
+`Sender` can remain non-null while disconnected. Cleanup from a terminated attempt
+does not reset the successor's connected status or dispose its transport.
+Disposing the client permanently ends admission: later subscriptions fail with
+`ObjectDisposedException`. Unsubscribe to end one attempt while keeping the client
+available. Use a finite retry policy that stops when you dispose the client.
+The shared Sender/status policy for simultaneous active subscriptions on one
+client is unspecified; use separate clients for independent connections.
+
 ### Connecting to a WebSocket Server
 
 To connect and observe WebSocket communication:
diff --git a/src/main/WebsocketClientLite/ClientWebSocketRx.cs b/src/main/WebsocketClientLite/ClientWebSocketRx.cs
index 071ded2..237d2d8 100644
--- a/src/main/WebsocketClientLite/ClientWebSocketRx.cs
+++ b/src/main/WebsocketClientLite/ClientWebSocketRx.cs
@@ -1,5 +1,6 @@
-﻿using System;
+using System;
 using System.Collections.Concurrent;
+using System.Diagnostics.CodeAnalysis;
 using System.Collections.Generic;
 using System.Net.Security;
 using System.Reactive;
@@ -20,11 +21,14 @@ namespace WebsocketClientLite;
 public class ClientWebSocketRx : IWebSocketClientRx, IDisposable, IAsyncDisposable
 {
     private readonly CompositeDisposable _disposables = [];
+    private readonly object _lifecycleGate = new();
+    private bool _disposed;
+    private object? _generation;
     private readonly IObserver<bool> _observerIsConnected;
 
     // Connections created by active subscriptions. Tracked so DisposeAsync can
     // give each one a graceful, awaited close handshake (and Dispose an abrupt
-    // bounded one). Entries remove themselves on normal teardown (the Finally
+    // bounded one). Entries remove themselves on normal teardown (the Using
     // around each connection).
     private readonly ConcurrentDictionary<WebsocketService, byte> _activeConnections = new();
 
@@ -223,6 +227,10 @@ public virtual bool ValidateServerCertificate(
     /// <param name="clientPingMessage">Specific client message. Default none. Will stay constant and can only be a <see langword="string"/>. For more advanced scenarios use <see cref="ISender.SendPing"/></param>
     /// <param name="handshaketimeout">Specific time out for client trying to connect (aka handshake). Default is 30 seconds.</param>
     /// <returns></returns>
+    [SuppressMessage("Maintainability", "CA1513:Use ObjectDisposedException.ThrowIf",
+        Justification = "The same code supports netstandard2.0 and netstandard2.1.")]
+    [SuppressMessage("Reliability", "CA2025:Do not pass disposable instances into unawaited tasks",
+        Justification = "Rx Using owns the service through asynchronous setup and observation; unsubscribe intentionally aborts pending I/O.")]
     public IObservable<(IDataframe? dataframe, ConnectionStatus state)>
         WebsocketConnectWithStatusObservable(
             Uri uri,
@@ -237,44 +245,68 @@ public virtual bool ValidateServerCertificate(
             handshaketimeout = TimeSpan.FromSeconds(30);
         }
 
-        void initSender(ISender sender, IEnumerable<string>? negotiatedSubprotocols)
+        return Observable.Create<(IDataframe? dataframe, ConnectionStatus state)>(obsTuple =>
         {
-            Sender = sender;
-            NegotiatedSubprotocols = negotiatedSubprotocols;
-            SetIsConnected(true);
-        }
+            var generation = new object();
+            lock (_lifecycleGate)
+            {
+                if (_disposed)
+                {
+                    obsTuple.OnError(new ObjectDisposedException(nameof(ClientWebSocketRx)));
+                    return Disposable.Empty;
+                }
+                _generation = generation;
+            }
 
-        return Observable.Create<(IDataframe? dataframe, ConnectionStatus state)>(obsTuple =>
-            Observable.Create<ConnectionStatus>(async obsStatus =>
+            void InitSender(ISender sender, IEnumerable<string>? negotiatedSubprotocols)
             {
-                obsStatus.OnNext(ConnectionStatus.Initialized);
+                lock (_lifecycleGate)
+                {
+                    if (_disposed) throw new ObjectDisposedException(nameof(ClientWebSocketRx));
+                    Sender = sender;
+                    NegotiatedSubprotocols = negotiatedSubprotocols;
+                    SetIsConnected(true);
+                }
+            }
 
-                return await Observable.FromAsync<WebsocketService>(_ => WebsocketClientFactory.Create(
-                            () => IsSecureConnectionScheme(uri),
-                            ValidateServerCertificate,
-                            obsStatus,
-                            this))
-                        .Do(ws => _activeConnections.TryAdd(ws, 0))
-                        .Select(ws => Observable.FromAsync<IObservable<IDataframe?>>(ct => ConnectWebsocket(ws, ct))
-                            .Concat()
-                            .Finally(() =>
-                            {
-                                _activeConnections.TryRemove(ws, out _);
-                                ws.Dispose();
-                            })
-                            .Subscribe(
-                                dataframe => { obsTuple.OnNext((dataframe, ConnectionStatus.DataframeReceived)); },
-                                ex => { obsTuple.OnError(ex); },
-                                () => { obsTuple.OnCompleted(); }));
+            return Observable.Create<ConnectionStatus>(obsStatus =>
+            {
+                obsStatus.OnNext(ConnectionStatus.Initialized);
+                WebsocketService? service = null;
+                return Observable.Using(
+                    () =>
+                    {
+                        lock (_lifecycleGate)
+                        {
+                            if (_disposed) throw new ObjectDisposedException(nameof(ClientWebSocketRx));
+                            service = WebsocketClientFactory.Create(
+                                () => IsSecureConnectionScheme(uri), ValidateServerCertificate, obsStatus, this);
+                            _activeConnections.TryAdd(service, 0);
+                        }
+                        // Using owns cleanup before it starts asynchronous setup.
+                        var owned = service;
+                        return Disposable.Create(() =>
+                        {
+                            _activeConnections.TryRemove(owned, out _);
+                            owned.Dispose();
+                        });
+                    },
+                    _ => Observable.FromAsync<IObservable<IDataframe?>>(ct => ConnectWebsocket(service!, ct, InitSender)).Concat())
+                    .Subscribe(
+                        dataframe => obsTuple.OnNext((dataframe, ConnectionStatus.DataframeReceived)),
+                        obsTuple.OnError, obsTuple.OnCompleted);
             })
-            .Finally(() => SetIsConnected(false))
-            .Subscribe(
-                state => { obsTuple.OnNext((null, state)); },
-                ex => { obsTuple.OnError(ex); },
-                () => { obsTuple.OnCompleted(); })
-            );
-
-        async Task<IObservable<IDataframe?>> ConnectWebsocket(WebsocketService ws, CancellationToken ct) =>
+            .Finally(() =>
+            {
+                lock (_lifecycleGate)
+                {
+                    if (ReferenceEquals(_generation, generation)) SetIsConnected(false);
+                }
+            })
+            .Subscribe(state => obsTuple.OnNext((null, state)), obsTuple.OnError, obsTuple.OnCompleted);
+        });
+
+        async Task<IObservable<IDataframe?>> ConnectWebsocket(WebsocketService ws, CancellationToken ct, Action<ISender, IEnumerable<string>?> initSender) =>
             await ws.WebsocketConnectionHandler.ConnectWebsocket(
                 uri,
                 X509CertCollection,
@@ -296,6 +328,7 @@ protected virtual void Dispose(bool disposing)
     {
         if (disposing)
         {
+            lock (_lifecycleGate) _disposed = true;
             // Abrupt teardown of any still-active connection: the close
             // handshake is attempted best-effort within a bound (see
             // WebsocketConnectionHandler.Dispose). Prefer DisposeAsync /
@@ -332,6 +365,7 @@ public void Dispose()
     /// </summary>
     public async ValueTask DisposeAsync()
     {
+        lock (_lifecycleGate) _disposed = true;
         foreach (var ws in _activeConnections.Keys)
         {
             if (_activeConnections.TryRemove(ws, out _))
diff --git a/src/main/WebsocketClientLite/Factory/WebsocketClientFactory.cs b/src/main/WebsocketClientLite/Factory/WebsocketClientFactory.cs
index 84ea244..1113943 100644
--- a/src/main/WebsocketClientLite/Factory/WebsocketClientFactory.cs
+++ b/src/main/WebsocketClientLite/Factory/WebsocketClientFactory.cs
@@ -1,4 +1,4 @@
-﻿using System;
+using System;
 using System.IO;
 using System.Net.Security;
 using System.Net.Sockets;
@@ -13,7 +13,7 @@ namespace WebsocketClientLite.Factory;
 
 internal static class WebsocketClientFactory
 {
-    internal static Task<WebsocketService> Create(
+    internal static WebsocketService Create(
         Func<bool> isSecureConnectionSchemeFunc,
         Func<object, X509Certificate, X509Chain, SslPolicyErrors, bool> validateServerCertificateFunc,
         IObserver<ConnectionStatus> observerConnectionStatus,
@@ -49,7 +49,7 @@ internal static Task<WebsocketService> Create(
             parserHandler,
             connectionHandler);
 
-        return Task.FromResult(service);
+        return service;
 
         void ConnectionStatusAction(ConnectionStatus status, Exception? ex)
         {
diff --git a/src/main/WebsocketClientLiteTest/LoopbackWebSocketServer.cs b/src/main/WebsocketClientLiteTest/LoopbackWebSocketServer.cs
index fbd8411..0378a3b 100644
--- a/src/main/WebsocketClientLiteTest/LoopbackWebSocketServer.cs
+++ b/src/main/WebsocketClientLiteTest/LoopbackWebSocketServer.cs
@@ -34,7 +34,7 @@ public LoopbackWebSocketServer()
     public Uri Uri => new($"ws://127.0.0.1:{Port}");
 
     /// <summary>Accept one client, complete the handshake, then run <paramref name="afterHandshake"/>.</summary>
-    public void Start(Func<Stream, CancellationToken, Task> afterHandshake)
+    public void Start(Func<Stream, CancellationToken, Task> afterHandshake, Func<Stream, CancellationToken, Task>? beforeHandshakeResponse = null)
     {
         _serverLoop = Task.Run(async () =>
         {
@@ -42,7 +42,7 @@ public void Start(Func<Stream, CancellationToken, Task> afterHandshake)
             {
                 using var tcp = await _listener.AcceptTcpClientAsync(_cts.Token).ConfigureAwait(false);
                 using var stream = tcp.GetStream();
-                await PerformHandshakeAsync(stream, _cts.Token).ConfigureAwait(false);
+                await PerformHandshakeAsync(stream, _cts.Token, beforeHandshakeResponse).ConfigureAwait(false);
                 await afterHandshake(stream, _cts.Token).ConfigureAwait(false);
             }
             catch (OperationCanceledException) { /* shutting down */ }
@@ -219,9 +219,10 @@ private static async Task<string> ReadRequestHeadersAsync(Stream stream, Cancell
         return sb.ToString();
     }
 
-    private static async Task PerformHandshakeAsync(Stream stream, CancellationToken ct)
+    private static async Task PerformHandshakeAsync(Stream stream, CancellationToken ct, Func<Stream, CancellationToken, Task>? beforeResponse = null)
     {
         var request = await ReadRequestHeadersAsync(stream, ct).ConfigureAwait(false);
+        if (beforeResponse is not null) await beforeResponse(stream, ct).ConfigureAwait(false);
 
         var key = TryExtractHeader(request, "Sec-WebSocket-Key")
             ?? throw new IOException("Missing header: Sec-WebSocket-Key");
diff --git a/src/main/WebsocketClientLiteTest/ReconnectTests.cs b/src/main/WebsocketClientLiteTest/ReconnectTests.cs
new file mode 100644
index 0000000..3cdc6b7
--- /dev/null
+++ b/src/main/WebsocketClientLiteTest/ReconnectTests.cs
@@ -0,0 +1,191 @@
+using System;
+using System.Collections.Concurrent;
+using System.Reflection;
+using System.Threading;
+using WebsocketClientLite.Service;
+using WebsocketClientLite.CustomException;
+using System.Reactive.Linq;
+using System.Threading.Tasks;
+using IWebsocketClientLite;
+using WebsocketClientLite;
+using Xunit;
+
+namespace WebsocketClientLiteTest;
+
+public class ReconnectTests
+{
+    private static readonly TimeSpan Limit = TimeSpan.FromSeconds(15);
+
+    [Theory]
+    [InlineData(false)]
+    [InlineData(true)]
+    public async Task DisposedClientRejectsAdmission(bool asynchronous)
+    {
+        using var server = new LoopbackWebSocketServer();
+        server.Start(LoopbackWebSocketServer.EchoLoopAsync);
+        var client = new ClientWebSocketRx();
+        if (asynchronous) await client.DisposeAsync(); else client.Dispose();
+        var terminal = new TaskCompletionSource<Exception?>(TaskCreationOptions.RunContinuationsAsynchronously);
+        using var subscription = client.WebsocketConnectWithStatusObservable(server.Uri).Subscribe(
+            value => { if (value.state == ConnectionStatus.WebsocketConnected) terminal.TrySetResult(null); },
+            error => terminal.TrySetResult(error));
+        Assert.True(await terminal.Task.WaitAsync(Limit) is ObjectDisposedException,
+            "Disposed client admitted a connection");
+    }
+
+    private static ConcurrentDictionary<WebsocketService, byte> Active(ClientWebSocketRx client) =>
+        (ConcurrentDictionary<WebsocketService, byte>)typeof(ClientWebSocketRx)
+            .GetField("_activeConnections", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(client)!;
+
+    [Fact]
+    public async Task TerminalCallbackSuccessorSurvivesOldCleanup()
+    {
+        using var first = new LoopbackWebSocketServer();
+        using var second = new LoopbackWebSocketServer();
+        var endFirst = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        first.Start(async (stream, ct) =>
+        {
+            await endFirst.Task.WaitAsync(ct);
+            await LoopbackWebSocketServer.WriteFrameAsync(stream, 8, new byte[] { 3, 232 }, true, ct);
+            await LoopbackWebSocketServer.ReadFrameAsync(stream, ct);
+        });
+        second.Start(LoopbackWebSocketServer.EchoLoopAsync);
+        using var client = new ClientWebSocketRx();
+        var firstReady = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        var secondReady = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        var oldTerminalReturned = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        var echo = new TaskCompletionSource<string?>(TaskCreationOptions.RunContinuationsAsynchronously);
+        bool connected = false;
+        using var status = client.IsConnectedObservable.Subscribe(value => Volatile.Write(ref connected, value));
+        IDisposable? successor = null;
+        using var initial = client.WebsocketConnectWithStatusObservable(first.Uri).Subscribe(
+            value => { if (value.state == ConnectionStatus.WebsocketConnected) firstReady.TrySetResult(); },
+            ex => oldTerminalReturned.TrySetException(ex),
+            () =>
+            {
+                successor = client.WebsocketConnectWithStatusObservable(second.Uri).Subscribe(value =>
+                {
+                    if (value.state == ConnectionStatus.WebsocketConnected) secondReady.TrySetResult();
+                    if (value.state == ConnectionStatus.DataframeReceived) echo.TrySetResult(value.dataframe?.Message);
+                }, ex => echo.TrySetException(ex));
+                // Hold the old terminal callback until the successor handshake finishes.
+                if (!secondReady.Task.Wait(Limit)) oldTerminalReturned.TrySetException(new TimeoutException());
+                else oldTerminalReturned.TrySetResult();
+            });
+        try
+        {
+            await firstReady.Task.WaitAsync(Limit);
+            var oldSender = client.Sender!;
+            var oldService = Assert.Single(Active(client)).Key;
+            endFirst.TrySetResult();
+            await oldTerminalReturned.Task.WaitAsync(Limit);
+            // Dispose the old subscription explicitly to join its Finally cleanup.
+            initial.Dispose();
+            var close = (Lazy<Task>)typeof(WebsocketConnectionHandler).GetField("_closeHandshakeOnce", BindingFlags.Instance | BindingFlags.NonPublic)!
+                .GetValue(oldService.WebsocketConnectionHandler)!;
+            await close.Value.WaitAsync(Limit);
+            Assert.True(!Active(client).ContainsKey(oldService), "Old service retained registration");
+            Assert.Single(Active(client));
+            Assert.NotSame(oldSender, client.Sender);
+            Assert.True(Volatile.Read(ref connected), "Old cleanup reset successor connectivity");
+            await Assert.ThrowsAsync<WebsocketClientLiteException>(() => oldSender.SendText("old"));
+            await client.Sender!.SendText("new");
+            Assert.Equal("new", await echo.Task.WaitAsync(Limit));
+        }
+        finally { successor?.Dispose(); }
+        Assert.Empty(Active(client));
+    }
+
+    [Theory]
+    [InlineData("dispose")]
+    [InlineData("async")]
+    [InlineData("unsubscribe")]
+    public async Task SetupAdmissionIsOwnedUntilTeardown(string mode)
+    {
+        using var server = new LoopbackWebSocketServer();
+        var accepted = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        var released = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        server.Start(LoopbackWebSocketServer.EchoLoopAsync, async (_, ct) =>
+        {
+            accepted.TrySetResult();
+            await released.Task.WaitAsync(ct);
+        });
+        using var client = new ClientWebSocketRx();
+        using var subscription = client.WebsocketConnectWithStatusObservable(server.Uri).Subscribe(_ => { }, _ => { });
+        try
+        {
+            await accepted.Task.WaitAsync(Limit);
+            Assert.True(Active(client).Count == 1, "Accepted setup missing registration");
+            var service = Assert.Single(Active(client)).Key;
+            var transport = (TcpConnectionService)typeof(WebsocketService)
+                .GetField("_tcpConnectionService", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(service)!;
+            if (mode == "async") await client.DisposeAsync().AsTask().WaitAsync(Limit);
+            else if (mode == "dispose") client.Dispose();
+            else subscription.Dispose();
+            Assert.Empty(Active(client));
+            Assert.False(transport.ConnectionStream.CanRead);
+            Assert.Null(client.Sender);
+        }
+        finally { released.TrySetResult(); }
+    }
+
+    [Theory]
+    [InlineData(false)]
+    [InlineData(true)]
+    public async Task SequentialRepeatOrRetryUsesFreshServices(bool retry)
+    {
+        using var first = new LoopbackWebSocketServer();
+        using var second = new LoopbackWebSocketServer();
+        var finishFirst = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        first.Start(async (stream, ct) =>
+        {
+            await finishFirst.Task.WaitAsync(ct);
+            if (!retry)
+            {
+                await LoopbackWebSocketServer.WriteFrameAsync(stream, 8, new byte[] { 3, 232 }, true, ct);
+                await LoopbackWebSocketServer.ReadFrameAsync(stream, ct);
+            }
+        });
+        second.Start(LoopbackWebSocketServer.EchoLoopAsync);
+        using var client = new ClientWebSocketRx();
+        var firstReady = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        var secondReady = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
+        var echo = new TaskCompletionSource<string?>(TaskCreationOptions.RunContinuationsAsynchronously);
+        int attempts = 0;
+        var source = Observable.Defer(() => client.WebsocketConnectWithStatusObservable(
+            Interlocked.Increment(ref attempts) == 1 ? first.Uri : second.Uri));
+        using var subscription = (retry ? source.Retry(2) : source.Repeat(2)).Subscribe(value =>
+        {
+            if (value.state == ConnectionStatus.WebsocketConnected)
+            {
+                if (Volatile.Read(ref attempts) == 1) firstReady.TrySetResult();
+                else secondReady.TrySetResult();
+            }
+            if (value.state == ConnectionStatus.DataframeReceived) echo.TrySetResult(value.dataframe?.Message);
+        }, ex => { secondReady.TrySetException(ex); echo.TrySetException(ex); });
+        await firstReady.Task.WaitAsync(Limit);
+        var oldSender = client.Sender!;
+        var oldService = Assert.Single(Active(client)).Key;
+        finishFirst.TrySetResult();
+        await secondReady.Task.WaitAsync(Limit);
+        Assert.Equal(2, attempts);
+        Assert.NotSame(oldSender, client.Sender);
+        Assert.True(!Active(client).ContainsKey(oldService), "Old service retained registration");
+        await client.Sender!.SendText("successor");
+        Assert.Equal("successor", await echo.Task.WaitAsync(Limit));
+    }
+
+    [Fact]
+    public async Task FailedConnectTerminatesAndRemovesRegistration()
+    {
+        using var server = new LoopbackWebSocketServer();
+        server.StartWithRawHandshakeResponse("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n");
+        using var client = new ClientWebSocketRx();
+        var terminal = new TaskCompletionSource<Exception>(TaskCreationOptions.RunContinuationsAsynchronously);
+        using var subscription = client.WebsocketConnectWithStatusObservable(server.Uri).Subscribe(_ => { }, ex => terminal.TrySetResult(ex));
+        await terminal.Task.WaitAsync(Limit);
+        subscription.Dispose();
+        Assert.True(SpinWait.SpinUntil(() => Active(client).IsEmpty, Limit), "Failed setup retained registration");
+        Assert.Null(client.Sender);
+    }
+}
diff --git a/tools/Pdd.Tests/ReconnectEvidenceTests.cs b/tools/Pdd.Tests/ReconnectEvidenceTests.cs
new file mode 100644
index 0000000..38b2729
--- /dev/null
+++ b/tools/Pdd.Tests/ReconnectEvidenceTests.cs
@@ -0,0 +1,80 @@
+using System.Text.Json.Nodes;
+using System.Xml.Linq;
+using Pdd;
+using Xunit;
+
+namespace Pdd.Tests;
+
+public class ReconnectEvidenceTests
+{
+    static readonly XNamespace Ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+    const string Hash = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
+    static readonly Dictionary<string, string?> Hashes = new() { [Evidence.ReconnectSource] = Hash };
+    static JsonNode Run(bool pass) => Data.Node(new CommandReceipt { Command = ["dotnet", "test", "-c", "Release", "-p:LibTfm=net10.0"], Status = pass ? "passed" : "failed", ExitCode = pass ? 0 : 1, StartedAt = Data.Now(), FinishedAt = Data.Now() });
+    static JsonNode Fixture(string directory)
+    {
+        void Write(string phase, IEnumerable<(string Name, string Outcome, string Message)> rows)
+        {
+            var path = Path.Combine(directory, phase); Directory.CreateDirectory(path);
+            new XDocument(new XElement(Ns + "TestRun", new XElement(Ns + "Results", rows.Select(r =>
+                new XElement(Ns + "UnitTestResult", new XAttribute("testName", r.Name), new XAttribute("outcome", r.Outcome), new XElement(Ns + "Output", r.Message)))))).Save(Path.Combine(path, "results.trx"));
+            Data.Save(Path.Combine(path, "execution.json"), new { exit_code = phase == "baseline" ? 0 : 1, timed_out = false, interrupted = false });
+        }
+        var runtime = ("RecordHostRuntime", "Passed", "PDD_HOST_RUNTIME=.NET 10 fixture");
+        Write("baseline", Evidence.ReconnectCaseCounts.SelectMany(c => Enumerable.Range(0, c.Value).Select(i => ("ReconnectTests." + c.Key + "(" + i + ")", "Passed", ""))).Append(runtime));
+        var report = new JsonObject { ["status"] = "passed", ["library_target"] = "net10.0", ["baseline"] = Run(true), ["experiments"] = new JsonArray() };
+        foreach (var c in Evidence.ReconnectCases)
+        {
+            Write(c.Id, new[] { (c.Test, "Failed", c.Assertion), runtime });
+            report["experiments"]!.AsArray().Add(new JsonObject { ["id"] = c.Id, ["status"] = "passed", ["test"] = c.Test, ["assertion"] = c.Assertion,
+                ["source_hash"] = Hash, ["mutant_hash"] = new string('b', 64), ["before"] = c.Before, ["after"] = c.After, ["run"] = Run(false), ["host_runtime"] = ".NET 10 fixture" });
+        }
+        return report;
+    }
+    [Fact]
+    public void NamedCleanupAssertionIsAccepted()
+    {
+        using var tree = new TemporaryTree(); Evidence.ValidateReconnectReport(tree.Path, Fixture(tree.Path), Hashes);
+    }
+    [Theory]
+    [InlineData("configuration")]
+    [InlineData("baseline")]
+    [InlineData("source")]
+    [InlineData("edit")]
+    [InlineData("runtime")]
+    [InlineData("timeout")]
+    [InlineData("cancel")]
+    [InlineData("compile")]
+    [InlineData("survival")]
+    [InlineData("assertion")]
+    [InlineData("missing-case")]
+    [InlineData("missing-mutant")]
+    [InlineData("duplicate-mutant")]
+    public void InvalidEvidenceCannotCountAsDetection(string failure)
+    {
+        using var tree = new TemporaryTree(); var report = Fixture(tree.Path);
+        var entry = report["experiments"]![0]!;
+        var trx = Path.Combine(tree.Path, "missing-removal/results.trx");
+        switch (failure)
+        {
+            case "configuration": entry["run"]!["command"]![3] = "Debug"; break;
+            case "baseline": report["baseline"] = Run(false); break;
+            case "source": entry["source_hash"] = "stale"; break;
+            case "edit": entry["after"] = "other"; break;
+            case "runtime": entry["host_runtime"] = "other"; break;
+            case "survival": entry["run"] = Run(true); break;
+            case "compile": File.Delete(trx); break;
+            case "missing-mutant": report["experiments"]!.AsArray().RemoveAt(0); break;
+            case "duplicate-mutant": report["experiments"]!.AsArray().Add(entry.DeepClone()); break;
+            case "assertion": File.WriteAllText(trx, File.ReadAllText(trx).Replace(Evidence.ReconnectCases[0].Assertion, "Stuck owner")); break;
+            case "missing-case":
+                var path = Path.Combine(tree.Path, "baseline/results.trx");
+                var xml = XDocument.Load(path); xml.Descendants(Ns + "UnitTestResult").First().Remove(); xml.Save(path); break;
+            default:
+                var execution = Data.Read(Path.Combine(tree.Path, "missing-removal/execution.json"));
+                execution[failure == "timeout" ? "timed_out" : "interrupted"] = true;
+                Data.Save(Path.Combine(tree.Path, "missing-removal/execution.json"), execution); break;
+        }
+        Assert.ThrowsAny<Exception>(() => Evidence.ValidateReconnectReport(tree.Path, report, Hashes));
+    }
+}
diff --git a/tools/Pdd.Tests/RequirementsTests.cs b/tools/Pdd.Tests/RequirementsTests.cs
index bef536c..c8af108 100644
--- a/tools/Pdd.Tests/RequirementsTests.cs
+++ b/tools/Pdd.Tests/RequirementsTests.cs
@@ -42,7 +42,7 @@ public void MalformedManifest(string json)
     public void ValidManifestAndTestedOnlyRequirements()
     {
         var manifest = new Requirements(Root).Validate();
-        Assert.Equal(13, manifest.Requirements.Length);
+        Assert.Equal(14, manifest.Requirements.Length);
         Assert.Empty(manifest.Requirements.Single(r => r.Id == "REASSEMBLY-003").Contracts);
         Assert.Empty(manifest.Requirements[3].Contracts);
         Assert.Empty(manifest.Requirements[4].Contracts);
diff --git a/tools/Pdd/Aggregation.cs b/tools/Pdd/Aggregation.cs
index 0c3fa9b..cac6c78 100644
--- a/tools/Pdd/Aggregation.cs
+++ b/tools/Pdd/Aggregation.cs
@@ -215,6 +215,22 @@ public JsonObject Aggregate(string directory, SourceIdentity expected)
             }
             catch (Exception e) when (e is not OutOfMemoryException) { retention["status"] = "failed"; errors.Add("Retention experiment: " + e.Message); }
         }
+        var reconnect = new JsonObject { ["status"] = "not-run" };
+        receipt["reconnect_experiment"] = reconnect;
+        if (jobs.ContainsKey("controlled"))
+        {
+            try
+            {
+                Require(Passed(jobs["controlled"]?["runs"]?["reconnect"]), "unsuccessful reconnect command");
+                var directoryPath = Path.Combine(directory, "controlled/reconnect");
+                var report = Read(Path.Combine(directoryPath, "results.json"));
+                Require(Equal(report["source"], Node(expected)) && Equal(report["source_after"], Node(expected)) && Equal(report["ci"], jobs["controlled"]?["ci"]), "reconnect source/CI mismatch");
+                Require(S(report, "status") == "passed", "Incomplete reconnect report");
+                ValidateReconnectReport(directoryPath, report, expected.SourceHashes);
+                reconnect["status"] = "passed"; reconnect["evidence"] = report;
+            }
+            catch (Exception e) when (e is not OutOfMemoryException) { reconnect["status"] = "failed"; errors.Add("Reconnect experiment: " + e.Message); }
+        }
         if (jobs.ContainsKey("stryker"))
         {
             try
@@ -349,6 +365,11 @@ public JsonObject Aggregate(string directory, SourceIdentity expected)
                     item["evidence"]!.AsArray().Add("controlled/retention/results.json");
                     if (S(retention, "status") != "passed") item["status"] = S(retention, "status");
                 }
+                if (o.Id == "EPOCH-001-TEST")
+                {
+                    item["evidence"]!.AsArray().Add("controlled/reconnect/results.json");
+                    if (S(reconnect, "status") != "passed") item["status"] = S(reconnect, "status");
+                }
                 if (o.Id == "CLOSE-004-CONTROLLED")
                 {
                     item["evidence"]!.AsArray().Add("controlled/defect/results.json");
diff --git a/tools/Pdd/Evidence.cs b/tools/Pdd/Evidence.cs
index ed788c7..958625a 100644
--- a/tools/Pdd/Evidence.cs
+++ b/tools/Pdd/Evidence.cs
@@ -20,7 +20,7 @@ public async Task<SourceIdentity> Identity()
     }
     public static List<(string Name, string[] Command)> Commands(string job, string output) => job == "stryker" ?
         [("runtime", ["dotnet", "test", Project, "-c", "Release", "-p:LibTfm=net10.0", "--filter", "FullyQualifiedName=" + RuntimeTest, "--logger", "trx;LogFileName=runtime.trx", "--results-directory", Path.Combine(output, "runtime")]), ("stryker", ["./scripts/stryker-close.sh"])] : job == "controlled" ?
-        [("defect", ["./scripts/pdd.sh", "controlled-defect", "--output", Path.Combine(output, "defect")]), ("boundaries", ["./scripts/pdd.sh", "boundary-defects", "--output", Path.Combine(output, "boundaries")]), ("queued", ["./scripts/pdd.sh", "queued-defect", "--output", Path.Combine(output, "queued")]), ("leases", ["./scripts/pdd.sh", "lease-defects", "--output", Path.Combine(output, "leases")]), ("retention", ["./scripts/pdd.sh", "retention-defects", "--output", Path.Combine(output, "retention")])] : job == "protocol" ?
+        [("defect", ["./scripts/pdd.sh", "controlled-defect", "--output", Path.Combine(output, "defect")]), ("boundaries", ["./scripts/pdd.sh", "boundary-defects", "--output", Path.Combine(output, "boundaries")]), ("queued", ["./scripts/pdd.sh", "queued-defect", "--output", Path.Combine(output, "queued")]), ("leases", ["./scripts/pdd.sh", "lease-defects", "--output", Path.Combine(output, "leases")]), ("retention", ["./scripts/pdd.sh", "retention-defects", "--output", Path.Combine(output, "retention")]), ("reconnect", ["./scripts/pdd.sh", "reconnect-defect", "--output", Path.Combine(output, "reconnect")])] : job == "protocol" ?
         [("manifest", ["./scripts/pdd.sh", "validate"]), ("fixtures", ["dotnet", "test", "tools/Pdd.Tests/Pdd.Tests.csproj", "-c", "Release", "--nologo"]), ("proof", ["./scripts/dafny-masking.sh", "--check"]), ("mutations", ["./scripts/pdd.sh", "mutations", "--output", Path.Combine(output, "mutations")])] :
         [("restore", ["dotnet", "restore", "src/main/WebsocketClientLite.sln"]), ("build", ["dotnet", "build", "src/main/WebsocketClientLite.sln", "--configuration", "Release", "--no-restore"]), ("matrix", ["./test-all-tfms.sh", "Release"]), ("coverage-run", ["dotnet", "test", Project, "--configuration", "Release", "--collect:XPlat Code Coverage", "--results-directory", Path.Combine(output, "coverage")]), ("coverage-gate", ["./scripts/check-coverage.sh", Path.Combine(output, "coverage"), "70"])];
     public async Task<CommandReceipt> Execute(string[] command, string output, double budget = 1800, CancellationToken cancellation = default)
diff --git a/tools/Pdd/Program.cs b/tools/Pdd/Program.cs
index 70a22a8..a159c81 100644
--- a/tools/Pdd/Program.cs
+++ b/tools/Pdd/Program.cs
@@ -81,6 +81,9 @@ void Allow(params string[] names)
                 case "boundary-defects":
                     Allow("--output");
                     return await evidence.BoundaryDefects(output, cancellation.Token);
+                case "reconnect-defect":
+                    Allow("--output");
+                    return await evidence.ReconnectDefects(output, cancellation.Token);
                 case "retention-defects":
                     Allow("--output");
                     return await evidence.RetentionDefects(output, cancellation.Token);
diff --git a/tools/Pdd/README.md b/tools/Pdd/README.md
index 6238d37..b4ec2ba 100644
--- a/tools/Pdd/README.md
+++ b/tools/Pdd/README.md
@@ -179,3 +179,8 @@ Two isolated control-total and late-scratch edits must fail named assertions;
 aggregation checks Release configuration, exact source/edit, cases, execution and
 runtime. The existing REASSEMBLY-001-TEST adapter obligation includes the new
 five-target tests without expanding its proof. See [parser retention](../../verification/parser-retention.md).
+
+P3-D adds `reconnect-defect --output <fresh-directory>` to controlled capture.
+The missing-removal edit must fail the old service identity assertion after all
+nine reconnect cases pass. EPOCH-001-TEST requires five-target tests and this
+source-bound experiment. Concurrent active subscription policy remains deferred.
diff --git a/tools/Pdd/ReconnectDefects.cs b/tools/Pdd/ReconnectDefects.cs
new file mode 100644
index 0000000..311a306
--- /dev/null
+++ b/tools/Pdd/ReconnectDefects.cs
@@ -0,0 +1,113 @@
+using System.Text.Json.Nodes;
+using System.Xml.Linq;
+using static Pdd.Data;
+
+namespace Pdd;
+
+public sealed partial class Evidence
+{
+    public const string ReconnectSource = "src/main/WebsocketClientLite/ClientWebSocketRx.cs";
+    public static readonly Dictionary<string, int> ReconnectCaseCounts = new()
+    {
+        ["DisposedClientRejectsAdmission"] = 2,
+        ["TerminalCallbackSuccessorSurvivesOldCleanup"] = 1,
+        ["SetupAdmissionIsOwnedUntilTeardown"] = 3,
+        ["SequentialRepeatOrRetryUsesFreshServices"] = 2,
+        ["FailedConnectTerminatesAndRemovesRegistration"] = 1
+    };
+    public static readonly (string Id, string Source, string Before, string After, string Test, string Assertion)[] ReconnectCases =
+    [
+        ("missing-removal", ReconnectSource, "_activeConnections.TryRemove(owned, out _);",
+            "// isolated defect: retain the old registration",
+            "TerminalCallbackSuccessorSurvivesOldCleanup", "Old service retained registration")
+    ];
+    public async Task<int> ReconnectDefects(string output, CancellationToken cancellation)
+    {
+        Fresh(output);
+        var report = new JsonObject { ["status"] = "failed", ["source"] = Node(await Identity()), ["ci"] = Node(CiIdentity()),
+            ["started_at"] = Now(), ["library_target"] = "net10.0", ["experiments"] = new JsonArray() };
+        using var copy = new TemporaryTree();
+        try
+        {
+            // Restrict to repository inputs; unrelated untracked dumps are never copied/read.
+            var paths = (await ContractReport.Git(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard",
+                "src", "verification", "tools", "scripts", ".config", "global.json", "Directory.Build.props", "Directory.Build.targets", "NuGet.config")).Split('\0', StringSplitOptions.RemoveEmptyEntries);
+            foreach (var path in paths.Distinct())
+            {
+                var target = Path.Combine(copy.Path, path);
+                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
+                File.Copy(Path.Combine(root, path), target);
+            }
+            var runner = new Evidence(copy.Path);
+            async Task<CommandReceipt> Run(string name, string filter) => await runner.Execute(
+                ["dotnet", "test", Project, "-c", "Release", "-p:LibTfm=net10.0", "--filter", filter + "|FullyQualifiedName=" + RuntimeTest,
+                    "--logger", "trx;LogFileName=results.trx", "--results-directory", Path.Combine(output, name)], Path.Combine(output, name), 180, cancellation);
+            report["baseline"] = Node(await Run("baseline", "FullyQualifiedName~WebsocketClientLiteTest.ReconnectTests"));
+            Require(Passed(report["baseline"]), "Reconnect baseline failed");
+            foreach (var c in ReconnectCases)
+            {
+                var file = Path.Combine(copy.Path, c.Source);
+                var original = Text(file);
+                var name = c.Id;
+                var index = original.IndexOf(c.Before, StringComparison.Ordinal);
+                Require(index >= 0 && original.IndexOf(c.Before, index + 1, StringComparison.Ordinal) < 0, "Ambiguous/missing reconnect edit");
+                File.WriteAllText(file, original[..index] + c.After + original[(index + c.Before.Length)..]);
+                var run = await Run(name, "FullyQualifiedName=WebsocketClientLiteTest.ReconnectTests." + c.Test);
+                var experiment = new JsonObject { ["id"] = name, ["status"] = "failed", ["test"] = c.Test, ["assertion"] = c.Assertion,
+                    ["source_hash"] = Hash(System.Text.Encoding.UTF8.GetBytes(original)), ["mutant_hash"] = Hash(File.ReadAllBytes(file)),
+                    ["before"] = c.Before, ["after"] = c.After, ["run"] = Node(run) };
+                report["experiments"]!.AsArray().Add(experiment);
+                experiment["host_runtime"] = ValidateReconnectResult(Path.Combine(output, name), Node(run), c.Test, c.Assertion);
+                experiment["status"] = "passed";
+                File.WriteAllText(file, original);
+            }
+            report["status"] = "passed";
+            ValidateReconnectReport(output, report, (await Identity()).SourceHashes);
+        }
+        catch (Exception e) when (e is not OutOfMemoryException) { report["status"] = "failed"; report["error"] = e.Message; }
+        finally { report["finished_at"] = Now(); report["source_after"] = Node(await Identity()); Save(Path.Combine(output, "results.json"), report); }
+        return S(report, "status") == "passed" ? 0 : 1;
+    }
+
+    public static void ValidateReconnectReport(string directory, JsonNode report, IReadOnlyDictionary<string, string?> sourceHashes)
+    {
+        Require(S(report, "status") == "passed" && S(report, "library_target") == "net10.0" && Passed(report["baseline"]), "Incomplete reconnect baseline/report");
+        XNamespace ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+        var baseline = XDocument.Load(Path.Combine(directory, "baseline/results.trx")).Descendants(ns + "UnitTestResult").ToArray();
+        Require(baseline.Length == 10 && baseline.All(r => (string?)r.Attribute("outcome") == "Passed"), "Incomplete reconnect baseline cases");
+        foreach (var (test, count) in ReconnectCaseCounts)
+            Require(baseline.Count(r => ((string?)r.Attribute("testName"))?.Contains("ReconnectTests." + test, StringComparison.Ordinal) == true) == count, "Missing named reconnect baseline case");
+        ValidateReconnectExecution(Path.Combine(directory, "baseline"), 0);
+        RequireReconnectCommand(report["baseline"]!);
+        var baselineRuntime = baseline.Single(r => ((string?)r.Attribute("testName"))?.EndsWith("RecordHostRuntime", StringComparison.Ordinal) == true).Value;
+        var entries = report["experiments"]!.AsArray();
+        Require(entries.Count == 1, "Missing reconnect experiments or repetitions");
+        foreach (var c in ReconnectCases)
+        {
+            var name = c.Id;
+            var e = entries.Single(e => S(e, "id") == name)!;
+            Require(S(e, "status") == "passed" && S(e, "source_hash") == sourceHashes[c.Source] && S(e, "mutant_hash").Length == 64 && S(e, "mutant_hash") != sourceHashes[c.Source], "Reconnect mutation identity mismatch");
+            Require(S(e, "before") == c.Before && S(e, "after") == c.After && S(e, "test") == c.Test && S(e, "assertion") == c.Assertion, "Reconnect experiment contract mismatch");
+            var runtime = ValidateReconnectResult(Path.Combine(directory, name), e["run"]!, c.Test, c.Assertion);
+            Require(S(e, "host_runtime") == runtime && baselineRuntime.Contains("PDD_HOST_RUNTIME=" + runtime, StringComparison.Ordinal), "Reconnect runtime mismatch");
+        }
+    }
+
+    private static void RequireReconnectCommand(JsonNode run)
+    {
+        var command = run["command"]!.AsArray().Select(x => x!.ToString()).ToArray();
+        int config = Array.IndexOf(command, "-c");
+        Require(config >= 0 && config + 1 < command.Length && command[config + 1] == "Release" && command.Contains("-p:LibTfm=net10.0"), "Reconnect must use Release/net10.0");
+    }
+    private static void ValidateReconnectExecution(string directory, int code)
+    {
+        var e = Read(Path.Combine(directory, "execution.json"));
+        Require(e["timed_out"]?.GetValue<bool>() == false && e["interrupted"]?.GetValue<bool>() == false && e["launch_error"] is null && e["exit_code"]?.ToString() == code.ToString(), "Invalid reconnect execution");
+    }
+    private static string ValidateReconnectResult(string directory, JsonNode run, string test, string assertion)
+    {
+        RequireReconnectCommand(run);
+        ValidateReconnectExecution(directory, 1);
+        return ValidateBoundaryResult(Path.Combine(directory, "results.trx"), run, test, assertion, 1);
+    }
+}
diff --git a/verification/boundaries.json b/verification/boundaries.json
index bd8bdfb..264c3da 100644
--- a/verification/boundaries.json
+++ b/verification/boundaries.json
@@ -340,6 +340,26 @@
       "exclusions": [
         "Abort does not cancel arbitrary in-flight delegates or guarantee delivery. Tests establish selected finite schedules, not unconditional liveness."
       ]
+    },
+    {
+      "id": "EPOCH-PROGRESS",
+      "assumption": "Callbacks return and external connect/handshake/I/O settle; finite retry and internal sockets are used. Rx disposal and terminal routing remain trusted.",
+      "review_anchor": "boundary-epoch-progress",
+      "owners": [
+        {
+          "file": "src/main/WebsocketClientLite/ClientWebSocketRx.cs",
+          "symbol": "WebsocketClientLite.ClientWebSocketRx.DisposeAsync"
+        }
+      ],
+      "requirements": [
+        "EPOCH-001"
+      ],
+      "test_obligations": [
+        "EPOCH-001-TEST"
+      ],
+      "exclusions": [
+        "Finite loopback schedules do not establish arbitrary concurrency, a wall-clock deadline or simultaneous-subscription public semantics."
+      ]
     }
   ]
 }
diff --git a/verification/close-intent-review.md b/verification/close-intent-review.md
index 7f6fa3b..3c9f111 100644
--- a/verification/close-intent-review.md
+++ b/verification/close-intent-review.md
@@ -293,3 +293,16 @@ with clearing requested, and initialized count. Observation timeout does not end
 write ownership. Pool compliance, relinquishment on Task completion, stable caller
 inputs and external progress remain assumptions. Machine receipts cannot record
 human acceptance; review the PR source revision separately.
+
+### EPOCH-001
+
+Review [reconnect intent and counterexamples](reconnect-intent.md). The admission
+lock covers permanent disposal and registration only; cleanup waits outside it.
+The generation identity suppresses an old final false notification after a new
+subscription. The factory remains synchronous construction, now expressed directly;
+Rx Using installs ownership before setup. No new scheduler or public seam is added.
+
+<a id="boundary-epoch-progress"></a>
+**EPOCH-PROGRESS:** finite callbacks, external connect/handshake settlement and Rx
+resource disposal remain trusted. Simultaneous active subscription policy is
+explicitly deferred. Human semantic acceptance remains a revision-specific review.
diff --git a/verification/reconnect-intent.md b/verification/reconnect-intent.md
new file mode 100644
index 0000000..75dd0da
--- /dev/null
+++ b/verification/reconnect-intent.md
@@ -0,0 +1,58 @@
+# P3-D intent before implementation
+
+Baseline: release 6709c99, containing A and Phase 2 G. The exact G archive and
+receipt digests match the Phase 3 plan. Sequential subscriptions (including
+finite Retry/Repeat) with internal sockets are supported. Each attempt owns its
+service and socket. A retained Sender remains attached to that attempt; after
+teardown it rejects sends and never forwards to a successor. Sender is the most
+recent successful handshake, not a reconnecting proxy, and may remain non-null
+when disconnected. Old teardown must not dispose a successor.
+
+Disposal is permanent: a subscription after disposal must terminate with
+ObjectDisposedException without admitting a service. Setup already in progress
+must either be registered before disposal takes ownership or rejected and cleaned
+up. Subscription cancellation must clean up a service whose creation completes
+late. There is no promise that external connection work finishes by a deadline.
+
+Concurrent active subscriptions' aggregate IsConnected/Sender policy is explicitly
+deferred. No tests here define that public policy. A successor subscribed from an
+old terminal callback is sequential logical reconnect even if old cleanup has not
+returned. G observer/ping and caller-context cases remain inherited acceptance.
+
+Any new production guard requires an executed reduced counterexample. Tests and
+isolated defects establish selected C# schedules only. Human semantic acceptance
+remains a PR review obligation, distinct from machine evidence.
+
+## Reduced counterexamples and scoped correction
+
+At 6709c99 both Dispose and DisposeAsync followed by a new loopback subscription
+reach WebsocketConnected instead of ObjectDisposedException. A second reduced
+schedule completes generation 1, starts generation 2 from its terminal callback,
+holds that callback until generation 2 handshakes, then joins generation 1's
+actual shared close task. The successor remains registered but IsConnected is
+false. These are executed failures, not inferred races.
+
+The correction uses one lifecycle lock to order admission/registration against
+permanent disposal. It never waits for service cleanup under that lock. The
+factory previously returned Task.FromResult around synchronous construction; it
+now returns the service directly. Rx Using installs the identity-bound disposer
+before async connection setup. A per-subscription identity gates only the final
+false notification. Public signatures, protocol core, sender and connection-handler
+algorithms and G observer/ping seams are unchanged. Scope review found no need for
+a scheduler, public reconnect API or broader Rx redesign.
+
+Nine cases exercise the two terminal paths (Repeat and Retry), a reentrant terminal
+callback, three held-handshake teardown modes, two permanent-disposal modes and
+failed handshake cleanup. Tests inspect actual registered service identity and
+closed stream state; real successor echo proves positive progress. Private-field
+inspection is test-only and fails loudly on owner-field renaming. The isolated
+missing-removal edit must fail `Old service retained registration` after the
+unchanged baseline succeeds; timeout or an unrelated failure cannot count.
+
+The held-handshake cases test subscription cancellation, not a new meaning for
+the public cancellationToken (which also participates in frame/control handling).
+No arbitrary connect/dispose schedule or OS connection deadline is proved. The
+reentrant schedule's progress assumes the second handshake and finite callbacks
+return. G's single-generation observer, ping and non-pumping-context tests remain
+mandatory inherited evidence. Human acceptance is still separate from this scoped
+implementation review and from automated receipts.
diff --git a/verification/requirements.json b/verification/requirements.json
index 3a81dcb..5a299d1 100644
--- a/verification/requirements.json
+++ b/verification/requirements.json
@@ -1147,6 +1147,67 @@
         "No concurrent caller mutation safety, universal zeroization, delivery or arbitrary schedule claim.",
         "Pool and stream contracts, scheduling progress and finite callbacks remain trusted; delegates must not use buffers after Task completion."
       ]
+    },
+    {
+      "id": "EPOCH-001",
+      "intent": "Sequential reconnect uses distinct owned services and sockets; old cleanup cannot reset successor connectivity or dispose its transport. Permanent disposal rejects new admission. Selected C# schedules, tested-only.",
+      "origin": [
+        "Library policy: P3-D reconnect intent"
+      ],
+      "contracts": [],
+      "production_paths": [
+        {
+          "reference": {
+            "file": "src/main/WebsocketClientLite/ClientWebSocketRx.cs",
+            "symbol": "WebsocketClientLite.ClientWebSocketRx.DisposeAsync"
+          },
+          "responsibility": "Permanently close admission before draining registered services; the connection observable registers and owns setup/cleanup by service identity."
+        }
+      ],
+      "assumptions": [
+        "EPOCH-PROGRESS"
+      ],
+      "obligations": [
+        {
+          "id": "EPOCH-001-TEST",
+          "kind": "test",
+          "delivery": "existing",
+          "description": "Five-target reconnect, setup disposal/cancellation and failure cases plus reachable missing-removal experiment.",
+          "references": [
+            {
+              "file": "src/main/WebsocketClientLiteTest/ReconnectTests.cs",
+              "symbol": "WebsocketClientLiteTest.ReconnectTests.DisposedClientRejectsAdmission"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ReconnectTests.cs",
+              "symbol": "WebsocketClientLiteTest.ReconnectTests.TerminalCallbackSuccessorSurvivesOldCleanup"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ReconnectTests.cs",
+              "symbol": "WebsocketClientLiteTest.ReconnectTests.SetupAdmissionIsOwnedUntilTeardown"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ReconnectTests.cs",
+              "symbol": "WebsocketClientLiteTest.ReconnectTests.SequentialRepeatOrRetryUsesFreshServices"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ReconnectTests.cs",
+              "symbol": "WebsocketClientLiteTest.ReconnectTests.FailedConnectTerminatesAndRemovesRegistration"
+            }
+          ]
+        },
+        {
+          "id": "EPOCH-001-REVIEW",
+          "kind": "review",
+          "delivery": "existing",
+          "description": "Review reduced admission/status counterexamples, scoped resource ownership and generation guards against the PR revision; concurrent active subscription policy is deferred.",
+          "references": []
+        }
+      ],
+      "exclusions": [
+        "No aggregate policy for simultaneous active subscriptions, arbitrary interleaving proof or unconditional connection progress.",
+        "Caller-supplied sockets cannot reconnect. External connection work and finite callbacks remain trusted."
+      ]
     }
   ],
   "boundaries_file": "verification/boundaries.json"
diff --git a/verification/requirements.schema.json b/verification/requirements.schema.json
index 0b69938..179ff60 100644
--- a/verification/requirements.schema.json
+++ b/verification/requirements.schema.json
@@ -13,7 +13,7 @@
         "properties": {
           "id": {
             "type": "string",
-            "pattern": "^(CLOSE|REASSEMBLY|MASK|WRITE|LEASE)-[0-9]{3}$"
+            "pattern": "^(CLOSE|REASSEMBLY|MASK|WRITE|LEASE|EPOCH)-[0-9]{3}$"
           },
           "intent": {
             "type": "string",
```


import atexit,json,pathlib,runpy,subprocess,sys
from unittest.mock import patch
root=pathlib.Path('/tmp/ws-p3-g');out=pathlib.Path('/tmp/p3-g-evidence/exploration-negatives');out.mkdir()
real=subprocess.run
results=[]
for mode in ['timeout','launch','interrupt']:
 target=out/mode
 def fake(command,*args,**kwargs):
  if command[:2]==['dotnet','build']:
   if mode=='timeout': raise subprocess.TimeoutExpired(command,300,output=b'partial out',stderr=b'partial error')
   if mode=='launch': raise OSError('injected launch failure')
   raise KeyboardInterrupt()
  return real(command,*args,**kwargs)
 sys.argv=['run.py','--output',str(target)]
 with patch('subprocess.run',fake):
  try:runpy.run_path(str(root/'verification/exploration/run.py'),run_name='__main__')
  except (subprocess.TimeoutExpired,OSError,KeyboardInterrupt):pass
  else:raise AssertionError('injected failure accepted')
 atexit._run_exitfuncs()
 records=json.load(open(target/'commands.json'));identity=json.load(open(target/'identity.json'))
 assert len(records)==1 and records[0]['status'] in ['TimeoutExpired','OSError','KeyboardInterrupt']
 assert identity['sourceBefore']==identity['sourceAfter']
 if mode=='timeout': assert (target/'build.log').read_text()=='partial outpartial error'
 results.append(dict(case=mode,status='rejected-and-retained',command=records[0]))
# An already present directory must be rejected before writing any file.
before=(out/'timeout/commands.json').read_bytes()
sys.argv=['run.py','--output',str(out/'timeout')]
try:runpy.run_path(str(root/'verification/exploration/run.py'),run_name='__main__')
except FileExistsError:pass
else:raise AssertionError('overwrite allowed')
assert before==(out/'timeout/commands.json').read_bytes()
results.append(dict(case='existing-output',status='rejected-unchanged'))
(out/'summary.json').write_text(json.dumps(results,indent=2))
print('4 exploration persistence negatives passed (injected failures, not real hang detection)')

import subprocess,json,pathlib,datetime,statistics
out=pathlib.Path('/tmp/p3-g-evidence/ci');out.mkdir()
runs=json.load(open('/tmp/p3-g-evidence/ci-runs.json'))
selected=[r for r in runs if r['databaseId']>=42408136157 and r['databaseId']<=42455442198]
rows=[]
for r in reversed(selected):
    id=r['databaseId']
    raw=subprocess.check_output(['gh','api',f'repos/1iveowl/WebsocketClientLite.PCL/actions/runs/{id}'])
    (out/f'{id}-run.json').write_bytes(raw)
    raw=subprocess.check_output(['gh','api',f'repos/1iveowl/WebsocketClientLite.PCL/actions/runs/{id}/attempts/1/jobs?per_page=100'])
    (out/f'{id}-jobs.json').write_bytes(raw)
    jobs=json.loads(raw)['jobs']; durations=[]
    for j in jobs:
        sec=(datetime.datetime.fromisoformat(j['completed_at'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(j['started_at'].replace('Z','+00:00'))).total_seconds() if j['started_at'] and j['completed_at'] else None
        durations.append(dict(name=j['name'],seconds=0 if j['conclusion']=='skipped' else sec,conclusion=j['conclusion']))
    rows.append(dict(**r,jobs=durations,runner_seconds=sum(j['seconds'] or 0 for j in durations),wall_seconds=(datetime.datetime.fromisoformat(r['updatedAt'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(r['createdAt'].replace('Z','+00:00'))).total_seconds()))
(out/'summary.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))

import subprocess,pathlib,json,zipfile,io,hashlib
out=pathlib.Path('/tmp/p3-g-evidence/ci'); records=[]
for run in json.load(open(out/'summary.json')):
 id=run['databaseId']
 artifacts=json.loads(subprocess.check_output(['gh','api',f'repos/1iveowl/WebsocketClientLite.PCL/actions/runs/{id}/artifacts']))
 (out/f'{id}-artifacts.json').write_text(json.dumps(artifacts,indent=2))
 for a in artifacts['artifacts']:
  if a['name']!='pdd-receipt':continue
  record=dict(run=id,artifact=a['id'],expired=a['expired']);records.append(record)
  if a['expired']:continue
  raw=subprocess.check_output(['gh','api',f"repos/1iveowl/WebsocketClientLite.PCL/actions/artifacts/{a['id']}/zip"])
  record['archive_sha256']=hashlib.sha256(raw).hexdigest()
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for name in z.namelist():
    if name=='receipt.json' or name.endswith('/job.json') or name.endswith('/execution.json'):
     data=z.read(name);dest=out/str(id)/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
     if name=='receipt.json': record['receipt_sha256']=hashlib.sha256(data).hexdigest()
 (out/'downloads.json').write_text(json.dumps(records,indent=2))
print('retained',len(records),'receipts')

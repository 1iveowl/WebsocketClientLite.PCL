import subprocess,json,time,pathlib,resource,os
root=pathlib.Path('/tmp/ws-p3-g'); out=pathlib.Path('/tmp/p3-g-evidence'); records=[]
def run(name,args):
    start=time.time(); record=dict(name=name,command=args,started=start,status='started'); records.append(record)
    (out/'attempts.json').write_text(json.dumps(records,indent=2))
    with (out/(name+'.log')).open('w') as log:
        p=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    record.update(exit=p.returncode,seconds=time.time()-start,status='completed',cumulative_children_maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    (out/'attempts.json').write_text(json.dumps(records,indent=2))
    print(name,p.returncode,record['seconds'],flush=True)
    return p.returncode
pdd=['dotnet','tools/Pdd/bin/Release/net10.0/Pdd.dll']
run('build-tool',['dotnet','build','tools/Pdd/Pdd.csproj','-c','Release'])
for job in ['protocol','tests','controlled','stryker']:
    run(job,pdd+['capture','--job',job,'--output',str(out/'full'/job)])
run('aggregate',pdd+['aggregate','--output',str(out/'full')])
for i in [2,3]:
    run('controlled-'+str(i),pdd+['capture','--job','controlled','--output',str(out/('controlled-'+str(i)))])
for i in [1,2,3]:
    run('host-'+str(i),pdd+['test-host','--cell','linux-10-net10.0','--output',str(out/('host-'+str(i)))])
run('exploration',['python3','verification/exploration/run.py','--output',str(out/'exploration')])

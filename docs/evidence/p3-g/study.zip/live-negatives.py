import pathlib,json,shutil,subprocess
root=pathlib.Path('/tmp/ws-p3-g');out=pathlib.Path('/tmp/p3-g-evidence');results=[]
assert json.load(open(out/'full/receipt.json'))['gate']['status']=='passed'
for name in ['absent-trx','stale-source','ordering-timeout','boundary-interruption']:
 d=out/'negatives'/name;shutil.copytree(out/'full',d)
 if name=='absent-trx':(d/'tests/tests/net10.0/results.trx').unlink()
 else:
  relative={'stale-source':'controlled/job.json','ordering-timeout':'controlled/defect/mutant/execution.json','boundary-interruption':'controlled/boundaries/read-failure-0/execution.json'}[name]
  p=d/relative;obj=json.load(open(p))
  if name=='stale-source':obj['source']['tested_commit']='stale-source-probe'
  elif name=='ordering-timeout':obj['timed_out']=True
  else:obj['interrupted']=True
  p.write_text(json.dumps(obj,indent=2))
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(['dotnet','tools/Pdd/bin/Release/net10.0/Pdd.dll','aggregate','--output',str(d)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 r=json.load(open(d/'receipt.json'))
 assert result.returncode==1 and r['gate']['status']=='failed',name
 if name=='absent-trx':assert r['framework_matrix']['net10.0']['status']=='not-run'
 elif name=='stale-source':assert 'controlled' in r['rejected_jobs']
 elif name=='ordering-timeout':assert r['controlled_experiment']['status']=='failed'
 else:assert r['boundary_experiments']['status']=='failed'
 # Keep changed inputs and failed receipt, referring to the identical positive
 # capture for the remaining inputs, instead of archiving four duplicate trees.
 keep=['receipt.json','summary.md']
 if name!='absent-trx':keep.append(relative)
 for p in list(d.rglob('*')):
  if p.is_file() and str(p.relative_to(d)) not in keep:p.unlink()
 results.append(dict(case=name,exit=result.returncode,gate=r['gate'],errors=r['errors'],base='full',edit='delete tests/tests/net10.0/results.trx' if name=='absent-trx' else relative))
(out/'negatives/summary.json').write_text(json.dumps(results,indent=2))
print('4 live negatives rejected; original capture preserved')

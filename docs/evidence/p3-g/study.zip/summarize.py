import pathlib,json,statistics,xml.etree.ElementTree as ET,hashlib,datetime
out=pathlib.Path('/tmp/p3-g-evidence'); summary={}
receipt=json.load(open(out/'full/receipt.json'))
summary['source']=receipt['source'];summary['gate']=receipt['gate'];summary['errors']=receipt['errors'];summary['stryker']=receipt['stryker']
summary['commands']={}
for p in (out/'full').glob('*/commands/*/execution.json'):
 e=json.load(open(p));summary['commands'][str(p.parent.relative_to(out/'full'))]={k:e.get(k) for k in ['elapsed_seconds','exit_code','timed_out','interrupted','cleanup_incomplete','cleanup_seconds']}
summary['controlled']=[]
for d in [out/'full/controlled',out/'controlled-2',out/'controlled-3']:
 j=json.load(open(d/'job.json'));assert j['source']==j['source_after']==receipt['source']
 runs={name:json.load(open(d/'commands'/name/'execution.json'))['elapsed_seconds'] for name in j['runs']}
 reports={name:json.load(open(d/name/'results.json'))['status'] for name in j['runs']}
 assert all(s=='passed' for s in reports.values())
 summary['controlled'].append(dict(directory=str(d.relative_to(out)),seconds=runs,outcomes=reports,incremental_abcd=sum(runs[n] for n in ['queued','leases','retention','reconnect'])))
summary['hosts']=[]
for i in [1,2,3]:
 d=out/f'host-{i}'; j=json.load(open(d/'job.json'));assert j['source']==j['source_after']==receipt['source']
 summary['hosts'].append(dict(directory=d.name,job=j))
summary['exploration']={'commands':json.load(open(out/'exploration/commands.json')),'identity':json.load(open(out/'exploration/identity.json'))}
assert summary['exploration']['identity']['sourceBefore']==summary['exploration']['identity']['sourceAfter']
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
summary['matrix']={}
for p in (out/'full/tests/tests').glob('*/results.trx'):
 rows=ET.parse(p).findall('.//t:UnitTestResult',ns)
 summary['matrix'][p.parent.name]=dict(count=len(rows),outcomes={k:sum(r.attrib['outcome']==k for r in rows) for k in {r.attrib['outcome'] for r in rows}})
summary['coverage']=receipt['coverage']
summary['review_not_run']=len(receipt['review_evidence'])
(out/'study-summary.json').write_text(json.dumps(summary,indent=2))
print('gate',summary['gate'],'matrix',summary['matrix'])
print('commands',summary['commands'])
print('controlled',summary['controlled'])

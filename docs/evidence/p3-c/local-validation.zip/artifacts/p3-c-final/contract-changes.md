# Contract-change review report

- Target commit: `77af6c570d0f52e6a6c31a85116cf687a99c53b1`
- Compared head: `03c251903c969455ac68b73fc2fce6604bab86de`
- Merge base: `77af6c570d0f52e6a6c31a85116cf687a99c53b1`

**Semantic review required.**

This is a textual comparison, not a proof of equivalence or a weakening detector. Review stronger preconditions, weaker postconditions, helper definitions and expanded trust. Normal PR review must record the accepted decision and reviewed head revision; a committed approval flag is not evidence.

Only committed trees are compared. Uncommitted/untracked files are excluded. The full source diff includes changes outside the summaries. No verifier or tests run here.

## Requirement intent

No textual changes.

## Boundary register

```diff
diff --git a/verification/boundaries.json b/verification/boundaries.json
index 29ed462..bd8bdfb 100644
--- a/verification/boundaries.json
+++ b/verification/boundaries.json
@@ -205,6 +205,10 @@
         {
           "file": "src/main/WebsocketClientLite/Helper/VerifiedNativeCopy.cs",
           "symbol": "WebsocketClientLite.VerifiedProtocol.NativeCopy.CopySlice"
+        },
+        {
+          "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+          "symbol": "WebsocketClientLiteTest.ParserRetentionTests.SmallSequencesPreserveBytesMetadataAndReset"
         }
       ],
       "requirements": [
@@ -241,6 +245,10 @@
         {
           "file": "src/main/WebsocketClientLiteTest/PayloadBoundaryTests.cs",
           "symbol": "WebsocketClientLiteTest.PayloadBoundaryTests.MergeVariantsPreserveAliasedSegmentsAndReturnFreshStorage"
+        },
+        {
+          "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+          "symbol": "WebsocketClientLiteTest.ParserRetentionTests.SmallSequencesPreserveBytesMetadataAndReset"
         }
       ],
       "requirements": [
```


## Machine-compared external-contract audit

No textual changes.

## Full source diff

```diff
diff --git a/src/main/WebsocketClientLiteTest/ParserRetentionTests.cs b/src/main/WebsocketClientLiteTest/ParserRetentionTests.cs
new file mode 100644
index 0000000..563e575
--- /dev/null
+++ b/src/main/WebsocketClientLiteTest/ParserRetentionTests.cs
@@ -0,0 +1,229 @@
+using System;
+using System.Collections.Generic;
+using System.IO;
+using System.Linq;
+using System.Reactive.Linq;
+using System.Reflection;
+using System.Text;
+using System.Threading;
+using System.Threading.Tasks;
+using IWebsocketClientLite;
+using WebsocketClientLite.CustomException;
+using WebsocketClientLite.Helper;
+using WebsocketClientLite.Model;
+using WebsocketClientLite.Service;
+using Xunit;
+
+namespace WebsocketClientLiteTest;
+
+public class ParserRetentionTests
+{
+    // A single reader supplies one byte per read, exercising both TFM read overloads.
+    // BytesRead and Attempts distinguish admission rejection from an absent body/EOF.
+    private sealed class Input(byte[] bytes, bool cancelAtEnd = false) : MemoryStream(bytes)
+    {
+        public int Attempts { get; private set; }
+        public int BytesRead => (int)Position;
+        private int Next(Span<byte> destination)
+        {
+            Attempts++;
+            if (Position == Length && cancelAtEnd) throw new OperationCanceledException();
+            return base.Read(destination[..Math.Min(1, destination.Length)]);
+        }
+        public override Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken token) =>
+            Task.FromResult(Next(buffer.AsSpan(offset, count)));
+        public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken token = default) =>
+            new(Next(buffer.Span));
+    }
+    private static TcpConnectionService Connection(Stream stream, int limit = 0)
+    {
+        var connection = new TcpConnectionService(() => false, (_, _, _, _) => true,
+            (_, _) => Task.CompletedTask, (_, _) => { }, true, maxFrameSize: limit);
+        typeof(TcpConnectionService).GetField("_stream", BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(connection, stream);
+        return connection;
+    }
+    // Independent literal RFC wire encoding; never calls production composition/Step/Merge.
+    private static byte[] Wire(byte opcode, bool fin, params byte[] payload) =>
+        new[] { (byte)(opcode | (fin ? 128 : 0)), checked((byte)payload.Length) }.Concat(payload).ToArray();
+    private static byte[] Join(params byte[][] pieces) => pieces.SelectMany(p => p).ToArray();
+    private static void Message(Dataframe frame, byte opcode, byte[] expected)
+    {
+        Assert.True(frame.Payload!.SequenceEqual(expected), "Retained bytes differ from independent concatenation");
+        Assert.True(frame.Length == (ulong)expected.Length, "Retained Length differs from byte total");
+        Assert.True(frame.FIN && frame.Fragment == FragmentKind.None && (byte)frame.Opcode == opcode,
+            "Original message metadata was not preserved");
+    }
+    private static async Task<(List<Dataframe> Frames, Exception? Error)> Observe(TcpConnectionService connection)
+    {
+        using var parser = new WebsocketParserHandler(connection);
+        var frames = new List<Dataframe>();
+        var done = new TaskCompletionSource<Exception?>(TaskCreationOptions.RunContinuationsAsynchronously);
+        using var subscription = parser.DataframeObservable().Subscribe(f => frames.Add(f!), e => done.TrySetResult(e), () => done.TrySetResult(null));
+        return (frames, await done.Task.WaitAsync(TimeSpan.FromSeconds(15)));
+    }
+
+    [Fact]
+    public async Task SmallSequencesPreserveBytesMetadataAndReset()
+    {
+        // Exhaustive bounded lengths 0..2 in three fragments: zero, one and multiple
+        // retained arrays, empty continuations, both data opcodes and controls.
+        foreach (byte opcode in new byte[] { 1, 2 })
+        for (int a = 0; a <= 2; a++)
+        for (int b = 0; b <= 2; b++)
+        for (int c = 0; c <= 2; c++)
+        {
+            byte[] x = Enumerable.Repeat((byte)'a', a).ToArray(), y = Enumerable.Repeat((byte)'b', b).ToArray(), z = Enumerable.Repeat((byte)'c', c).ToArray();
+            using var input = new Input(Join(Wire(opcode, false, x), Wire(9, true, 90), Wire(0, false, y),
+                Wire(10, true, 91), Wire(0, true, z), Wire(2, true, 42), Wire(1, true), Wire(8, true)));
+            using var connection = Connection(input, 6);
+            var (frames, error) = await Observe(connection);
+            Assert.True(error is null, "Sequence rejected: " + error);
+            Assert.Equal(6, frames.Count);
+            Message(frames[0], 9, new byte[] { 90 }); Message(frames[1], 10, new byte[] { 91 });
+            Message(frames[2], opcode, Join(x, y, z));
+            Message(frames[3], 2, new byte[] { 42 }); Message(frames[4], 1, Array.Empty<byte>());
+            Assert.Equal(OpcodeKind.Close, frames[5].Opcode);
+        }
+    }
+
+    [Theory]
+    [InlineData(1)]
+    [InlineData(4)]
+    public async Task AccumulatedLimitRejectsBeforePayloadRead(int limit)
+    {
+        // Each prefix length probes the externally observable remaining budget.
+        for (int prefix = 0; prefix <= limit; prefix++)
+        foreach (int total in new[] { limit - 1, limit, limit + 1 }.Where(n => n >= prefix))
+        {
+            var first = Enumerable.Repeat((byte)7, prefix).ToArray();
+            var last = Enumerable.Repeat((byte)8, total - prefix).ToArray();
+            var beforeLast = Join(Wire(2, false, first), Wire(9, true, 99), Wire(0, false), Wire(10, true, 98));
+            using var input = new Input(Join(beforeLast, Wire(0, true, last), Wire(8, true)));
+            using var connection = Connection(input, limit);
+            var (frames, error) = await Observe(connection);
+            if (total > limit)
+            {
+                Assert.IsType<WebsocketClientLiteException>(error);
+                Assert.True(input.BytesRead == beforeLast.Length + 2 && input.Attempts == input.BytesRead,
+                    "Accumulated limit consumed rejected payload");
+                Assert.Equal(2, frames.Count);
+            }
+            else
+            {
+                Assert.True(error is null, "Control payload changed retained budget: " + error);
+                Message(frames[2], 2, Join(first, last));
+            }
+        }
+    }
+
+    [Fact]
+    public async Task ControlPayloadDoesNotChangeRetainedTotal()
+    {
+        using var input = new Input(Join(Wire(2, false, 1, 2), Wire(9, true, 99), Wire(0, true, 3, 4), Wire(8, true)));
+        using var connection = Connection(input, 4);
+        var (frames, error) = await Observe(connection);
+        Assert.True(error is null && frames.Count == 3, "Control payload changed retained budget: " + error);
+        Message(frames[1], 2, new byte[] { 1, 2, 3, 4 });
+        Assert.True(input.BytesRead == 13, "Control sequence read budget differs from wire size");
+    }
+
+    [Fact]
+    public async Task ExtendedHeaderCapturesScratchBeforeReuse()
+    {
+        var expected = Enumerable.Range(0, 126).Select(i => (byte)i).ToArray();
+        using var input = new Input(Join(new byte[] { 0x82, 126, 0, 126 }, expected));
+        using var connection = Connection(input);
+        Dataframe? frame = null; Exception? error = null;
+        try { frame = await connection.ReadDataframeAsync(CancellationToken.None); }
+        catch (Exception e) { error = e; }
+        Assert.True(error is null && frame is not null, "Header scratch capture corrupted admission: " + error);
+        Message(frame!, 2, expected);
+        Assert.True(input.BytesRead == 130 && input.Attempts == 130, "Header read budget differs from wire size");
+    }
+
+    [Theory]
+    [InlineData(2147483647UL, 1U)]
+    [InlineData(2147483648UL, 0U)]
+    [InlineData(9223372036854775808UL, 0U)]
+    public async Task HugeLengthsRejectOnHeaderOnly(ulong length, uint retained)
+    {
+        var bytes = new List<byte> { 0x80, 127 };
+        for (int shift = 56; shift >= 0; shift -= 8) bytes.Add((byte)(length >> shift));
+        using var input = new Input(bytes.ToArray()); using var connection = Connection(input);
+        await Assert.ThrowsAsync<WebsocketClientLiteException>(() => connection.ReadDataframeAsync(CancellationToken.None, 2, retained));
+        Assert.True(input.BytesRead == 10 && input.Attempts == 10, "Large admission attempted payload allocation/read");
+    }
+
+    [Theory]
+    [InlineData(false)]
+    [InlineData(true)]
+    public async Task IncompleteMessageTerminatesWithoutEmission(bool cancel)
+    {
+        // EOF/cancellation at next header, partial extended header and partial payload.
+        foreach (var tail in new[] { Array.Empty<byte>(), new byte[] { 0x80, 126, 0 }, new byte[] { 0x80, 2, 9 } })
+        {
+            using var input = new Input(Join(Wire(2, false, 7), tail), cancel);
+            using var connection = Connection(input);
+            var (frames, error) = await Observe(connection);
+            Assert.Empty(frames);
+            if (cancel) Assert.Null(error); else Assert.IsType<WebsocketClientLiteException>(error);
+        }
+    }
+
+    [Fact]
+    public async Task CloseAndInvalidContinuationDoNotLeakRetainedData()
+    {
+        using var input = new Input(Join(Wire(2, false, 7), Wire(8, true), Wire(0, true, 8)));
+        using var connection = Connection(input);
+        var (frames, error) = await Observe(connection);
+        Assert.Null(error); Assert.Equal(OpcodeKind.Close, Assert.Single(frames).Opcode);
+        Assert.Equal(5, input.BytesRead);
+        foreach (var prefix in new[] { Array.Empty<byte>(), Wire(2, true, 7) })
+        {
+            using var invalid = new Input(Join(prefix, Wire(0, true, 8)));
+            using var badConnection = Connection(invalid);
+            var result = await Observe(badConnection);
+            Assert.IsType<WebsocketClientLiteException>(result.Error);
+            Assert.True(invalid.BytesRead == prefix.Length + 2 && invalid.Attempts == invalid.BytesRead, "Orphan continuation consumed payload");
+            Assert.Equal(prefix.Length == 0 ? 0 : 1, result.Frames.Count);
+        }
+    }
+
+    [Fact]
+    public async Task SplitUtf8IsValidatedOnlyWhenComplete()
+    {
+        foreach (byte final in new byte[] { 0xac, 0xff })
+        {
+            using var input = new Input(Join(Wire(1, false, 0xe2), Wire(9, true, 1), Wire(0, false, 0x82), Wire(0, true, final), Wire(8, true)));
+            using var connection = Connection(input, 3);
+            var (frames, error) = await Observe(connection);
+            if (final == 0xac) { Assert.Null(error); Message(frames[1], 1, new byte[] { 0xe2, 0x82, 0xac }); Assert.Equal("€", frames[1].Message); }
+            else { Assert.IsType<WebsocketClientLiteException>(error); Assert.Equal(OpcodeKind.Ping, Assert.Single(frames).Opcode); }
+        }
+    }
+
+    [Fact]
+    public async Task HandshakeConsumesScratchImmediatelyAndStopsBeforeFrame()
+    {
+        using var input = new Input(Array.Empty<byte>()); // replaced by writer after it sees the random request key
+        using var connection = Connection(input);
+        Input? response = null; int headerLength = 0;
+        var sender = new WebsocketSenderHandler(connection, (_, _) => { }, (_, buffer, count, _) =>
+        {
+            string request = Encoding.ASCII.GetString(buffer, 0, count);
+            string key = request.Split("\r\n").Single(l => l.StartsWith("Sec-WebSocket-Key:", StringComparison.Ordinal)).Split(':')[1].Trim();
+            string accept = Convert.ToBase64String(System.Security.Cryptography.SHA1.HashData(Encoding.ASCII.GetBytes(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")));
+            var header = Encoding.ASCII.GetBytes("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n");
+            headerLength = header.Length;
+            response = new Input(Join(header, Wire(2, true, 17), Wire(8, true)));
+            typeof(TcpConnectionService).GetField("_stream", BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(connection, response);
+            return Task.CompletedTask;
+        }, false);
+        var handshake = new HandshakeHandler(connection, (_, _) => { });
+        var states = await handshake.Handshake(new Uri("ws://localhost/"), sender, TimeSpan.FromSeconds(15), CancellationToken.None).ToArray();
+        Assert.Equal(HandshakeStateKind.HandshakeCompletedSuccessfully, Assert.Single(states).handshakeState);
+        Assert.True(response!.BytesRead == headerLength && response.Attempts == headerLength, "Handshake consumed first frame or reused stale scratch");
+        var result = await Observe(connection);
+        Assert.Null(result.Error); Message(result.Frames[0], 2, new byte[] { 17 });
+    }
+}
diff --git a/tools/Pdd.Tests/RetentionEvidenceTests.cs b/tools/Pdd.Tests/RetentionEvidenceTests.cs
new file mode 100644
index 0000000..45bbf68
--- /dev/null
+++ b/tools/Pdd.Tests/RetentionEvidenceTests.cs
@@ -0,0 +1,80 @@
+using System.Text.Json.Nodes;
+using System.Xml.Linq;
+using Pdd;
+using Xunit;
+
+namespace Pdd.Tests;
+
+public class RetentionEvidenceTests
+{
+    static readonly XNamespace Ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+    const string Hash = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
+    static readonly Dictionary<string, string?> Hashes = new() { [Evidence.RetentionSource] = Hash, [Evidence.HeaderSource] = Hash };
+    static JsonNode Run(bool pass) => Data.Node(new CommandReceipt { Command = ["dotnet", "test", "-c", "Release", "-p:LibTfm=net10.0"], Status = pass ? "passed" : "failed", ExitCode = pass ? 0 : 1, StartedAt = Data.Now(), FinishedAt = Data.Now() });
+    static JsonNode Fixture(string directory)
+    {
+        void Write(string phase, IEnumerable<(string Name, string Outcome, string Message)> rows)
+        {
+            var path = Path.Combine(directory, phase); Directory.CreateDirectory(path);
+            new XDocument(new XElement(Ns + "TestRun", new XElement(Ns + "Results", rows.Select(r =>
+                new XElement(Ns + "UnitTestResult", new XAttribute("testName", r.Name), new XAttribute("outcome", r.Outcome), new XElement(Ns + "Output", r.Message)))))).Save(Path.Combine(path, "results.trx"));
+            Data.Save(Path.Combine(path, "execution.json"), new { exit_code = phase == "baseline" ? 0 : 1, timed_out = false, interrupted = false });
+        }
+        var runtime = ("RecordHostRuntime", "Passed", "PDD_HOST_RUNTIME=.NET 10 fixture");
+        Write("baseline", Evidence.RetentionCaseCounts.SelectMany(c => Enumerable.Range(0, c.Value).Select(i => ("ParserRetentionTests." + c.Key + "(" + i + ")", "Passed", ""))).Append(runtime));
+        var report = new JsonObject { ["status"] = "passed", ["library_target"] = "net10.0", ["baseline"] = Run(true), ["experiments"] = new JsonArray() };
+        foreach (var c in Evidence.RetentionCases)
+        {
+            Write(c.Id, new[] { (c.Test, "Failed", c.Assertion), runtime });
+            report["experiments"]!.AsArray().Add(new JsonObject { ["id"] = c.Id, ["status"] = "passed", ["test"] = c.Test, ["assertion"] = c.Assertion,
+                ["source_hash"] = Hash, ["mutant_hash"] = new string('b', 64), ["before"] = c.Before, ["after"] = c.After, ["run"] = Run(false), ["host_runtime"] = ".NET 10 fixture" });
+        }
+        return report;
+    }
+    [Fact]
+    public void TwoNamedRetentionAssertionsAreAccepted()
+    {
+        using var tree = new TemporaryTree(); Evidence.ValidateRetentionReport(tree.Path, Fixture(tree.Path), Hashes);
+    }
+    [Theory]
+    [InlineData("configuration")]
+    [InlineData("baseline")]
+    [InlineData("source")]
+    [InlineData("edit")]
+    [InlineData("runtime")]
+    [InlineData("timeout")]
+    [InlineData("cancel")]
+    [InlineData("compile")]
+    [InlineData("survival")]
+    [InlineData("assertion")]
+    [InlineData("missing-case")]
+    [InlineData("missing-mutant")]
+    [InlineData("duplicate-mutant")]
+    public void InvalidEvidenceCannotCountAsDetection(string failure)
+    {
+        using var tree = new TemporaryTree(); var report = Fixture(tree.Path);
+        var entry = report["experiments"]![0]!;
+        var trx = Path.Combine(tree.Path, "control-total/results.trx");
+        switch (failure)
+        {
+            case "configuration": entry["run"]!["command"]![3] = "Debug"; break;
+            case "baseline": report["baseline"] = Run(false); break;
+            case "source": entry["source_hash"] = "stale"; break;
+            case "edit": entry["after"] = "other"; break;
+            case "runtime": entry["host_runtime"] = "other"; break;
+            case "survival": entry["run"] = Run(true); break;
+            case "compile": File.Delete(trx); break;
+            case "missing-mutant": report["experiments"]!.AsArray().RemoveAt(0); break;
+            case "duplicate-mutant": report["experiments"]![1] = entry.DeepClone(); break;
+            case "assertion": File.WriteAllText(trx, File.ReadAllText(trx).Replace(Evidence.RetentionCases[0].Assertion, "Stuck owner")); break;
+            case "missing-case":
+                var path = Path.Combine(tree.Path, "baseline/results.trx");
+                var xml = XDocument.Load(path); xml.Descendants(Ns + "UnitTestResult").First().Remove(); xml.Save(path); break;
+            default:
+                var execution = Data.Read(Path.Combine(tree.Path, "control-total/execution.json"));
+                execution[failure == "timeout" ? "timed_out" : "interrupted"] = true;
+                Data.Save(Path.Combine(tree.Path, "control-total/execution.json"), execution); break;
+        }
+        Assert.ThrowsAny<Exception>(() => Evidence.ValidateRetentionReport(tree.Path, report, Hashes));
+    }
+}
diff --git a/tools/Pdd/Aggregation.cs b/tools/Pdd/Aggregation.cs
index f3991a6..0c3fa9b 100644
--- a/tools/Pdd/Aggregation.cs
+++ b/tools/Pdd/Aggregation.cs
@@ -77,6 +77,11 @@ public static JsonObject TestResults(string directory)
                 var fullName = "WebsocketClientLiteTest.PayloadLeaseTests." + name;
                 if (caseCounts.TryGetValue(fullName, out var actualCount) && actualCount != count) tests[fullName] = "failed";
             }
+            foreach (var (name, count) in RetentionCaseCounts)
+            {
+                var fullName = "WebsocketClientLiteTest.ParserRetentionTests." + name;
+                if (caseCounts.TryGetValue(fullName, out var actualCount) && actualCount != count) tests[fullName] = "failed";
+            }
             var run = Read(Path.Combine(path, "run.json"));
             var valid = Passed(run) && (run["command"]?.AsArray() ?? []).Any(c => c?.ToString() == "-p:LibTfm=" + tfm) && File.Exists(Path.Combine(path, "output.log"));
             matrix[tfm] = new JsonObject { ["status"] = valid && tests.Count > 0 && tests.Values.All(x => x == "passed") && !string.IsNullOrEmpty(runtime) ? "passed" : "failed", ["execution"] = run, ["tests"] = Node(tests), ["host_runtime"] = runtime, ["trx"] = Path.GetRelativePath(directory, files[0]) };
@@ -194,6 +199,22 @@ public JsonObject Aggregate(string directory, SourceIdentity expected)
             }
             catch (Exception e) when (e is not OutOfMemoryException) { leases["status"] = "failed"; errors.Add("Lease experiment: " + e.Message); }
         }
+        var retention = new JsonObject { ["status"] = "not-run" };
+        receipt["retention_experiment"] = retention;
+        if (jobs.ContainsKey("controlled"))
+        {
+            try
+            {
+                Require(Passed(jobs["controlled"]?["runs"]?["retention"]), "unsuccessful retention command");
+                var directoryPath = Path.Combine(directory, "controlled/retention");
+                var report = Read(Path.Combine(directoryPath, "results.json"));
+                Require(Equal(report["source"], Node(expected)) && Equal(report["source_after"], Node(expected)) && Equal(report["ci"], jobs["controlled"]?["ci"]), "retention source/CI mismatch");
+                Require(S(report, "status") == "passed", "Incomplete lease report");
+                ValidateRetentionReport(directoryPath, report, expected.SourceHashes);
+                retention["status"] = "passed"; retention["evidence"] = report;
+            }
+            catch (Exception e) when (e is not OutOfMemoryException) { retention["status"] = "failed"; errors.Add("Retention experiment: " + e.Message); }
+        }
         if (jobs.ContainsKey("stryker"))
         {
             try
@@ -323,6 +344,11 @@ public JsonObject Aggregate(string directory, SourceIdentity expected)
                     item["evidence"]!.AsArray().Add("controlled/leases/results.json");
                     if (S(leases, "status") != "passed") item["status"] = S(leases, "status");
                 }
+                if (o.Id == "REASSEMBLY-001-TEST")
+                {
+                    item["evidence"]!.AsArray().Add("controlled/retention/results.json");
+                    if (S(retention, "status") != "passed") item["status"] = S(retention, "status");
+                }
                 if (o.Id == "CLOSE-004-CONTROLLED")
                 {
                     item["evidence"]!.AsArray().Add("controlled/defect/results.json");
diff --git a/tools/Pdd/Evidence.cs b/tools/Pdd/Evidence.cs
index bbf06dc..ed788c7 100644
--- a/tools/Pdd/Evidence.cs
+++ b/tools/Pdd/Evidence.cs
@@ -20,7 +20,7 @@ public async Task<SourceIdentity> Identity()
     }
     public static List<(string Name, string[] Command)> Commands(string job, string output) => job == "stryker" ?
         [("runtime", ["dotnet", "test", Project, "-c", "Release", "-p:LibTfm=net10.0", "--filter", "FullyQualifiedName=" + RuntimeTest, "--logger", "trx;LogFileName=runtime.trx", "--results-directory", Path.Combine(output, "runtime")]), ("stryker", ["./scripts/stryker-close.sh"])] : job == "controlled" ?
-        [("defect", ["./scripts/pdd.sh", "controlled-defect", "--output", Path.Combine(output, "defect")]), ("boundaries", ["./scripts/pdd.sh", "boundary-defects", "--output", Path.Combine(output, "boundaries")]), ("queued", ["./scripts/pdd.sh", "queued-defect", "--output", Path.Combine(output, "queued")]), ("leases", ["./scripts/pdd.sh", "lease-defects", "--output", Path.Combine(output, "leases")])] : job == "protocol" ?
+        [("defect", ["./scripts/pdd.sh", "controlled-defect", "--output", Path.Combine(output, "defect")]), ("boundaries", ["./scripts/pdd.sh", "boundary-defects", "--output", Path.Combine(output, "boundaries")]), ("queued", ["./scripts/pdd.sh", "queued-defect", "--output", Path.Combine(output, "queued")]), ("leases", ["./scripts/pdd.sh", "lease-defects", "--output", Path.Combine(output, "leases")]), ("retention", ["./scripts/pdd.sh", "retention-defects", "--output", Path.Combine(output, "retention")])] : job == "protocol" ?
         [("manifest", ["./scripts/pdd.sh", "validate"]), ("fixtures", ["dotnet", "test", "tools/Pdd.Tests/Pdd.Tests.csproj", "-c", "Release", "--nologo"]), ("proof", ["./scripts/dafny-masking.sh", "--check"]), ("mutations", ["./scripts/pdd.sh", "mutations", "--output", Path.Combine(output, "mutations")])] :
         [("restore", ["dotnet", "restore", "src/main/WebsocketClientLite.sln"]), ("build", ["dotnet", "build", "src/main/WebsocketClientLite.sln", "--configuration", "Release", "--no-restore"]), ("matrix", ["./test-all-tfms.sh", "Release"]), ("coverage-run", ["dotnet", "test", Project, "--configuration", "Release", "--collect:XPlat Code Coverage", "--results-directory", Path.Combine(output, "coverage")]), ("coverage-gate", ["./scripts/check-coverage.sh", Path.Combine(output, "coverage"), "70"])];
     public async Task<CommandReceipt> Execute(string[] command, string output, double budget = 1800, CancellationToken cancellation = default)
diff --git a/tools/Pdd/Program.cs b/tools/Pdd/Program.cs
index f370c57..70a22a8 100644
--- a/tools/Pdd/Program.cs
+++ b/tools/Pdd/Program.cs
@@ -23,7 +23,7 @@ public static async Task<int> Main(string[] args)
         try
         {
             if (args.Length == 0)
-                throw new ArgumentException("Usage: pdd <validate|contract-report|mutations|capture|test-target|aggregate|controlled-defect|boundary-defects|queued-defect|queued-probe|lease-defects|lease-probe|stryker-triage|normalize-generated> [options]");
+                throw new ArgumentException("Usage: pdd <validate|contract-report|mutations|capture|test-target|aggregate|controlled-defect|boundary-defects|queued-defect|queued-probe|lease-defects|lease-probe|retention-defects|stryker-triage|normalize-generated> [options]");
             var root = FindRoot();
             var options = new Dictionary<string, string>();
             var positionals = new List<string>();
@@ -81,6 +81,9 @@ void Allow(params string[] names)
                 case "boundary-defects":
                     Allow("--output");
                     return await evidence.BoundaryDefects(output, cancellation.Token);
+                case "retention-defects":
+                    Allow("--output");
+                    return await evidence.RetentionDefects(output, cancellation.Token);
                 case "lease-defects":
                     Allow("--output");
                     return await evidence.LeaseDefects(output, cancellation.Token);
diff --git a/tools/Pdd/README.md b/tools/Pdd/README.md
index 8d85faf..6238d37 100644
--- a/tools/Pdd/README.md
+++ b/tools/Pdd/README.md
@@ -173,3 +173,9 @@ P3-B adds `lease-defects --output <fresh-directory>` to controlled capture and
 isolated early-return, missing-return and wrong-count edits must fail their named
 assertions; aggregate checks exact edits/source, all cases, execution and runtime.
 See [sender leases](../../verification/payload-lease-ownership.md).
+
+P3-C adds `retention-defects --output <fresh-directory>` to controlled capture.
+Two isolated control-total and late-scratch edits must fail named assertions;
+aggregation checks Release configuration, exact source/edit, cases, execution and
+runtime. The existing REASSEMBLY-001-TEST adapter obligation includes the new
+five-target tests without expanding its proof. See [parser retention](../../verification/parser-retention.md).
diff --git a/tools/Pdd/RetentionDefects.cs b/tools/Pdd/RetentionDefects.cs
new file mode 100644
index 0000000..96db61e
--- /dev/null
+++ b/tools/Pdd/RetentionDefects.cs
@@ -0,0 +1,121 @@
+using System.Text.Json.Nodes;
+using System.Xml.Linq;
+using static Pdd.Data;
+
+namespace Pdd;
+
+public sealed partial class Evidence
+{
+    public const string RetentionSource = "src/main/WebsocketClientLite/Service/WebsocketParserHandler.cs";
+    public const string HeaderSource = "src/main/WebsocketClientLite/Helper/DataframeParsing.cs";
+    public static readonly Dictionary<string, int> RetentionCaseCounts = new()
+    {
+        ["SmallSequencesPreserveBytesMetadataAndReset"] = 1,
+        ["AccumulatedLimitRejectsBeforePayloadRead"] = 2,
+        ["ControlPayloadDoesNotChangeRetainedTotal"] = 1,
+        ["ExtendedHeaderCapturesScratchBeforeReuse"] = 1,
+        ["HugeLengthsRejectOnHeaderOnly"] = 3,
+        ["IncompleteMessageTerminatesWithoutEmission"] = 2,
+        ["CloseAndInvalidContinuationDoNotLeakRetainedData"] = 1,
+        ["SplitUtf8IsValidatedOnlyWhenComplete"] = 1,
+        ["HandshakeConsumesScratchImmediatelyAndStopsBeforeFrame"] = 1
+    };
+    public static readonly (string Id, string Source, string Before, string After, string Test, string Assertion)[] RetentionCases =
+    [
+        ("control-total", RetentionSource, "total = size;\n                        obs.OnNext(frame);",
+            "total = size + (uint)payload.Length;\n                        obs.OnNext(frame);",
+            "ControlPayloadDoesNotChangeRetainedTotal", "Control payload changed retained budget"),
+        ("late-scratch", HeaderSource, "Protocol.Admit(b0, b1, ext, (uint)count, state, total, (uint)tcpConnection.MaxFrameSize,",
+            "Protocol.Admit(header[0], header[1], ext, (uint)count, state, total, (uint)tcpConnection.MaxFrameSize,",
+            "ExtendedHeaderCapturesScratchBeforeReuse", "Header scratch capture corrupted admission")
+    ];
+    public async Task<int> RetentionDefects(string output, CancellationToken cancellation)
+    {
+        Fresh(output);
+        var report = new JsonObject { ["status"] = "failed", ["source"] = Node(await Identity()), ["ci"] = Node(CiIdentity()),
+            ["started_at"] = Now(), ["library_target"] = "net10.0", ["experiments"] = new JsonArray() };
+        using var copy = new TemporaryTree();
+        try
+        {
+            // Restrict to repository inputs; unrelated untracked dumps are never copied/read.
+            var paths = (await ContractReport.Git(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard",
+                "src", "verification", "tools", "scripts", ".config", "global.json", "Directory.Build.props", "Directory.Build.targets", "NuGet.config")).Split('\0', StringSplitOptions.RemoveEmptyEntries);
+            foreach (var path in paths.Distinct())
+            {
+                var target = Path.Combine(copy.Path, path);
+                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
+                File.Copy(Path.Combine(root, path), target);
+            }
+            var runner = new Evidence(copy.Path);
+            async Task<CommandReceipt> Run(string name, string filter) => await runner.Execute(
+                ["dotnet", "test", Project, "-c", "Release", "-p:LibTfm=net10.0", "--filter", filter + "|FullyQualifiedName=" + RuntimeTest,
+                    "--logger", "trx;LogFileName=results.trx", "--results-directory", Path.Combine(output, name)], Path.Combine(output, name), 180, cancellation);
+            report["baseline"] = Node(await Run("baseline", "FullyQualifiedName~WebsocketClientLiteTest.ParserRetentionTests"));
+            Require(Passed(report["baseline"]), "Retention baseline failed");
+            foreach (var c in RetentionCases)
+            {
+                var file = Path.Combine(copy.Path, c.Source);
+                var original = Text(file);
+                var name = c.Id;
+                var index = original.IndexOf(c.Before, StringComparison.Ordinal);
+                Require(index >= 0 && original.IndexOf(c.Before, index + 1, StringComparison.Ordinal) < 0, "Ambiguous/missing retention edit");
+                File.WriteAllText(file, original[..index] + c.After + original[(index + c.Before.Length)..]);
+                var run = await Run(name, "FullyQualifiedName=WebsocketClientLiteTest.ParserRetentionTests." + c.Test);
+                var experiment = new JsonObject { ["id"] = name, ["status"] = "failed", ["test"] = c.Test, ["assertion"] = c.Assertion,
+                    ["source_hash"] = Hash(System.Text.Encoding.UTF8.GetBytes(original)), ["mutant_hash"] = Hash(File.ReadAllBytes(file)),
+                    ["before"] = c.Before, ["after"] = c.After, ["run"] = Node(run) };
+                report["experiments"]!.AsArray().Add(experiment);
+                experiment["host_runtime"] = ValidateRetentionResult(Path.Combine(output, name), Node(run), c.Test, c.Assertion);
+                experiment["status"] = "passed";
+                File.WriteAllText(file, original);
+            }
+            report["status"] = "passed";
+            ValidateRetentionReport(output, report, (await Identity()).SourceHashes);
+        }
+        catch (Exception e) when (e is not OutOfMemoryException) { report["status"] = "failed"; report["error"] = e.Message; }
+        finally { report["finished_at"] = Now(); report["source_after"] = Node(await Identity()); Save(Path.Combine(output, "results.json"), report); }
+        return S(report, "status") == "passed" ? 0 : 1;
+    }
+
+    public static void ValidateRetentionReport(string directory, JsonNode report, IReadOnlyDictionary<string, string?> sourceHashes)
+    {
+        Require(S(report, "status") == "passed" && S(report, "library_target") == "net10.0" && Passed(report["baseline"]), "Incomplete retention baseline/report");
+        XNamespace ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+        var baseline = XDocument.Load(Path.Combine(directory, "baseline/results.trx")).Descendants(ns + "UnitTestResult").ToArray();
+        Require(baseline.Length == 14 && baseline.All(r => (string?)r.Attribute("outcome") == "Passed"), "Incomplete retention baseline cases");
+        foreach (var (test, count) in RetentionCaseCounts)
+            Require(baseline.Count(r => ((string?)r.Attribute("testName"))?.Contains("ParserRetentionTests." + test, StringComparison.Ordinal) == true) == count, "Missing named retention baseline case");
+        ValidateRetentionExecution(Path.Combine(directory, "baseline"), 0);
+        RequireRetentionCommand(report["baseline"]!);
+        var baselineRuntime = baseline.Single(r => ((string?)r.Attribute("testName"))?.EndsWith("RecordHostRuntime", StringComparison.Ordinal) == true).Value;
+        var entries = report["experiments"]!.AsArray();
+        Require(entries.Count == 2, "Missing retention experiments or repetitions");
+        foreach (var c in RetentionCases)
+        {
+            var name = c.Id;
+            var e = entries.Single(e => S(e, "id") == name)!;
+            Require(S(e, "status") == "passed" && S(e, "source_hash") == sourceHashes[c.Source] && S(e, "mutant_hash").Length == 64 && S(e, "mutant_hash") != sourceHashes[c.Source], "Retention mutation identity mismatch");
+            Require(S(e, "before") == c.Before && S(e, "after") == c.After && S(e, "test") == c.Test && S(e, "assertion") == c.Assertion, "Retention experiment contract mismatch");
+            var runtime = ValidateRetentionResult(Path.Combine(directory, name), e["run"]!, c.Test, c.Assertion);
+            Require(S(e, "host_runtime") == runtime && baselineRuntime.Contains("PDD_HOST_RUNTIME=" + runtime, StringComparison.Ordinal), "Retention runtime mismatch");
+        }
+    }
+
+    private static void RequireRetentionCommand(JsonNode run)
+    {
+        var command = run["command"]!.AsArray().Select(x => x!.ToString()).ToArray();
+        int config = Array.IndexOf(command, "-c");
+        Require(config >= 0 && config + 1 < command.Length && command[config + 1] == "Release" && command.Contains("-p:LibTfm=net10.0"), "Retention must use Release/net10.0");
+    }
+    private static void ValidateRetentionExecution(string directory, int code)
+    {
+        var e = Read(Path.Combine(directory, "execution.json"));
+        Require(e["timed_out"]?.GetValue<bool>() == false && e["interrupted"]?.GetValue<bool>() == false && e["launch_error"] is null && e["exit_code"]?.ToString() == code.ToString(), "Invalid retention execution");
+    }
+    private static string ValidateRetentionResult(string directory, JsonNode run, string test, string assertion)
+    {
+        RequireRetentionCommand(run);
+        ValidateRetentionExecution(directory, 1);
+        return ValidateBoundaryResult(Path.Combine(directory, "results.trx"), run, test, assertion, 1);
+    }
+}
diff --git a/verification/boundaries.json b/verification/boundaries.json
index 29ed462..bd8bdfb 100644
--- a/verification/boundaries.json
+++ b/verification/boundaries.json
@@ -205,6 +205,10 @@
         {
           "file": "src/main/WebsocketClientLite/Helper/VerifiedNativeCopy.cs",
           "symbol": "WebsocketClientLite.VerifiedProtocol.NativeCopy.CopySlice"
+        },
+        {
+          "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+          "symbol": "WebsocketClientLiteTest.ParserRetentionTests.SmallSequencesPreserveBytesMetadataAndReset"
         }
       ],
       "requirements": [
@@ -241,6 +245,10 @@
         {
           "file": "src/main/WebsocketClientLiteTest/PayloadBoundaryTests.cs",
           "symbol": "WebsocketClientLiteTest.PayloadBoundaryTests.MergeVariantsPreserveAliasedSegmentsAndReturnFreshStorage"
+        },
+        {
+          "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+          "symbol": "WebsocketClientLiteTest.ParserRetentionTests.SmallSequencesPreserveBytesMetadataAndReset"
         }
       ],
       "requirements": [
diff --git a/verification/close-intent-review.md b/verification/close-intent-review.md
index 1af2b40..7f6fa3b 100644
--- a/verification/close-intent-review.md
+++ b/verification/close-intent-review.md
@@ -225,6 +225,10 @@ No concurrent caller mutation or proof of C# ownership; aliased retained segment
 Callers provide the exact retained-byte total within Size bounds; empty payload segments do not change that sum.
 
 The parser total and retained segment list are C# bookkeeping, not verified by the Merge proof.
+P3-C adds [production adapter evidence](parser-retention.md) for finite retained
+sequences, byte limits and sequential handshake/header scratch consumption. It
+keeps the single-reader and stable-input assumptions; machine tests do not
+constitute human acceptance of those boundaries.
 
 <a id="boundary-native-copy"></a>
 ### NATIVE-COPY
diff --git a/verification/parser-retention.md b/verification/parser-retention.md
new file mode 100644
index 0000000..b7b62f2
--- /dev/null
+++ b/verification/parser-retention.md
@@ -0,0 +1,69 @@
+# Parser retention and scratch ownership (P3-C)
+
+This is tested C# adapter evidence for REASSEMBLY-TOTALS and PAYLOAD-OWNERSHIP,
+not an extension of the Merge proof. The production parser, header reader and
+handshake reader are unchanged. The specification is P3-C in planning commit
+78966de (`docs/pdd-phase-3-plan.md`), read from the planning branch; the release
+baseline is 77af6c5, containing G and merged A/B.
+
+`ParserRetentionTests` uses the existing private stream injection convention and
+one-byte stream reads through both target-dependent ReadAsync overloads. There is
+one subscription, after handshake completion. No concurrent reader is supported:
+`ReadHeaderBytesAsync` returns an eight-byte shared scratch array, valid only until
+the next header read. Handshake consumes each byte synchronously; header parsing
+captures b0/b1 before the extended-length read overwrites the array. Payload reads
+allocate distinct storage. Retained payloads stay stable until emission; the
+one-segment fast path reuses its payload, so fresh output is not promised for
+all parser messages. No new pool/copying policy is introduced.
+
+The expected bytes come from literal input arrays and LINQ concatenation, never
+from Protocol.Step, Admit, Merge or a production encoder. The wire builder handles
+only the small literal frames used here; extended headers are literal bytes.
+
+- 54 combinations: Text/Binary, three fragment lengths each in 0..2, interleaved
+  Ping/Pong, empty continuations, then consecutive Binary and empty Text messages.
+  Checks bytes, Length, FIN, Fragment and original opcode, covering zero/one/many
+  nonempty retained arrays and reset without stale data.
+- Limits 1 and 4: each retained prefix 0..N, complete totals N−1/N/N+1 where
+  possible, empty continuation and both control payloads. Successful output and
+  the next admission's remaining budget observe retained totals. Rejected payloads
+  are present in the input; exact read-attempt and byte counts prove rejection
+  before their consumption, not an accidental EOF failure.
+- Header-only rejection at int.MaxValue plus a retained byte, int.MaxValue+1,
+  and the forbidden 64-bit high bit; no enormous allocation is attempted.
+- Close abort, orphan continuation before/after a completed message, EOF and
+  cancellation at next header, partial extended header and partial payload.
+  Cancellation here is the transport's OperationCanceledException outcome; these
+  cases do not claim exhaustive subscription-disposal scheduling.
+- Split UTF-8 succeeds only after complete assembly; an invalid final byte fails
+  without emitting partial data. The control can still be observed first.
+- A real production handshake, with its random request key answered by the test
+  writer, stops exactly at the HTTP terminator before parsing the adjacent frame.
+  A canonical 126-byte frame checks base-header capture across scratch reuse.
+
+`retention-defects` uses isolated source copies and the existing PDD process/TRX
+validators. It first passes all 13 cases plus the runtime probe, then requires:
+
+| Edit | Test | Required assertion |
+| --- | --- | --- |
+| Add control payload length to retained total | ControlPayloadDoesNotChangeRetainedTotal | Control payload changed retained budget |
+| Use header[0]/header[1] after extended read instead of captured b0/b1 | ExtendedHeaderCapturesScratchBeforeReuse | Header scratch capture corrupted admission |
+
+These faults are non-equivalent: one corrupts inter-frame size accounting; the
+other consumes overwritten header storage within a frame. Compile failures,
+timeouts, interruption, missing TRX/cases, survival, wrong edits/source/runtime,
+and unrelated assertions do not count. Release/net10.0 is checked explicitly.
+Controlled capture and aggregation require both detections; all five library
+matrix cells require the named adapter tests under REASSEMBLY-001-TEST. Existing
+G/A/B experiments and F Merge/native/masking tests remain required unchanged.
+
+No genuine production defect has been reproduced in this increment. Artificial
+negative edits are evidence checks, not reports of shipping defects.
+
+Limits: finite small sequences and selected admission boundaries; no arbitrary
+schedule, full RFC, memory-model, native-copy, Rx/runtime or allocation proof.
+Single-reader discipline and external stream behavior remain trusted. Byte caps
+do not bound fragment/object count or total process memory; no fragment-count
+policy is added. Internal locals are not introspected: total/list agreement is
+observed via emitted bytes/metadata and subsequent admission/read budgets.
+Human acceptance of these assumptions remains revision-bound PR review.
diff --git a/verification/requirements.json b/verification/requirements.json
index 956fd82..3a81dcb 100644
--- a/verification/requirements.json
+++ b/verification/requirements.json
@@ -535,7 +535,7 @@
           "id": "REASSEMBLY-001-TEST",
           "kind": "test",
           "delivery": "existing",
-          "description": "Require these independent byte, adapter or loopback tests on every supported library target; tests do not prove all inputs.",
+          "description": "Require these independent byte, adapter or loopback tests on every supported library target; tests do not prove all inputs. P3-C also requires tested-only parser retention/scratch adapters and two isolated C# defects; this does not expand the Merge proof.",
           "references": [
             {
               "file": "src/main/WebsocketClientLiteTest/ProtocolStateTests.cs",
@@ -552,6 +552,42 @@
             {
               "file": "src/main/WebsocketClientLiteTest/IntegrationTests.cs",
               "symbol": "WebsocketClientLiteTest.IntegrationTests.Reassembles_ServerFragmentedMessage_EndToEnd"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.SmallSequencesPreserveBytesMetadataAndReset"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.AccumulatedLimitRejectsBeforePayloadRead"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.ControlPayloadDoesNotChangeRetainedTotal"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.ExtendedHeaderCapturesScratchBeforeReuse"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.HugeLengthsRejectOnHeaderOnly"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.IncompleteMessageTerminatesWithoutEmission"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.CloseAndInvalidContinuationDoNotLeakRetainedData"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.SplitUtf8IsValidatedOnlyWhenComplete"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/ParserRetentionTests.cs",
+              "symbol": "WebsocketClientLiteTest.ParserRetentionTests.HandshakeConsumesScratchImmediatelyAndStopsBeforeFrame"
             }
           ]
         },
```


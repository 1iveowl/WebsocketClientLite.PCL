# Contract-change review report

- Target commit: `d5edabbc148001f8fdc9cafe6f6ac8e09d8e57be`
- Compared head: `6e95ce1a66f61a8c62dc04c38aa8a07803e0b9ea`
- Merge base: `d5edabbc148001f8fdc9cafe6f6ac8e09d8e57be`

**Semantic review required.**

This is a textual comparison, not a proof of equivalence or a weakening detector. Review stronger preconditions, weaker postconditions, helper definitions and expanded trust. Normal PR review must record the accepted decision and reviewed head revision; a committed approval flag is not evidence.

Only committed trees are compared. Uncommitted/untracked files are excluded. The full source diff includes changes outside the summaries. No verifier or tests run here.

## Requirement intent

No textual changes.

## Boundary register

No textual changes.

## Machine-compared external-contract audit

No textual changes.

## Full source diff

```diff
diff --git a/.github/workflows/ci.yml b/.github/workflows/ci.yml
index 85bd66e..da67a43 100644
--- a/.github/workflows/ci.yml
+++ b/.github/workflows/ci.yml
@@ -13,12 +13,18 @@ on:
     paths:
       - "GitVersion.yml"
   workflow_dispatch:
+    inputs:
+      host_qualification:
+        description: 'Manual P3-E host qualification only (does not satisfy release evidence)'
+        type: boolean
+        default: false
 
 env:
   PDD_PR_HEAD: ${{ github.event.pull_request.head.sha }}
 
 jobs:
   verify-protocol:
+    if: ${{ !inputs.host_qualification }}
     runs-on: ubuntu-22.04
     steps:
       - uses: actions/checkout@v4
@@ -69,7 +75,8 @@ jobs:
           if-no-files-found: error
 
   build-and-test:
-    runs-on: ubuntu-latest
+    if: ${{ !inputs.host_qualification }}
+    runs-on: ubuntu-24.04
     steps:
       - name: Checkout
         uses: actions/checkout@v4
@@ -100,7 +107,8 @@ jobs:
           if-no-files-found: error
 
   controlled-close:
-    runs-on: ubuntu-latest
+    if: ${{ !inputs.host_qualification }}
+    runs-on: ubuntu-24.04
     timeout-minutes: 10
     steps:
       - uses: actions/checkout@v4
@@ -117,7 +125,8 @@ jobs:
           if-no-files-found: error
 
   stryker-close:
-    runs-on: ubuntu-latest
+    if: ${{ !inputs.host_qualification }}
+    runs-on: ubuntu-24.04
     timeout-minutes: 40
     steps:
       - uses: actions/checkout@v4
@@ -134,9 +143,9 @@ jobs:
           if-no-files-found: error
 
   evidence-gate:
-    if: always()
+    if: ${{ always() && !inputs.host_qualification }}
     needs: [verify-protocol, build-and-test, controlled-close, stryker-close]
-    runs-on: ubuntu-latest
+    runs-on: ubuntu-24.04
     steps:
       - uses: actions/checkout@v4
       - uses: actions/setup-dotnet@v4
@@ -169,3 +178,54 @@ jobs:
             artifacts/pdd/controlled/
             artifacts/pdd/stryker/
           if-no-files-found: error
+
+  qualify-host:
+    if: ${{ github.event_name == 'workflow_dispatch' && inputs.host_qualification }}
+    strategy:
+      fail-fast: false
+      matrix:
+        repetition: [1, 2]
+        host:
+          - { runner: ubuntu-24.04, prefix: linux-10, runtime: '10.0.x', targets: 'netstandard2.0,netstandard2.1,net8.0,net9.0,net10.0' }
+          - { runner: windows-2022, prefix: windows-10, runtime: '10.0.x', targets: 'net10.0,netstandard2.0' }
+          - { runner: macos-15, prefix: macos-10, runtime: '10.0.x', targets: 'net10.0,netstandard2.0' }
+    runs-on: ${{ matrix.host.runner }}
+    env:
+      # Hash the same source bytes on all hosts, including Windows checkout.
+      GIT_CONFIG_COUNT: '2'
+      GIT_CONFIG_KEY_0: core.autocrlf
+      GIT_CONFIG_VALUE_0: 'false'
+      GIT_CONFIG_KEY_1: core.eol
+      GIT_CONFIG_VALUE_1: lf
+    timeout-minutes: 10
+    steps:
+      - uses: actions/checkout@v4
+      - uses: actions/setup-dotnet@v4
+        with:
+          dotnet-version: 10.0.x
+      - name: Build receipt tooling
+        run: dotnet build tools/Pdd/Pdd.csproj -c Release
+      - name: Check host receipts and process log readback
+        run: dotnet test tools/Pdd.Tests/Pdd.Tests.csproj -c Release --filter "FullyQualifiedName~HostEvidenceTests|FullyQualifiedName~CaptureReadback"
+      - name: Qualify actual host cells
+        shell: pwsh
+        env:
+          CELL_PREFIX: ${{ matrix.host.prefix }}
+          LIBRARY_TARGETS: ${{ matrix.host.targets }}
+        run: |
+          $failed = $false
+          $cells = @()
+          foreach ($tfm in $env:LIBRARY_TARGETS.Split(',')) {
+            $cell = "$env:CELL_PREFIX-$tfm"
+            $cells += $cell
+            dotnet tools/Pdd/bin/Release/net10.0/Pdd.dll test-host --cell $cell --output "artifacts/hosts/$cell"
+            if ($LASTEXITCODE -ne 0) { $failed = $true }
+          }
+          dotnet tools/Pdd/bin/Release/net10.0/Pdd.dll aggregate --host-cells ($cells -join ',') --output artifacts/hosts
+          if ($LASTEXITCODE -ne 0 -or $failed) { exit 1 }
+      - uses: actions/upload-artifact@v4
+        if: always()
+        with:
+          name: hosts-${{ matrix.host.prefix }}-${{ matrix.repetition }}
+          path: artifacts/hosts/
+          if-no-files-found: error
diff --git a/src/main/WebsocketClientLiteTest/RuntimeEvidenceTests.cs b/src/main/WebsocketClientLiteTest/RuntimeEvidenceTests.cs
index 8f35d6f..897269e 100644
--- a/src/main/WebsocketClientLiteTest/RuntimeEvidenceTests.cs
+++ b/src/main/WebsocketClientLiteTest/RuntimeEvidenceTests.cs
@@ -1,4 +1,11 @@
+using System;
+using System.IO;
+using System.Reflection;
 using System.Runtime.InteropServices;
+using System.Runtime.Versioning;
+using System.Security.Cryptography;
+using System.Text.Json;
+using WebsocketClientLite;
 using Xunit;
 using Xunit.Abstractions;
 
@@ -12,6 +19,27 @@ public class RuntimeEvidenceTests
     public RuntimeEvidenceTests(ITestOutputHelper output) => _output = output;
 
     [Fact]
-    public void RecordHostRuntime() =>
+    public void RecordHostRuntime()
+    {
+        var library = typeof(ClientWebSocketRx).Assembly;
+        var os = OperatingSystem.IsWindows() ? "windows" : OperatingSystem.IsMacOS() ? "macos" : "linux";
         _output.WriteLine("PDD_HOST_RUNTIME=" + RuntimeInformation.FrameworkDescription);
+        _output.WriteLine("PDD_HOST_IDENTITY=" + JsonSerializer.Serialize(new
+        {
+            runtime = RuntimeInformation.FrameworkDescription,
+            runtime_version = Environment.Version.ToString(),
+            test_framework = typeof(RuntimeEvidenceTests).Assembly.GetCustomAttribute<TargetFrameworkAttribute>()!.FrameworkName,
+            os,
+            os_description = RuntimeInformation.OSDescription,
+            os_version = Environment.OSVersion.VersionString,
+            os_release = OperatingSystem.IsLinux() ? File.ReadAllText("/etc/os-release") : "",
+            os_architecture = RuntimeInformation.OSArchitecture.ToString(),
+            process_architecture = RuntimeInformation.ProcessArchitecture.ToString(),
+            library_framework = library.GetCustomAttribute<TargetFrameworkAttribute>()!.FrameworkName,
+            library_name = library.FullName,
+            library_path = library.Location,
+            library_sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(library.Location))).ToLowerInvariant(),
+            library_mvid = library.ManifestModule.ModuleVersionId.ToString()
+        }));
+    }
 }
diff --git a/src/main/WebsocketClientLiteTest/WebsocketClientLiteTest.csproj b/src/main/WebsocketClientLiteTest/WebsocketClientLiteTest.csproj
index 98221f6..da1d4cd 100644
--- a/src/main/WebsocketClientLiteTest/WebsocketClientLiteTest.csproj
+++ b/src/main/WebsocketClientLiteTest/WebsocketClientLiteTest.csproj
@@ -1,7 +1,9 @@
-﻿<Project Sdk="Microsoft.NET.Sdk">
+<Project Sdk="Microsoft.NET.Sdk">
 
   <PropertyGroup>
-    <TargetFramework>net10.0</TargetFramework>
+    <TestHostTfm Condition="'$(TestHostTfm)' == ''">net10.0</TestHostTfm>
+    <TargetFramework>$(TestHostTfm)</TargetFramework>
+    <RollForward>LatestPatch</RollForward>
     <Nullable>enable</Nullable>
 
     <IsPackable>false</IsPackable>
diff --git a/tools/Pdd.Tests/HostEvidenceTests.cs b/tools/Pdd.Tests/HostEvidenceTests.cs
new file mode 100644
index 0000000..0b5ca30
--- /dev/null
+++ b/tools/Pdd.Tests/HostEvidenceTests.cs
@@ -0,0 +1,159 @@
+using System.Text.Json.Nodes;
+using System.Xml.Linq;
+using Pdd;
+using Xunit;
+
+namespace Pdd.Tests;
+
+public class HostEvidenceTests
+{
+    static HostCell Cell => Evidence.FindHostCell("linux-10-net10.0");
+    static SourceIdentity Source => new("revision", null, false, new() { ["source.cs"] = "hash" });
+    static JsonNode Host => Data.Parse("""
+        {"runtime":".NET 10.0.14","runtime_version":"10.0.14","test_framework":".NETCoreApp,Version=v10.0",
+         "os":"linux","os_description":"Ubuntu 24.04.1 LTS","os_version":"Unix 6.8.0.0","os_release":"ID=ubuntu\nVERSION_ID=\"24.04\"\n",
+         "os_architecture":"X64","process_architecture":"X64","library_framework":".NETCoreApp,Version=v10.0",
+         "library_name":"WebsocketClientLite, Version=1.0.0.0","library_path":"/checkout/bin/WebsocketClientLite.dll",
+         "library_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","library_mvid":"dcac2be4-d8bc-40f8-be82-b8f8f39f728c"}
+        """);
+    static void Fixture(string root, JsonNode host)
+    {
+        var directory = Path.Combine(root, Cell.Id);
+        var target = Path.Combine(directory, "tests", Cell.LibraryTfm);
+        Directory.CreateDirectory(target);
+        File.WriteAllText(Path.Combine(directory, "expected-library.dll"), "fixture assembly bytes");
+        host["library_sha256"] = Data.Hash(File.ReadAllBytes(Path.Combine(directory, "expected-library.dll")));
+        var report = new JobReceipt { Job = Cell.Id, Source = Source, SourceAfter = Source, FinishedAt = Data.Now() };
+        report.Tools["cell"] = Data.Node(Cell);
+        foreach (var name in new[] { "sdk", "restore", "build", "test" })
+        {
+            var path = name == "test" ? target : Path.Combine(directory, name);
+            Directory.CreateDirectory(path);
+            var command = new[] { "dotnet", name, "-p:LibTfm=net10.0", "-p:TestHostTfm=net10.0", "-c", "Release" };
+            var run = new CommandReceipt { Command = command, Status = "passed", ExitCode = 0, StartedAt = Data.Now(), FinishedAt = Data.Now() };
+            report.Runs[name] = run;
+            Data.Save(Path.Combine(path, "run.json"), run);
+            Data.Save(Path.Combine(path, "execution.json"), new ExecutionResult { Command = command, ExitCode = 0, ElapsedSeconds = 1 });
+            File.WriteAllText(Path.Combine(path, "output.log"), "fixture");
+        }
+        Data.Save(Path.Combine(directory, "job.json"), report);
+        XNamespace ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+        var definitions = new XElement(ns + "TestDefinitions");
+        var results = new XElement(ns + "Results");
+        void Add(string name, int count, string? output = null)
+        {
+            var id = definitions.Elements().Count().ToString();
+            var split = name.LastIndexOf('.');
+            definitions.Add(new XElement(ns + "UnitTest", new XAttribute("id", id), new XElement(ns + "TestMethod", new XAttribute("className", name[..split]), new XAttribute("name", name[(split + 1)..]))));
+            for (var i = 0; i < count; i++)
+                results.Add(new XElement(ns + "UnitTestResult", new XAttribute("testId", id), new XAttribute("outcome", "Passed"), new XElement(ns + "Output", new XElement(ns + "StdOut", output))));
+        }
+        foreach (var (prefix, cases) in new[] { ("QueuedWriteTests.", Evidence.QueuedCaseCounts), ("PayloadLeaseTests.", Evidence.LeaseCaseCounts), ("ParserRetentionTests.", Evidence.RetentionCaseCounts), ("ReconnectTests.", Evidence.ReconnectCaseCounts) })
+            foreach (var (name, count) in cases) Add("WebsocketClientLiteTest." + prefix + name, count);
+        Add("WebsocketClientLiteTest.RuntimeEvidenceTests.RecordHostRuntime", 1, "PDD_HOST_RUNTIME=" + host["runtime"] + "\nPDD_HOST_IDENTITY=" + host.ToJsonString());
+        Add("Fixture.OtherSuite", 269 - results.Elements().Count());
+        new XDocument(new XElement(ns + "TestRun", definitions, results)).Save(Path.Combine(target, "results.trx"));
+    }
+    [Fact]
+    public async Task CaptureReadbackClosesWritersBeforeReading()
+    {
+        using var tree = new TemporaryTree();
+        var result = await Processes.Run(["dotnet", "--version"], RequirementsTests.Root, tree.Path, 30);
+        Assert.True(result.Success, result.Stderr);
+        Assert.Equal(Data.Text(Path.Combine(tree.Path, "stdout.log")), result.Stdout);
+        Assert.NotEmpty(result.Stdout);
+    }
+    [Theory]
+    [InlineData("macos-10-net10.0", "macos", "macOS 15.8.2", "Unix 15.8.2", "Arm64")]
+    [InlineData("windows-10-net10.0", "windows", "Microsoft Windows 10.0.20348", "Microsoft Windows NT 10.0.20348.0", "X64")]
+    public void RecognizesQualifiedOsVersionFormats(string id, string os, string description, string version, string arch)
+    {
+        var host = Host;
+        host["os"] = os; host["os_description"] = description; host["os_version"] = version;
+        host["os_architecture"] = arch; host["process_architecture"] = arch;
+        Evidence.ValidateHostIdentity(Evidence.FindHostCell(id), host, ".NET 10.0.14");
+    }
+    [Fact]
+    public void PositiveSourceBoundHostReceipt()
+    {
+        using var tree = new TemporaryTree();
+        Fixture(tree.Path, Host);
+        var receipt = Evidence.HostResults(tree.Path, Source, Data.Node(Evidence.CiIdentity()), [Cell]);
+        Assert.True(receipt["gate"]!["status"]!.ToString() == "passed", receipt.ToJsonString());
+    }
+    [Theory]
+    [InlineData("runtime_version", "9.0.22", "runtime")]
+    [InlineData("test_framework", ".NETCoreApp,Version=v9.0", "host target")]
+    [InlineData("library_framework", ".NETStandard,Version=v2.0", "library target")]
+    [InlineData("os", "windows", "OS/architecture")]
+    [InlineData("os_release", "ID=ubuntu\nVERSION_ID=\"22.04\"", "OS release")]
+    [InlineData("process_architecture", "Arm64", "OS/architecture")]
+    [InlineData("library_path", "", "library identity")]
+    [InlineData("library_mvid", "", "library identity")]
+    public void RejectWrongHostOrAssembly(string key, string value, string reason)
+    {
+        using var tree = new TemporaryTree();
+        var host = Host; host[key] = value;
+        Fixture(tree.Path, host);
+        var receipt = Evidence.HostResults(tree.Path, Source, Data.Node(Evidence.CiIdentity()), [Cell]);
+        Assert.Equal("failed", receipt["gate"]!["status"]!.ToString());
+        Assert.Contains(Cell.Id, receipt["errors"]!.ToString());
+        Assert.Contains(reason, receipt["errors"]!.ToString());
+    }
+    [Theory]
+    [InlineData("missing", "Could not find")]
+    [InlineData("source", "source mismatch")]
+    [InlineData("after", "source mismatch")]
+    [InlineData("attempt", "run/attempt")]
+    [InlineData("run", "run/attempt")]
+    [InlineData("assembly", "assembly hash")]
+    [InlineData("timeout", "timed out")]
+    [InlineData("restore", "restore did not pass")]
+    [InlineData("duplicate", "duplicate cell")]
+    public void RejectMissingMixedOrFailedEvidence(string mode, string reason)
+    {
+        using var tree = new TemporaryTree();
+        Fixture(tree.Path, Host);
+        var directory = Path.Combine(tree.Path, Cell.Id);
+        var path = Path.Combine(directory, "job.json");
+        var report = Data.Read(path);
+        switch (mode)
+        {
+            case "source": report["source"]!["tested_commit"] = "stale"; break;
+            case "after": report["source_after"]!["source_hashes"]!["source.cs"] = "changed"; break;
+            case "attempt": report["ci"]!["GITHUB_RUN_ATTEMPT"] = "other"; break;
+            case "run": report["ci"]!["GITHUB_RUN_ID"] = "other"; break;
+            case "restore": report["runs"]!["restore"]!["status"] = "failed"; break;
+            case "assembly": File.WriteAllText(Path.Combine(directory, "expected-library.dll"), "substituted"); break;
+            case "timeout":
+                var execution = Path.Combine(directory, "tests/net10.0/execution.json");
+                var data = Data.Read(execution); data["timed_out"] = true; Data.Save(execution, data); break;
+        }
+        Data.Save(path, report);
+        if (mode == "missing") File.Delete(path);
+        var receipt = Evidence.HostResults(tree.Path, Source, Data.Node(Evidence.CiIdentity()), mode == "duplicate" ? [Cell, Cell] : [Cell]);
+        Assert.Equal("failed", receipt["gate"]!["status"]!.ToString());
+        Assert.Contains(Cell.Id, receipt["errors"]!.ToString());
+        Assert.Contains(reason, receipt["errors"]!.ToString());
+    }
+    [Fact]
+    public void ConsistentWrongMajorHostCannotSatisfyCell()
+    {
+        using var tree = new TemporaryTree();
+        var host = Host;
+        host["runtime"] = ".NET 9.0.22"; host["runtime_version"] = "9.0.22";
+        host["test_framework"] = ".NETCoreApp,Version=v9.0";
+        Fixture(tree.Path, host);
+        var receipt = Evidence.HostResults(tree.Path, Source, Data.Node(Evidence.CiIdentity()), [Cell]);
+        Assert.Equal("failed", receipt["gate"]!["status"]!.ToString());
+        Assert.Contains(Cell.Id + ": wrong host runtime", receipt["errors"]!.ToString());
+    }
+    [Fact]
+    public void MissingMandatoryLinuxCellFailsFullAggregate()
+    {
+        using var tree = new TemporaryTree();
+        var receipt = new Evidence(RequirementsTests.Root).Aggregate(tree.Path, Source);
+        Assert.Equal("failed", receipt["gate"]!["status"]!.ToString());
+        Assert.Contains("Missing tests job evidence", receipt["errors"]!.ToString());
+    }
+}
diff --git a/tools/Pdd/Aggregation.cs b/tools/Pdd/Aggregation.cs
index cac6c78..b9909cd 100644
--- a/tools/Pdd/Aggregation.cs
+++ b/tools/Pdd/Aggregation.cs
@@ -35,6 +35,7 @@ public static JsonObject TestResults(string directory)
             var definitions = tree.Descendants(ns + "UnitTest").ToDictionary(e => (string)e.Attribute("id")!, e => e.Element(ns + "TestMethod"));
             var tests = new Dictionary<string, string>();
             string? runtime = null;
+            JsonNode? host = null;
             var caseCounts = new Dictionary<string, int>();
             Dictionary<string, int> severity = new()
             {
@@ -60,6 +61,8 @@ public static JsonObject TestResults(string directory)
                 {
                     var match = Regex.Match(item.Value, @"PDD_HOST_RUNTIME=(.+)");
                     runtime = match.Success ? match.Groups[1].Value.Trim() : null;
+                    var identity = Regex.Match(item.Value, @"PDD_HOST_IDENTITY=(.+)");
+                    if (identity.Success) host = Parse(identity.Groups[1].Value.Trim());
                 }
             }
             foreach (var (name, count) in caseCounts.Where(p => p.Key.StartsWith("WebsocketClientLiteTest.ControlledCloseTests.", StringComparison.Ordinal) || p.Key.StartsWith("WebsocketClientLiteTest.CloseBoundaryTests.", StringComparison.Ordinal)))
@@ -84,7 +87,7 @@ public static JsonObject TestResults(string directory)
             }
             var run = Read(Path.Combine(path, "run.json"));
             var valid = Passed(run) && (run["command"]?.AsArray() ?? []).Any(c => c?.ToString() == "-p:LibTfm=" + tfm) && File.Exists(Path.Combine(path, "output.log"));
-            matrix[tfm] = new JsonObject { ["status"] = valid && tests.Count > 0 && tests.Values.All(x => x == "passed") && !string.IsNullOrEmpty(runtime) ? "passed" : "failed", ["execution"] = run, ["tests"] = Node(tests), ["host_runtime"] = runtime, ["trx"] = Path.GetRelativePath(directory, files[0]) };
+            matrix[tfm] = new JsonObject { ["status"] = valid && tests.Count > 0 && tests.Values.All(x => x == "passed") && !string.IsNullOrEmpty(runtime) ? "passed" : "failed", ["execution"] = run, ["tests"] = Node(tests), ["host_runtime"] = runtime, ["host"] = host, ["case_counts"] = Node(caseCounts), ["trx"] = Path.GetRelativePath(directory, files[0]) };
         }
         return matrix;
     }
@@ -259,6 +262,11 @@ public JsonObject Aggregate(string directory, SourceIdentity expected)
             if (jobs.ContainsKey("tests"))
             {
                 matrix = TestResults(Path.Combine(directory, "tests"));
+                foreach (var cell in HostCells.Where(c => c.Placement == "mandatory"))
+                {
+                    try { ValidateHostIdentity(cell, matrix[cell.LibraryTfm]?["host"], S(matrix[cell.LibraryTfm], "host_runtime")); }
+                    catch (Exception e) when (e is not OutOfMemoryException) { errors.Add(cell.Id + ": " + e.Message); }
+                }
                 if (matrix.Any(p => S(p.Value, "status") != "passed"))
                     errors.Add("Incomplete or unsuccessful framework matrix/runtime evidence");
             }
diff --git a/tools/Pdd/HostEvidence.cs b/tools/Pdd/HostEvidence.cs
new file mode 100644
index 0000000..fcc144f
--- /dev/null
+++ b/tools/Pdd/HostEvidence.cs
@@ -0,0 +1,126 @@
+using System.Text.Json.Nodes;
+using System.Text.RegularExpressions;
+using static Pdd.Data;
+
+namespace Pdd;
+
+// A cell is a test host plus library build, never a LibTfm alias for a runtime.
+public record HostCell(string Id, string HostTfm, string LibraryTfm, string Os, string Architecture, string Placement);
+
+public sealed partial class Evidence
+{
+    public static readonly HostCell[] HostCells =
+    [
+        .. Tfms.Select(t => new HostCell("linux-10-" + t, "net10.0", t, "linux", "X64", "mandatory")),
+        .. new[] { "net10.0", "netstandard2.0" }.Select(t => new HostCell("windows-10-" + t, "net10.0", t, "windows", "X64", "manual-candidate")),
+        .. new[] { "net10.0", "netstandard2.0" }.Select(t => new HostCell("macos-10-" + t, "net10.0", t, "macos", "Arm64", "scheduled-candidate")),
+        new("linux-8-net8.0", "net8.0", "net8.0", "linux", "X64", "manual-transitional"),
+        new("linux-9-net9.0", "net9.0", "net9.0", "linux", "X64", "manual-transitional")
+    ];
+    public static HostCell FindHostCell(string id) => HostCells.SingleOrDefault(c => c.Id == id) ?? throw new ArgumentException("Unknown host cell: " + id);
+    public static string FrameworkName(string tfm) => (tfm.StartsWith("netstandard", StringComparison.Ordinal) ? ".NETStandard,Version=v" + tfm[11..] : ".NETCoreApp,Version=v" + tfm[3..]);
+
+    public static void ValidateHostIdentity(HostCell cell, JsonNode? host, string runtime, string? expectedHash = null)
+    {
+        Require(host is JsonObject, "missing actual host identity");
+        var major = cell.HostTfm[3..].Split('.')[0];
+        Require(Regex.IsMatch(S(host, "runtime_version"), "^" + major + @"\.0\.\d+$") && S(host, "runtime") == runtime && runtime == ".NET " + S(host, "runtime_version"), "wrong host runtime/patch");
+        Require(S(host, "test_framework") == FrameworkName(cell.HostTfm), "wrong test host target");
+        Require(S(host, "os") == cell.Os && S(host, "process_architecture") == cell.Architecture && S(host, "os_architecture") == cell.Architecture, "wrong OS/architecture");
+        Require(S(host, "os_version").Length > 0 && S(host, "os_description").Length > 0, "missing OS version");
+        Require(cell.Os switch
+        {
+            "linux" => Regex.IsMatch(S(host, "os_release"), "(?m)^ID=ubuntu\\r?$") && Regex.IsMatch(S(host, "os_release"), "(?m)^VERSION_ID=\"24\\.04\"\\r?$"),
+            "windows" => S(host, "os_version").Contains("10.0.20348", StringComparison.Ordinal),
+            "macos" => Regex.IsMatch(S(host, "os_description"), @"^macOS 15\.\d+(\.\d+)?$"),
+            _ => false
+        }, "wrong OS release (requires Ubuntu 24.04 / Server 2022 / macOS 15)");
+        Require(S(host, "library_framework") == FrameworkName(cell.LibraryTfm), "wrong loaded library target");
+        Require(S(host, "library_name").StartsWith("WebsocketClientLite, Version=", StringComparison.Ordinal) && S(host, "library_path").Replace('\\', '/').EndsWith("/WebsocketClientLite.dll", StringComparison.Ordinal) && Guid.TryParse(S(host, "library_mvid"), out _), "missing loaded library identity");
+        Require(Regex.IsMatch(S(host, "library_sha256"), "^[a-f0-9]{64}$") && (expectedHash is null || S(host, "library_sha256") == expectedHash), "wrong loaded library assembly hash");
+    }
+
+    public async Task<int> TestHost(string id, string output, double budget, CancellationToken cancellation)
+    {
+        var cell = FindHostCell(id);
+        Fresh(output);
+        var report = new JobReceipt { Job = id, Source = await Identity() };
+        report.Tools["cell"] = Node(cell);
+        report.Tools["runner"] = Node(new[] { "RUNNER_OS", "RUNNER_ARCH", "ImageOS", "ImageVersion", "RUNNER_NAME" }.ToDictionary(k => k, Environment.GetEnvironmentVariable));
+        void SaveReport() => Save(Path.Combine(output, "job.json"), report);
+        SaveReport();
+        var properties = new[] { "-p:TestHostTfm=" + cell.HostTfm, "-p:LibTfm=" + cell.LibraryTfm };
+        var target = Path.Combine(output, "tests", cell.LibraryTfm);
+        var commands = new (string, string[])[]
+        {
+            ("sdk", ["dotnet", "--info"]),
+            ("restore", ["dotnet", "restore", Project, .. properties]),
+            ("build", ["dotnet", "build", Project, "-c", "Release", "--no-restore", .. properties]),
+            ("test", ["dotnet", "test", Project, "-c", "Release", "--no-build", "--no-restore", .. properties, "--logger", "trx;LogFileName=results.trx", "--results-directory", target])
+        };
+        var success = true;
+        try
+        {
+            foreach (var (name, command) in commands)
+            {
+                report.Runs[name] = success ? await Execute(command, name == "test" ? target : Path.Combine(output, name), budget, cancellation) : new CommandReceipt { Command = command, Status = "skipped" };
+                success &= report.Runs[name].Status == "passed";
+                SaveReport();
+                if (name == "build" && success)
+                {
+                    var library = Path.Combine(root, "src/main/WebsocketClientLite/bin/Release", cell.LibraryTfm, "WebsocketClientLite.dll");
+                    File.Copy(library, Path.Combine(output, "expected-library.dll"));
+                }
+                Console.WriteLine($"{id}/{name}: {report.Runs[name].Status}");
+            }
+        }
+        finally { report.SourceAfter = await Identity(); report.FinishedAt = Now(); SaveReport(); }
+        try { ValidateHostCell(output, cell, report.Source, Node(CiIdentity())); }
+        catch (Exception e) when (e is not OutOfMemoryException) { Console.Error.WriteLine(id + ": " + e.Message); return 1; }
+        return success ? 0 : 1;
+    }
+
+    public static JsonNode ValidateHostCell(string directory, HostCell cell, SourceIdentity expected, JsonNode ci)
+    {
+        var report = Read(Path.Combine(directory, "job.json"));
+        Require(!expected.DirtyWorktree && Equal(report["source"], Node(expected)) && Equal(report["source_after"], Node(expected)), "source mismatch or dirty/incomplete qualification");
+        Require(S(report, "job") == cell.Id && Equal(report["tools"]?["cell"], Node(cell)), "wrong cell identity");
+        foreach (var key in new[] { "GITHUB_RUN_ID", "GITHUB_RUN_ATTEMPT", "GITHUB_REPOSITORY", "GITHUB_EVENT_NAME", "GITHUB_SHA" })
+            Require(Equal(report["ci"]?[key], ci[key]), "source run/attempt mismatch: " + key);
+        foreach (var name in new[] { "sdk", "restore", "build", "test" })
+        {
+            Require(Passed(report["runs"]?[name]), name + " did not pass (compatibility/infrastructure is not a library assertion failure)");
+            var commandDirectory = name == "test" ? Path.Combine(directory, "tests", cell.LibraryTfm) : Path.Combine(directory, name);
+            var execution = Model<ExecutionResult>(Read(Path.Combine(commandDirectory, "execution.json")));
+            Require(execution.Success && execution.ElapsedSeconds >= 0 && double.IsFinite(execution.ElapsedSeconds), name + " execution failed/timed out/interrupted");
+            Require(Equal(Node(execution.Command), report["runs"]![name]!["command"]), name + " command mismatch");
+        }
+        var matrix = TestResults(directory);
+        var result = matrix[cell.LibraryTfm]!;
+        Require(S(result, "status") == "passed", "missing or failed test results");
+        var command = result["execution"]!["command"]!.AsArray().Select(x => x!.ToString()).ToArray();
+        Require(command.Contains("-p:TestHostTfm=" + cell.HostTfm) && command.Contains("Release") && !command.Contains("--filter"), "wrong host command/configuration/scope");
+        Require(Equal(result["execution"], report["runs"]!["test"]), "test execution mismatch");
+        Require(result["case_counts"]?[RuntimeTest]?.GetValue<int>() == 1, "duplicate or missing runtime probe");
+        Require(result["case_counts"]!.AsObject().Sum(p => p.Value!.GetValue<int>()) >= 269, "incomplete full suite");
+        foreach (var (prefix, cases) in new[] { ("QueuedWriteTests.", QueuedCaseCounts), ("PayloadLeaseTests.", LeaseCaseCounts), ("ParserRetentionTests.", RetentionCaseCounts), ("ReconnectTests.", ReconnectCaseCounts) })
+            foreach (var (name, count) in cases)
+                Require(result["case_counts"]?["WebsocketClientLiteTest." + prefix + name]?.GetValue<int>() == count, "missing boundary case: " + prefix + name);
+        ValidateHostIdentity(cell, result["host"], S(result, "host_runtime"), Hash(File.ReadAllBytes(Path.Combine(directory, "expected-library.dll"))));
+        return result.DeepClone();
+    }
+
+    // Shared with full aggregation; manual qualification never satisfies proof/mutation gates.
+    public static JsonObject HostResults(string directory, SourceIdentity source, JsonNode ci, IEnumerable<HostCell> required)
+    {
+        var cells = new JsonObject();
+        var errors = new JsonArray();
+        foreach (var cell in required)
+        {
+            if (cells.ContainsKey(cell.Id)) { errors.Add(cell.Id + ": duplicate cell"); continue; }
+            try { cells[cell.Id] = ValidateHostCell(Path.Combine(directory, cell.Id), cell, source, ci); }
+            catch (Exception e) when (e is not OutOfMemoryException) { errors.Add(cell.Id + ": " + e.Message); cells[cell.Id] = new JsonObject { ["status"] = "failed" }; }
+        }
+        return new JsonObject { ["source"] = Node(source), ["ci"] = ci.DeepClone(), ["cells"] = cells, ["errors"] = errors, ["gate"] = new JsonObject { ["status"] = errors.Count == 0 && cells.Count > 0 ? "passed" : "failed" } };
+    }
+}
diff --git a/tools/Pdd/Processes.cs b/tools/Pdd/Processes.cs
index 2a45e67..5d54a1e 100644
--- a/tools/Pdd/Processes.cs
+++ b/tools/Pdd/Processes.cs
@@ -80,6 +80,9 @@ async Task Pump(StreamReader input, StreamWriter output)
         await stderr.FlushAsync();
         if (combined is not null)
             await combined.FlushAsync();
+        // Close writers before readback: Windows enforces the read handle's sharing mode.
+        await stdout.DisposeAsync();
+        await stderr.DisposeAsync();
         record.ElapsedSeconds = Math.Round(watch.Elapsed.TotalSeconds, 3);
         record.Stdout = Data.Text(Path.Combine(directory, "stdout.log"));
         record.Stderr = Data.Text(Path.Combine(directory, "stderr.log"));
diff --git a/tools/Pdd/Program.cs b/tools/Pdd/Program.cs
index a159c81..7fc346e 100644
--- a/tools/Pdd/Program.cs
+++ b/tools/Pdd/Program.cs
@@ -102,15 +102,20 @@ void Allow(params string[] names)
                 case "controlled-defect":
                     Allow("--output");
                     return await evidence.ControlledDefect(output, cancellation.Token);
+                case "test-host":
+                    Allow("--cell", "--output", "--command-budget");
+                    return await evidence.TestHost(Get("--cell"), output, Number("--command-budget", "600"), cancellation.Token);
                 case "test-target":
                     Allow("--tfm", "--output", "--command-budget");
                     return await evidence.TestTarget(Choice("--tfm", Evidence.Tfms), output, Number("--command-budget", "1800"), cancellation.Token);
                 case "aggregate":
-                    Allow("--output");
+                    Allow("--output", "--host-cells");
                     Directory.CreateDirectory(output);
-                    var receipt = evidence.Aggregate(output, await evidence.Identity());
+                    var receipt = options.ContainsKey("--host-cells")
+                        ? Evidence.HostResults(output, await evidence.Identity(), Data.Node(Evidence.CiIdentity()), Get("--host-cells").Split(',').Select(Evidence.FindHostCell))
+                        : evidence.Aggregate(output, await evidence.Identity());
                     Data.Save(Path.Combine(output, "receipt.json"), receipt);
-                    var summary = Evidence.Summary(receipt);
+                    var summary = options.ContainsKey("--host-cells") ? receipt.ToJsonString(Data.Options) : Evidence.Summary(receipt);
                     File.WriteAllText(Path.Combine(output, "summary.md"), summary);
                     if (Environment.GetEnvironmentVariable("GITHUB_STEP_SUMMARY") is { Length: > 0 } summaryPath)
                         File.AppendAllText(summaryPath, summary);
```


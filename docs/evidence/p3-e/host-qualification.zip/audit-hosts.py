import os,json,pathlib,subprocess,shutil,hashlib,datetime
root=pathlib.Path('/tmp/ws-p3-e')
base=root/'artifacts/remote-acceptance'
summary=[]
for folder in sorted(base.iterdir()):
 if not folder.is_dir():continue
 r=json.loads((folder/'receipt.json').read_text())
 assert r['gate']['status']=='passed',folder
 env=os.environ.copy()
 for k,v in r['ci'].items():
  if v is None:env.pop(k,None)
  else:env[k]=v
 out=root/'artifacts/independent-host-audit'/folder.name
 shutil.copytree(folder,out)
 cells=','.join(r['cells'])
 p=subprocess.run(['dotnet','tools/Pdd/bin/Release/net10.0/Pdd.dll','aggregate','--host-cells',cells,'--output',str(out)],cwd=root,env=env,capture_output=True,text=True)
 (out/'audit-stdout.txt').write_text(p.stdout);(out/'audit-stderr.txt').write_text(p.stderr)
 assert p.returncode==0,(folder,p.stderr,p.stdout[-3000:])
 for c,x in r['cells'].items():
  job=json.loads((folder/c/'job.json').read_text());commands={}
  for stage in ['sdk','restore','build','test']:
   path=folder/c/('tests/'+c.split('-',2)[2] if stage=='test' else stage)/'execution.json'
   commands[stage]=json.loads(path.read_text())['elapsed_seconds']
  summary.append({'artifact':folder.name,'cell':c,'source':r['source']['tested_commit'],'runtime':x['host']['runtime'],'os':x['host']['os_description'],'os_version':x['host']['os_version'],'architecture':x['host']['process_architecture'],'library':x['host']['library_framework'],'assembly_sha256':x['host']['library_sha256'],'assembly_mvid':x['host']['library_mvid'],'assembly_path':x['host']['library_path'],'runner':job['tools']['runner'],'seconds':commands,'cell_wall_seconds':(datetime.datetime.fromisoformat(job['finished_at'])-datetime.datetime.fromisoformat(job['started_at'])).total_seconds(),'test_count':sum(x['case_counts'].values())})
(root/'artifacts/independent-host-audit/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Validated',len(summary),'cells against local current source and original CI run/attempt')

# Contract-change review report

- Target commit: `e810f72d04cf2916f5e3b5125458fc5b6cf4905d`
- Compared head: `5ccbcdbc87f3d132b426fdbed0eb467b91936934`
- Merge base: `e810f72d04cf2916f5e3b5125458fc5b6cf4905d`

**Semantic review required.**

This is a textual comparison, not a proof of equivalence or a weakening detector. Review stronger preconditions, weaker postconditions, helper definitions and expanded trust. Normal PR review must record the accepted decision and reviewed head revision; a committed approval flag is not evidence.

Only committed trees are compared. Uncommitted/untracked files are excluded. The full source diff includes changes outside the summaries. No verifier or tests run here.

## Requirement intent

```diff
diff --git abase/verification/requirements.json bhead/verification/requirements.json
index e6a5b99..e043ad1 100644
--- abase/verification/requirements.json
+++ bhead/verification/requirements.json
@@ -46,5 +46,9 @@
   {
     "id": "WRITE-001",
     "intent": "Selected single-connection schedules serialize frame delegates, reject queued data after terminal notification and settle queued cancellation/abort after controlled owners settle. This is tested C# ownership, not a Dafny proof."
+  },
+  {
+    "id": "LEASE-001",
+    "intent": "Selected sender paths retain each rented frame until its write Task settles and return it exactly once with clearing requested; only initialized bytes reach the delegate. Tested C# ownership, not a Dafny proof."
   }
 ]
```


## Boundary register

```diff
diff --git a/verification/boundaries.json b/verification/boundaries.json
index 2b6fec1..29ed462 100644
--- a/verification/boundaries.json
+++ b/verification/boundaries.json
@@ -187,7 +187,7 @@
     },
     {
       "id": "PAYLOAD-OWNERSHIP",
-      "assumption": "Input arrays and retained segments stay stable during each operation; destination ownership is exclusive and required source/destination non-aliasing holds.",
+      "assumption": "Input arrays and retained segments stay stable during each operation; destination ownership is exclusive and required source/destination non-aliasing holds. SendBinary and binary-list callers keep all borrowed arrays stable until the send Task settles; list snapshotting copies references only. Write delegates relinquish the frame on Task completion; ArrayPool honors rent/return ownership and conditional clearing.",
       "review_anchor": "boundary-payload-ownership",
       "owners": [
         {
@@ -213,7 +213,8 @@
         "REASSEMBLY-003",
         "MASK-001",
         "MASK-002",
-        "MASK-003"
+        "MASK-003",
+        "LEASE-001"
       ],
       "test_obligations": [
         "REASSEMBLY-001-TEST",
@@ -221,7 +222,8 @@
         "REASSEMBLY-003-TEST",
         "MASK-001-TEST",
         "MASK-002-TEST",
-        "MASK-003-TEST"
+        "MASK-003-TEST",
+        "LEASE-001-TEST"
       ],
       "exclusions": [
         "No concurrent caller mutation or proof of C# ownership; aliased retained segments are allowed when stable, but destination aliasing is not."
@@ -296,12 +298,14 @@
       "requirements": [
         "MASK-001",
         "MASK-002",
-        "MASK-003"
+        "MASK-003",
+        "LEASE-001"
       ],
       "test_obligations": [
         "MASK-001-TEST",
         "MASK-002-TEST",
-        "MASK-003-TEST"
+        "MASK-003-TEST",
+        "LEASE-001-TEST"
       ],
       "exclusions": [
         "No proof of the C# adapter, pool lifetime, entropy, encoding or I/O completion."
@@ -318,10 +322,12 @@
         }
       ],
       "requirements": [
-        "WRITE-001"
+        "WRITE-001",
+        "LEASE-001"
       ],
       "test_obligations": [
-        "WRITE-001-TEST"
+        "WRITE-001-TEST",
+        "LEASE-001-TEST"
       ],
       "exclusions": [
         "Abort does not cancel arbitrary in-flight delegates or guarantee delivery. Tests establish selected finite schedules, not unconditional liveness."
```


## Machine-compared external-contract audit

No textual changes.

## Full source diff

````diff
diff --git a/README.md b/README.md
index 9cdd77d..5f392bd 100644
--- a/README.md
+++ b/README.md
@@ -319,6 +319,10 @@ await sender.SendText("End", OpcodeKind.Text, FragmentKind.Last);
 ```
 
 
+`SendBinary` borrows the supplied array until its returned task completes. For a
+binary list send, keep every array unchanged until the whole send completes; the
+list snapshot copies references, not payload bytes. Repeated references to a stable
+array are supported. Concurrent caller mutation is unsupported.
 
 ### TLS/SSL Certificate Validation
 
diff --git a/src/main/WebsocketClientLite/Service/WebsocketSenderHandler.cs b/src/main/WebsocketClientLite/Service/WebsocketSenderHandler.cs
index 845fbfa..d2cb906 100644
--- a/src/main/WebsocketClientLite/Service/WebsocketSenderHandler.cs
+++ b/src/main/WebsocketClientLite/Service/WebsocketSenderHandler.cs
@@ -27,6 +27,7 @@ internal class WebsocketSenderHandler : ISender
     private readonly Action<ConnectionStatus, Exception?> _connectionStatusAction;
     private readonly bool _isExcludingZeroApplicationDataInPong;
     private readonly Func<TimeSpan, CancellationToken, Task> _peerDelay;
+    private readonly ArrayPool<byte> _framePool;
 
     // Data-message ownership spans an entire list; control frames bypass this
     // gate and still serialize at the connection's frame-write gate.
@@ -82,13 +83,15 @@ internal WebsocketSenderHandler(
         Action<ConnectionStatus, Exception?> connectionStatusAction,
         Func<Stream, byte[], int, CancellationToken, Task> writeFunc,
         bool isExcludingZeroApplicationDataInPong,
-        Func<TimeSpan, CancellationToken, Task>? peerDelay = null)
+        Func<TimeSpan, CancellationToken, Task>? peerDelay = null,
+        ArrayPool<byte>? framePool = null)
     {
         _tcpConnectionService = tcpConnectionService;
         _connectionStatusAction = connectionStatusAction;
         _writeFunc = writeFunc;
         _isExcludingZeroApplicationDataInPong = isExcludingZeroApplicationDataInPong;
         _peerDelay = peerDelay ?? Task.Delay;
+        _framePool = framePool ?? ArrayPool<byte>.Shared;
     }
 
     internal string? ExpectedAccept { get; private set; }
@@ -358,7 +361,7 @@ private async ValueTask ComposeFrameAndSendCoreAsync(
         if (opcode == OpcodeKind.Close)
             ProtocolPayload.ValidateClose(content ?? ProtocolPayload.StrictUtf8.GetBytes(text ?? string.Empty));
 
-        byte[] buffer = ArrayPool<byte>.Shared.Rent(totalSize);
+        byte[] buffer = _framePool.Rent(totalSize);
         int written = 0;
         try
         {
@@ -401,9 +404,9 @@ private async ValueTask ComposeFrameAndSendCoreAsync(
         }
         finally
         {
-            // Clear before returning: the buffer held the (masked) outgoing
-            // payload and mask key. Defense-in-depth so a later renter can't read it.
-            ArrayPool<byte>.Shared.Return(buffer, clearArray: true);
+            // Request clearing on return; the pool contract only promises clearing
+            // when it retains the array. The write Task must have relinquished it.
+            _framePool.Return(buffer, clearArray: true);
         }
 
     }
diff --git a/src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs b/src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs
new file mode 100644
index 0000000..ec0a618
--- /dev/null
+++ b/src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs
@@ -0,0 +1,217 @@
+using System;
+using System.Buffers;
+using System.Collections.Generic;
+using System.IO;
+using System.Linq;
+using System.Net.Sockets;
+using System.Reflection;
+using System.Text;
+using System.Threading;
+using System.Threading.Tasks;
+using IWebsocketClientLite;
+using WebsocketClientLite.CustomException;
+using WebsocketClientLite.Model;
+using WebsocketClientLite.Service;
+using Xunit;
+using Xunit.Abstractions;
+
+namespace WebsocketClientLiteTest;
+
+public class PayloadLeaseTests(ITestOutputHelper output)
+{
+    private sealed class Lease(byte[] bytes, int count)
+    {
+        internal readonly byte[] Bytes = bytes;
+        internal readonly int Count = count;
+        internal int Returns;
+        internal bool Clear, Early;
+        internal Task? Write;
+        internal readonly TaskCompletionSource Returned = new(TaskCreationOptions.RunContinuationsAsynchronously);
+    }
+    private sealed class Pool : ArrayPool<byte>
+    {
+        internal readonly List<Lease> Leases = new();
+        public override byte[] Rent(int minimumLength)
+        {
+            var bytes = Enumerable.Repeat((byte)0xcd, minimumLength + 19).ToArray();
+            Leases.Add(new(bytes, minimumLength)); return bytes;
+        }
+        public override void Return(byte[] array, bool clearArray = false)
+        {
+            var lease = Leases.Single(l => ReferenceEquals(l.Bytes, array));
+            lease.Returns++; lease.Clear = clearArray;
+            lease.Early |= lease.Write is { IsCompleted: false };
+            // Poison only while the pool owns the array. Harness readers check ownership first.
+            Array.Fill(array, (byte)0xdd);
+            lease.Returned.TrySetResult();
+        }
+        internal void Complete(int count)
+        {
+            Assert.Equal(count, Leases.Count);
+            foreach (var lease in Leases)
+            {
+                Assert.True(lease.Returns == 1, "Lease not returned exactly once");
+                Assert.True(lease.Clear, "Lease clear-on-return not requested");
+                Assert.False(lease.Early, "Lease returned before write completion");
+            }
+        }
+    }
+    private sealed class Harness(ITestOutputHelper output) : IAsyncDisposable
+    {
+        internal readonly Pool Pool = new();
+        internal readonly TaskCompletionSource Entered = new(TaskCreationOptions.RunContinuationsAsynchronously);
+        internal readonly TaskCompletionSource Completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
+        internal readonly List<Task> Tasks = new();
+        internal readonly List<byte[]> Frames = new();
+        internal readonly TcpConnectionService Tcp = new(() => false, (_, _, _, _) => true,
+            (_, _) => Task.CompletedTask, (_, _) => { }, true, new TcpClient());
+        internal WebsocketSenderHandler Sender = null!;
+        internal int Writes;
+        internal void Initialize()
+        {
+            typeof(TcpConnectionService).GetField("_stream", BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(Tcp, new MemoryStream());
+            Sender = new(Tcp, (_, _) => { }, (_, bytes, count, _) =>
+            {
+                Writes++; Entered.TrySetResult();
+                var lease = Pool.Leases.Single(l => ReferenceEquals(l.Bytes, bytes));
+                Assert.True(lease.Returns == 0, "Lease returned before write completion");
+                Assert.True(count == lease.Count, "Write count includes uninitialized capacity");
+                Assert.All(bytes.Skip(count), b => Assert.Equal(0xcd, b));
+                Frames.Add(bytes.Take(count).ToArray());
+                lease.Write = Writes == 1 ? Completion.Task : Task.CompletedTask;
+                return lease.Write;
+            }, false, framePool: Pool);
+        }
+        internal Task Track(Task task) { Tasks.Add(task); return task; }
+        internal static Task Wait(Task task) => task.WaitAsync(TimeSpan.FromSeconds(15));
+        internal void Held()
+        {
+            Assert.True(Pool.Leases[0].Returns == 0, "Lease returned before write completion");
+            Assert.False(Completion.Task.IsCompleted);
+        }
+        internal void Finish(Exception? error = null)
+        {
+            var lease = Pool.Leases[0];
+            // Last read occurs before the delegate's Task settles, never after Return.
+            Assert.True(lease.Returns == 0, "Lease returned before write completion");
+            Assert.Equal(Frames[0], lease.Bytes.Take(lease.Count).ToArray());
+            if (error is null) Completion.TrySetResult(); else Completion.TrySetException(error);
+        }
+        public async ValueTask DisposeAsync()
+        {
+            Completion.TrySetResult();
+            // Observe expected failures, but a cleanup timeout must fail the test.
+            try { await Wait(Task.WhenAll(Tasks)); }
+            catch (Exception e) when (e is not TimeoutException) { output.WriteLine("Observed cleanup: " + e.Message); }
+            finally { Tcp.Dispose(); output.WriteLine($"Rents={Pool.Leases.Count}, writes={Writes}, returns={string.Join(',', Pool.Leases.Select(l => l.Returns))}"); }
+        }
+    }
+    private static void Wire(byte[] frame, byte first, byte[] payload)
+    {
+        int header = payload.Length < 126 ? 2 : payload.Length <= 65535 ? 4 : 10;
+        var expected = new List<byte> { first, (byte)(128 | (header == 2 ? payload.Length : header == 4 ? 126 : 127)) };
+        if (header > 2) for (int shift = (header - 3) * 8; shift >= 0; shift -= 8) expected.Add((byte)((ulong)payload.Length >> shift));
+        var key = frame.Skip(header).Take(4).ToArray();
+        expected.AddRange(key);
+        expected.AddRange(payload.Select((b, i) => (byte)(b ^ key[i % 4])));
+        Assert.Equal(expected, frame);
+    }
+
+    [Fact]
+    public async Task PausedWriteRetainsLeaseUntilCompletion()
+    {
+        await using var h = new Harness(output); h.Initialize();
+        byte[] input = { 1, 2, 3, 4, 5 };
+        var send = h.Track(h.Sender.SendBinary(input, default));
+        await Harness.Wait(h.Entered.Task);
+        // Propagate delegate assertions before inspecting the pending lease.
+        if (send.IsCompleted) await send;
+        h.Held();
+        Wire(h.Frames[0], 0x82, input); h.Finish(); await Harness.Wait(send);
+        h.Pool.Complete(1); Assert.Equal(new byte[] { 1, 2, 3, 4, 5 }, input);
+    }
+
+    [Theory]
+    [InlineData(0)] [InlineData(125)] [InlineData(126)] [InlineData(65535)] [InlineData(65536)]
+    public async Task InitializedCountMatchesIndependentWireBytes(int length)
+    {
+        await using var h = new Harness(output); h.Initialize(); h.Completion.SetResult();
+        var input = Enumerable.Range(0, length).Select(i => (byte)i).ToArray();
+        var saved = input.ToArray();
+        await Harness.Wait(h.Track(h.Sender.SendBinary(input, default)));
+        Wire(h.Frames[0], 0x82, saved); Assert.Equal(saved, input); h.Pool.Complete(1);
+    }
+
+    [Fact]
+    public async Task StableAliasedListInputsRemainUnchanged()
+    {
+        await using var h = new Harness(output); h.Initialize();
+        byte[] shared = { 7, 8, 9 }; byte[][] inputs = { shared, shared };
+        var send = h.Track(h.Sender.SendBinary(inputs, default));
+        await Harness.Wait(h.Entered.Task); h.Held(); h.Finish(); await Harness.Wait(send);
+        Wire(h.Frames[0], 0x02, new byte[] { 7, 8, 9 }); Wire(h.Frames[1], 0x80, new byte[] { 7, 8, 9 });
+        Assert.Same(inputs[0], inputs[1]); Assert.Equal(new byte[] { 7, 8, 9 }, shared); h.Pool.Complete(2);
+    }
+
+    [Theory]
+    [InlineData(false)] [InlineData(true)]
+    public async Task GateCancellationReturnsOnlyAcquiredLeases(bool frameGate)
+    {
+        await using var h = new Harness(output); h.Initialize(); using var ct = new CancellationTokenSource();
+        var owner = h.Track(frameGate ? h.Sender.SendPing("owner") : h.Sender.SendText("owner"));
+        await Harness.Wait(h.Entered.Task);
+        var queued = h.Track(h.Sender.SendText("queued", ct.Token)); Assert.False(queued.IsCompleted);
+        Assert.Equal(frameGate ? 2 : 1, h.Pool.Leases.Count); ct.Cancel();
+        await Harness.Wait(Assert.ThrowsAnyAsync<Exception>(() => queued));
+        if (frameGate) Assert.Equal(1, h.Pool.Leases[1].Returns);
+        h.Held(); h.Finish(); await Harness.Wait(owner); Assert.Equal(1, h.Writes); h.Pool.Complete(frameGate ? 2 : 1);
+    }
+
+    [Theory]
+    [InlineData(false)] [InlineData(true)]
+    public async Task FailedOrPartialWriteReturnsAfterSettlement(bool partial)
+    {
+        await using var h = new Harness(output); h.Initialize();
+        var send = h.Track(h.Sender.SendText("héllo")); await Harness.Wait(h.Entered.Task); h.Held();
+        Wire(h.Frames[0], 0x81, Encoding.UTF8.GetBytes("héllo"));
+        if (partial) await h.Tcp.ConnectionStream.WriteAsync(h.Frames[0].AsMemory(0, 3));
+        h.Finish(new IOException("controlled write failure"));
+        var error = await Assert.ThrowsAsync<WebsocketClientLiteException>(() => Harness.Wait(send));
+        Assert.IsType<IOException>(error.InnerException); h.Pool.Complete(1);
+    }
+
+    [Fact]
+    public async Task InvalidTextIsRejectedBeforeRent()
+    {
+        await using var h = new Harness(output); h.Initialize();
+        await Assert.ThrowsAsync<EncoderFallbackException>(() => h.Sender.SendText("\ud800"));
+        await Assert.ThrowsAsync<EncoderFallbackException>(() => h.Sender.SendText(new[] { "valid", "\ud800" }));
+        h.Pool.Complete(0); Assert.Equal(0, h.Writes);
+    }
+
+    [Fact]
+    public async Task SuppressedQueuedPongReturnsWithoutDelegateUse()
+    {
+        await using var h = new Harness(output); h.Initialize();
+        var owner = h.Track(h.Sender.SendText("owner")); await Harness.Wait(h.Entered.Task);
+        var pong = h.Track(h.Sender.SendPong(new Dataframe { Payload = new byte[] { 42 } }, default));
+        Assert.False(pong.IsCompleted); Assert.Equal(2, h.Pool.Leases.Count); Assert.All(h.Pool.Leases, l => Assert.Equal(0, l.Returns));
+        h.Sender.NotifyPeerClose(); h.Held(); h.Finish(); await Harness.Wait(Task.WhenAll(owner, pong));
+        Assert.Equal(1, h.Writes); Assert.Null(h.Pool.Leases[1].Write); h.Pool.Complete(2);
+    }
+
+    [Fact]
+    public async Task SendObservationTimeoutRetainsPendingLease()
+    {
+        await using var h = new Harness(output); h.Initialize();
+        using var connection = new WebsocketConnectionHandler(h.Tcp, new WebsocketParserHandler(h.Tcp), (_, _) => { }, (_, _) => h.Sender);
+        var disconnect = h.Track(connection.DisconnectWebsocket(h.Sender));
+        await Harness.Wait(h.Entered.Task); h.Held();
+        await Harness.Wait(disconnect); // Real production five-second Rx observation timeout.
+        h.Held(); Assert.Equal(1, h.Writes);
+        // Observe the original close send through the return checkpoint; disconnect no longer awaits it.
+        h.Finish();
+        await Harness.Wait(h.Pool.Leases[0].Returned.Task);
+        h.Pool.Complete(1);
+    }
+}
diff --git a/tools/Pdd.Tests/LeaseEvidenceTests.cs b/tools/Pdd.Tests/LeaseEvidenceTests.cs
new file mode 100644
index 0000000..c20c98f
--- /dev/null
+++ b/tools/Pdd.Tests/LeaseEvidenceTests.cs
@@ -0,0 +1,77 @@
+using System.Text.Json.Nodes;
+using System.Xml.Linq;
+using Pdd;
+using Xunit;
+
+namespace Pdd.Tests;
+
+public class LeaseEvidenceTests
+{
+    static readonly XNamespace Ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+    const string Hash = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
+    static JsonNode Run(bool pass) => Data.Node(new CommandReceipt { Status = pass ? "passed" : "failed", ExitCode = pass ? 0 : 1, StartedAt = Data.Now(), FinishedAt = Data.Now() });
+    static JsonNode Fixture(string directory)
+    {
+        void Write(string phase, IEnumerable<(string Name, string Outcome, string Message)> rows)
+        {
+            var path = Path.Combine(directory, phase); Directory.CreateDirectory(path);
+            new XDocument(new XElement(Ns + "TestRun", new XElement(Ns + "Results", rows.Select(r =>
+                new XElement(Ns + "UnitTestResult", new XAttribute("testName", r.Name), new XAttribute("outcome", r.Outcome), new XElement(Ns + "Output", r.Message)))))).Save(Path.Combine(path, "results.trx"));
+            Data.Save(Path.Combine(path, "execution.json"), new { exit_code = phase == "baseline" ? 0 : 1, timed_out = false, interrupted = false });
+        }
+        var runtime = ("RecordHostRuntime", "Passed", "PDD_HOST_RUNTIME=.NET 10 fixture");
+        Write("baseline", Evidence.LeaseCaseCounts.SelectMany(c => Enumerable.Range(0, c.Value).Select(i => ("PayloadLeaseTests." + c.Key + "(" + i + ")", "Passed", ""))).Append(runtime));
+        var report = new JsonObject { ["status"] = "passed", ["library_target"] = "net10.0", ["baseline"] = Run(true), ["experiments"] = new JsonArray() };
+        foreach (var c in Evidence.LeaseCases)
+        {
+            Write(c.Id, new[] { (Evidence.LeaseTest, "Failed", c.Assertion), runtime });
+            report["experiments"]!.AsArray().Add(new JsonObject { ["id"] = c.Id, ["status"] = "passed", ["test"] = Evidence.LeaseTest, ["assertion"] = c.Assertion,
+                ["source_hash"] = Hash, ["mutant_hash"] = new string('b', 64), ["before"] = c.Before, ["after"] = c.After, ["run"] = Run(false), ["host_runtime"] = ".NET 10 fixture" });
+        }
+        return report;
+    }
+    [Fact]
+    public void ThreeNamedLeaseAssertionsAreAccepted()
+    {
+        using var tree = new TemporaryTree(); Evidence.ValidateLeaseReport(tree.Path, Fixture(tree.Path), Hash);
+    }
+    [Theory]
+    [InlineData("baseline")]
+    [InlineData("source")]
+    [InlineData("edit")]
+    [InlineData("runtime")]
+    [InlineData("timeout")]
+    [InlineData("cancel")]
+    [InlineData("compile")]
+    [InlineData("survival")]
+    [InlineData("assertion")]
+    [InlineData("missing-case")]
+    [InlineData("missing-mutant")]
+    [InlineData("duplicate-mutant")]
+    public void InvalidEvidenceCannotCountAsDetection(string failure)
+    {
+        using var tree = new TemporaryTree(); var report = Fixture(tree.Path);
+        var entry = report["experiments"]![0]!;
+        var trx = Path.Combine(tree.Path, "early-return/results.trx");
+        switch (failure)
+        {
+            case "baseline": report["baseline"] = Run(false); break;
+            case "source": entry["source_hash"] = "stale"; break;
+            case "edit": entry["after"] = "other"; break;
+            case "runtime": entry["host_runtime"] = "other"; break;
+            case "survival": entry["run"] = Run(true); break;
+            case "compile": File.Delete(trx); break;
+            case "missing-mutant": report["experiments"]!.AsArray().RemoveAt(0); break;
+            case "duplicate-mutant": report["experiments"]![1] = entry.DeepClone(); break;
+            case "assertion": File.WriteAllText(trx, File.ReadAllText(trx).Replace(Evidence.LeaseCases[0].Assertion, "Stuck owner")); break;
+            case "missing-case":
+                var path = Path.Combine(tree.Path, "baseline/results.trx");
+                var xml = XDocument.Load(path); xml.Descendants(Ns + "UnitTestResult").First().Remove(); xml.Save(path); break;
+            default:
+                var execution = Data.Read(Path.Combine(tree.Path, "early-return/execution.json"));
+                execution[failure == "timeout" ? "timed_out" : "interrupted"] = true;
+                Data.Save(Path.Combine(tree.Path, "early-return/execution.json"), execution); break;
+        }
+        Assert.ThrowsAny<Exception>(() => Evidence.ValidateLeaseReport(tree.Path, report, Hash));
+    }
+}
diff --git a/tools/Pdd.Tests/RequirementsTests.cs b/tools/Pdd.Tests/RequirementsTests.cs
index 044dbc9..bef536c 100644
--- a/tools/Pdd.Tests/RequirementsTests.cs
+++ b/tools/Pdd.Tests/RequirementsTests.cs
@@ -42,7 +42,7 @@ public void MalformedManifest(string json)
     public void ValidManifestAndTestedOnlyRequirements()
     {
         var manifest = new Requirements(Root).Validate();
-        Assert.Equal(12, manifest.Requirements.Length);
+        Assert.Equal(13, manifest.Requirements.Length);
         Assert.Empty(manifest.Requirements.Single(r => r.Id == "REASSEMBLY-003").Contracts);
         Assert.Empty(manifest.Requirements[3].Contracts);
         Assert.Empty(manifest.Requirements[4].Contracts);
diff --git a/tools/Pdd/Aggregation.cs b/tools/Pdd/Aggregation.cs
index 4bf1778..f3991a6 100644
--- a/tools/Pdd/Aggregation.cs
+++ b/tools/Pdd/Aggregation.cs
@@ -72,6 +72,11 @@ public static JsonObject TestResults(string directory)
                 var fullName = "WebsocketClientLiteTest.QueuedWriteTests." + name;
                 if (caseCounts.TryGetValue(fullName, out var actualCount) && actualCount != count) tests[fullName] = "failed";
             }
+            foreach (var (name, count) in LeaseCaseCounts)
+            {
+                var fullName = "WebsocketClientLiteTest.PayloadLeaseTests." + name;
+                if (caseCounts.TryGetValue(fullName, out var actualCount) && actualCount != count) tests[fullName] = "failed";
+            }
             var run = Read(Path.Combine(path, "run.json"));
             var valid = Passed(run) && (run["command"]?.AsArray() ?? []).Any(c => c?.ToString() == "-p:LibTfm=" + tfm) && File.Exists(Path.Combine(path, "output.log"));
             matrix[tfm] = new JsonObject { ["status"] = valid && tests.Count > 0 && tests.Values.All(x => x == "passed") && !string.IsNullOrEmpty(runtime) ? "passed" : "failed", ["execution"] = run, ["tests"] = Node(tests), ["host_runtime"] = runtime, ["trx"] = Path.GetRelativePath(directory, files[0]) };
@@ -173,6 +178,22 @@ public JsonObject Aggregate(string directory, SourceIdentity expected)
             }
             catch (Exception e) when (e is not OutOfMemoryException) { queued["status"] = "failed"; errors.Add("Queued experiment: " + e.Message); }
         }
+        var leases = new JsonObject { ["status"] = "not-run" };
+        receipt["leases_experiment"] = leases;
+        if (jobs.ContainsKey("controlled"))
+        {
+            try
+            {
+                Require(Passed(jobs["controlled"]?["runs"]?["leases"]), "unsuccessful leases command");
+                var directoryPath = Path.Combine(directory, "controlled/leases");
+                var report = Read(Path.Combine(directoryPath, "results.json"));
+                Require(Equal(report["source"], Node(expected)) && Equal(report["source_after"], Node(expected)) && Equal(report["ci"], jobs["controlled"]?["ci"]), "leases source/CI mismatch");
+                Require(S(report, "status") == "passed", "Incomplete lease report");
+                ValidateLeaseReport(directoryPath, report, expected.SourceHashes[LeaseSource]!);
+                leases["status"] = "passed"; leases["evidence"] = report;
+            }
+            catch (Exception e) when (e is not OutOfMemoryException) { leases["status"] = "failed"; errors.Add("Lease experiment: " + e.Message); }
+        }
         if (jobs.ContainsKey("stryker"))
         {
             try
@@ -297,6 +318,11 @@ public JsonObject Aggregate(string directory, SourceIdentity expected)
                     item["evidence"]!.AsArray().Add("controlled/queued/results.json");
                     if (S(queued, "status") != "passed") item["status"] = S(queued, "status");
                 }
+                if (o.Id == "LEASE-001-TEST")
+                {
+                    item["evidence"]!.AsArray().Add("controlled/leases/results.json");
+                    if (S(leases, "status") != "passed") item["status"] = S(leases, "status");
+                }
                 if (o.Id == "CLOSE-004-CONTROLLED")
                 {
                     item["evidence"]!.AsArray().Add("controlled/defect/results.json");
diff --git a/tools/Pdd/Evidence.cs b/tools/Pdd/Evidence.cs
index 6657c82..bbf06dc 100644
--- a/tools/Pdd/Evidence.cs
+++ b/tools/Pdd/Evidence.cs
@@ -20,7 +20,7 @@ public async Task<SourceIdentity> Identity()
     }
     public static List<(string Name, string[] Command)> Commands(string job, string output) => job == "stryker" ?
         [("runtime", ["dotnet", "test", Project, "-c", "Release", "-p:LibTfm=net10.0", "--filter", "FullyQualifiedName=" + RuntimeTest, "--logger", "trx;LogFileName=runtime.trx", "--results-directory", Path.Combine(output, "runtime")]), ("stryker", ["./scripts/stryker-close.sh"])] : job == "controlled" ?
-        [("defect", ["./scripts/pdd.sh", "controlled-defect", "--output", Path.Combine(output, "defect")]), ("boundaries", ["./scripts/pdd.sh", "boundary-defects", "--output", Path.Combine(output, "boundaries")]), ("queued", ["./scripts/pdd.sh", "queued-defect", "--output", Path.Combine(output, "queued")])] : job == "protocol" ?
+        [("defect", ["./scripts/pdd.sh", "controlled-defect", "--output", Path.Combine(output, "defect")]), ("boundaries", ["./scripts/pdd.sh", "boundary-defects", "--output", Path.Combine(output, "boundaries")]), ("queued", ["./scripts/pdd.sh", "queued-defect", "--output", Path.Combine(output, "queued")]), ("leases", ["./scripts/pdd.sh", "lease-defects", "--output", Path.Combine(output, "leases")])] : job == "protocol" ?
         [("manifest", ["./scripts/pdd.sh", "validate"]), ("fixtures", ["dotnet", "test", "tools/Pdd.Tests/Pdd.Tests.csproj", "-c", "Release", "--nologo"]), ("proof", ["./scripts/dafny-masking.sh", "--check"]), ("mutations", ["./scripts/pdd.sh", "mutations", "--output", Path.Combine(output, "mutations")])] :
         [("restore", ["dotnet", "restore", "src/main/WebsocketClientLite.sln"]), ("build", ["dotnet", "build", "src/main/WebsocketClientLite.sln", "--configuration", "Release", "--no-restore"]), ("matrix", ["./test-all-tfms.sh", "Release"]), ("coverage-run", ["dotnet", "test", Project, "--configuration", "Release", "--collect:XPlat Code Coverage", "--results-directory", Path.Combine(output, "coverage")]), ("coverage-gate", ["./scripts/check-coverage.sh", Path.Combine(output, "coverage"), "70"])];
     public async Task<CommandReceipt> Execute(string[] command, string output, double budget = 1800, CancellationToken cancellation = default)
diff --git a/tools/Pdd/LeaseDefects.cs b/tools/Pdd/LeaseDefects.cs
new file mode 100644
index 0000000..5981f15
--- /dev/null
+++ b/tools/Pdd/LeaseDefects.cs
@@ -0,0 +1,140 @@
+using System.Text.Json.Nodes;
+using System.Xml.Linq;
+using static Pdd.Data;
+
+namespace Pdd;
+
+public sealed partial class Evidence
+{
+    public const string LeaseSource = "src/main/WebsocketClientLite/Service/WebsocketSenderHandler.cs";
+    public static readonly Dictionary<string, int> LeaseCaseCounts = new()
+    {
+        ["PausedWriteRetainsLeaseUntilCompletion"] = 1,
+        ["InitializedCountMatchesIndependentWireBytes"] = 5,
+        ["StableAliasedListInputsRemainUnchanged"] = 1,
+        ["GateCancellationReturnsOnlyAcquiredLeases"] = 2,
+        ["FailedOrPartialWriteReturnsAfterSettlement"] = 2,
+        ["InvalidTextIsRejectedBeforeRent"] = 1,
+        ["SuppressedQueuedPongReturnsWithoutDelegateUse"] = 1,
+        ["SendObservationTimeoutRetainsPendingLease"] = 1
+    };
+    public static readonly (string Id, string Before, string After, string Assertion)[] LeaseCases =
+    [
+        ("early-return", "await SendFrameCoreAsync(buffer, written, opcode, fragment, ct).ConfigureAwait(false);",
+            "var pending = SendFrameCoreAsync(buffer, written, opcode, fragment, ct);\n            _framePool.Return(buffer, clearArray: true);\n            await pending.ConfigureAwait(false);", "Lease returned before write completion"),
+        ("missing-return", "_framePool.Return(buffer, clearArray: true);", ";", "Lease not returned exactly once"),
+        ("wrong-count", "await SendFrameCoreAsync(buffer, written, opcode, fragment, ct).ConfigureAwait(false);",
+            "await SendFrameCoreAsync(buffer, buffer.Length, opcode, fragment, ct).ConfigureAwait(false);", "Write count includes uninitialized capacity")
+    ];
+    public const string LeaseTest = "PausedWriteRetainsLeaseUntilCompletion";
+    public async Task<int> LeaseDefects(string output, CancellationToken cancellation)
+    {
+        Fresh(output);
+        var report = new JsonObject { ["status"] = "failed", ["source"] = Node(await Identity()), ["ci"] = Node(CiIdentity()),
+            ["started_at"] = Now(), ["library_target"] = "net10.0", ["experiments"] = new JsonArray() };
+        using var copy = new TemporaryTree();
+        try
+        {
+            // Restrict to repository inputs; unrelated untracked dumps are never copied/read.
+            var paths = (await ContractReport.Git(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard",
+                "src", "verification", "tools", "scripts", ".config", "global.json", "Directory.Build.props", "Directory.Build.targets", "NuGet.config")).Split('\0', StringSplitOptions.RemoveEmptyEntries);
+            foreach (var path in paths.Distinct())
+            {
+                var target = Path.Combine(copy.Path, path);
+                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
+                File.Copy(Path.Combine(root, path), target);
+            }
+            var runner = new Evidence(copy.Path);
+            async Task<CommandReceipt> Run(string name, string filter) => await runner.Execute(
+                ["dotnet", "test", Project, "-c", "Release", "-p:LibTfm=net10.0", "--filter", filter + "|FullyQualifiedName=" + RuntimeTest,
+                    "--logger", "trx;LogFileName=results.trx", "--results-directory", Path.Combine(output, name)], Path.Combine(output, name), 180, cancellation);
+            report["baseline"] = Node(await Run("baseline", "FullyQualifiedName~WebsocketClientLiteTest.PayloadLeaseTests"));
+            Require(Passed(report["baseline"]), "Lease baseline failed");
+            var file = Path.Combine(copy.Path, LeaseSource);
+            var original = Text(file);
+            foreach (var c in LeaseCases)
+            {
+                var name = c.Id;
+                var index = original.IndexOf(c.Before, StringComparison.Ordinal);
+                Require(index >= 0 && original.IndexOf(c.Before, index + 1, StringComparison.Ordinal) < 0, "Ambiguous/missing lease edit");
+                File.WriteAllText(file, original[..index] + c.After + original[(index + c.Before.Length)..]);
+                var run = await Run(name, "FullyQualifiedName=WebsocketClientLiteTest.PayloadLeaseTests." + LeaseTest);
+                var experiment = new JsonObject { ["id"] = name, ["status"] = "failed", ["test"] = LeaseTest, ["assertion"] = c.Assertion,
+                    ["source_hash"] = Hash(System.Text.Encoding.UTF8.GetBytes(original)), ["mutant_hash"] = Hash(File.ReadAllBytes(file)),
+                    ["before"] = c.Before, ["after"] = c.After, ["run"] = Node(run) };
+                report["experiments"]!.AsArray().Add(experiment);
+                experiment["host_runtime"] = ValidateLeaseResult(Path.Combine(output, name), Node(run), c.Assertion);
+                experiment["status"] = "passed";
+                File.WriteAllText(file, original);
+            }
+            report["status"] = "passed";
+            ValidateLeaseReport(output, report, Hash(System.Text.Encoding.UTF8.GetBytes(original)));
+        }
+        catch (Exception e) when (e is not OutOfMemoryException) { report["status"] = "failed"; report["error"] = e.Message; }
+        finally { report["finished_at"] = Now(); report["source_after"] = Node(await Identity()); Save(Path.Combine(output, "results.json"), report); }
+        return S(report, "status") == "passed" ? 0 : 1;
+    }
+
+    public static void ValidateLeaseReport(string directory, JsonNode report, string sourceHash)
+    {
+        Require(S(report, "status") == "passed" && S(report, "library_target") == "net10.0" && Passed(report["baseline"]), "Incomplete lease baseline/report");
+        XNamespace ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+        var baseline = XDocument.Load(Path.Combine(directory, "baseline/results.trx")).Descendants(ns + "UnitTestResult").ToArray();
+        Require(baseline.Length == 15 && baseline.All(r => (string?)r.Attribute("outcome") == "Passed"), "Incomplete lease baseline cases");
+        foreach (var (test, count) in LeaseCaseCounts)
+            Require(baseline.Count(r => ((string?)r.Attribute("testName"))?.Contains("PayloadLeaseTests." + test, StringComparison.Ordinal) == true) == count, "Missing named lease baseline case");
+        ValidateLeaseExecution(Path.Combine(directory, "baseline"), 0);
+        var baselineRuntime = baseline.Single(r => ((string?)r.Attribute("testName"))?.EndsWith("RecordHostRuntime", StringComparison.Ordinal) == true).Value;
+        var entries = report["experiments"]!.AsArray();
+        Require(entries.Count == 3, "Missing lease experiments or repetitions");
+        foreach (var c in LeaseCases)
+        {
+            var name = c.Id;
+            var e = entries.Single(e => S(e, "id") == name)!;
+            Require(S(e, "status") == "passed" && S(e, "source_hash") == sourceHash && S(e, "mutant_hash").Length == 64 && S(e, "mutant_hash") != sourceHash, "Lease mutation identity mismatch");
+            Require(S(e, "before") == c.Before && S(e, "after") == c.After && S(e, "test") == LeaseTest && S(e, "assertion") == c.Assertion, "Lease experiment contract mismatch");
+            var runtime = ValidateLeaseResult(Path.Combine(directory, name), e["run"]!, c.Assertion);
+            Require(S(e, "host_runtime") == runtime && baselineRuntime.Contains("PDD_HOST_RUNTIME=" + runtime, StringComparison.Ordinal), "Lease runtime mismatch");
+        }
+    }
+
+    private static void ValidateLeaseExecution(string directory, int code)
+    {
+        var e = Read(Path.Combine(directory, "execution.json"));
+        Require(e["timed_out"]?.GetValue<bool>() == false && e["interrupted"]?.GetValue<bool>() == false && e["launch_error"] is null && e["exit_code"]?.ToString() == code.ToString(), "Invalid lease execution");
+    }
+    private static string ValidateLeaseResult(string directory, JsonNode run, string assertion)
+    {
+        ValidateLeaseExecution(directory, 1);
+        return ValidateBoundaryResult(Path.Combine(directory, "results.trx"), run, LeaseTest, assertion, 1);
+    }
+    // Manual smoke probe; deliberately not repeated fifty times in every PR job.
+    public async Task<int> LeaseProbe(string output, CancellationToken cancellation)
+    {
+        Fresh(output);
+        var report = new System.Text.Json.Nodes.JsonObject { ["status"] = "failed", ["source"] = Node(await Identity()),
+            ["ci"] = Node(CiIdentity()), ["started_at"] = Now(), ["runs"] = new System.Text.Json.Nodes.JsonArray() };
+        try
+        {
+            for (int i = 0; i < 50; i++)
+            {
+                var path = Path.Combine(output, i.ToString("D2"));
+                var run = await Execute(["dotnet", "test", Project, "-c", "Release", "-p:LibTfm=net10.0",
+                    "--filter", "FullyQualifiedName~WebsocketClientLiteTest.PayloadLeaseTests|FullyQualifiedName=" + RuntimeTest,
+                    "--logger", "trx;LogFileName=results.trx", "--results-directory", path], path, 180, cancellation);
+                report["runs"]!.AsArray().Add(Node(run));
+                Require(Passed(Node(run)), "Lease probe failed at repetition " + i);
+                XNamespace ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";
+                var rows = XDocument.Load(Path.Combine(path, "results.trx")).Descendants(ns + "UnitTestResult").ToArray();
+                Require(rows.Length == 15 && rows.All(r => (string?)r.Attribute("outcome") == "Passed"), "Incomplete lease probe cases");
+                foreach (var (name, count) in LeaseCaseCounts)
+                    Require(rows.Count(r => ((string?)r.Attribute("testName"))?.Contains("PayloadLeaseTests." + name, StringComparison.Ordinal) == true) == count, "Missing lease probe schedule");
+                Console.WriteLine($"Lease probe {i + 1}/50 passed");
+            }
+            report["status"] = "passed";
+        }
+        catch (Exception e) when (e is not OutOfMemoryException) { report["status"] = "failed"; report["error"] = e.Message; }
+        finally { report["source_after"] = Node(await Identity()); report["finished_at"] = Now(); Save(Path.Combine(output, "results.json"), report); }
+        return S(report, "status") == "passed" ? 0 : 1;
+    }
+}
diff --git a/tools/Pdd/Program.cs b/tools/Pdd/Program.cs
index 4d71e11..f370c57 100644
--- a/tools/Pdd/Program.cs
+++ b/tools/Pdd/Program.cs
@@ -23,7 +23,7 @@ public static async Task<int> Main(string[] args)
         try
         {
             if (args.Length == 0)
-                throw new ArgumentException("Usage: pdd <validate|contract-report|mutations|capture|test-target|aggregate|controlled-defect|boundary-defects|queued-defect|queued-probe|stryker-triage|normalize-generated> [options]");
+                throw new ArgumentException("Usage: pdd <validate|contract-report|mutations|capture|test-target|aggregate|controlled-defect|boundary-defects|queued-defect|queued-probe|lease-defects|lease-probe|stryker-triage|normalize-generated> [options]");
             var root = FindRoot();
             var options = new Dictionary<string, string>();
             var positionals = new List<string>();
@@ -81,6 +81,12 @@ void Allow(params string[] names)
                 case "boundary-defects":
                     Allow("--output");
                     return await evidence.BoundaryDefects(output, cancellation.Token);
+                case "lease-defects":
+                    Allow("--output");
+                    return await evidence.LeaseDefects(output, cancellation.Token);
+                case "lease-probe":
+                    Allow("--output");
+                    return await evidence.LeaseProbe(output, cancellation.Token);
                 case "queued-probe":
                     Allow("--output");
                     return await evidence.QueuedProbe(output, cancellation.Token);
diff --git a/tools/Pdd/README.md b/tools/Pdd/README.md
index 3d71ddc..8d85faf 100644
--- a/tools/Pdd/README.md
+++ b/tools/Pdd/README.md
@@ -167,3 +167,9 @@ P3-A adds `queued-defect --output <fresh-directory>` to controlled capture and
 The isolated capacity-two frame gate must trigger the named overlap assertion;
 source/CI identities, exact edit, runtime and execution/TRX are checked. No G gate
 or budget changes. See [queued ownership](../../verification/queued-write-ownership.md).
+
+P3-B adds `lease-defects --output <fresh-directory>` to controlled capture and
+`lease-probe --output <fresh-directory>` for 50 manual repetitions. The three
+isolated early-return, missing-return and wrong-count edits must fail their named
+assertions; aggregate checks exact edits/source, all cases, execution and runtime.
+See [sender leases](../../verification/payload-lease-ownership.md).
diff --git a/verification/boundaries.json b/verification/boundaries.json
index 2b6fec1..29ed462 100644
--- a/verification/boundaries.json
+++ b/verification/boundaries.json
@@ -187,7 +187,7 @@
     },
     {
       "id": "PAYLOAD-OWNERSHIP",
-      "assumption": "Input arrays and retained segments stay stable during each operation; destination ownership is exclusive and required source/destination non-aliasing holds.",
+      "assumption": "Input arrays and retained segments stay stable during each operation; destination ownership is exclusive and required source/destination non-aliasing holds. SendBinary and binary-list callers keep all borrowed arrays stable until the send Task settles; list snapshotting copies references only. Write delegates relinquish the frame on Task completion; ArrayPool honors rent/return ownership and conditional clearing.",
       "review_anchor": "boundary-payload-ownership",
       "owners": [
         {
@@ -213,7 +213,8 @@
         "REASSEMBLY-003",
         "MASK-001",
         "MASK-002",
-        "MASK-003"
+        "MASK-003",
+        "LEASE-001"
       ],
       "test_obligations": [
         "REASSEMBLY-001-TEST",
@@ -221,7 +222,8 @@
         "REASSEMBLY-003-TEST",
         "MASK-001-TEST",
         "MASK-002-TEST",
-        "MASK-003-TEST"
+        "MASK-003-TEST",
+        "LEASE-001-TEST"
       ],
       "exclusions": [
         "No concurrent caller mutation or proof of C# ownership; aliased retained segments are allowed when stable, but destination aliasing is not."
@@ -296,12 +298,14 @@
       "requirements": [
         "MASK-001",
         "MASK-002",
-        "MASK-003"
+        "MASK-003",
+        "LEASE-001"
       ],
       "test_obligations": [
         "MASK-001-TEST",
         "MASK-002-TEST",
-        "MASK-003-TEST"
+        "MASK-003-TEST",
+        "LEASE-001-TEST"
       ],
       "exclusions": [
         "No proof of the C# adapter, pool lifetime, entropy, encoding or I/O completion."
@@ -318,10 +322,12 @@
         }
       ],
       "requirements": [
-        "WRITE-001"
+        "WRITE-001",
+        "LEASE-001"
       ],
       "test_obligations": [
-        "WRITE-001-TEST"
+        "WRITE-001-TEST",
+        "LEASE-001-TEST"
       ],
       "exclusions": [
         "Abort does not cancel arbitrary in-flight delegates or guarantee delivery. Tests establish selected finite schedules, not unconditional liveness."
diff --git a/verification/close-intent-review.md b/verification/close-intent-review.md
index ccff071..1af2b40 100644
--- a/verification/close-intent-review.md
+++ b/verification/close-intent-review.md
@@ -279,3 +279,13 @@ An in-flight stream operation must settle or be explicitly released in a test.
 After abort, the semaphore remains alive for queued tasks to acquire and reject;
 its managed state is reclaimed by GC. No AvailableWaitHandle is requested. No FIFO
 or unconditional completion is asserted. Human semantic review remains not-run.
+
+### LEASE-001
+
+Review the finite schedules and trusted contracts in [payload lease ownership](payload-lease-ownership.md).
+The internal pool defaults to Shared; no public copying or caller-mutation policy
+changes. Safety requires the lease through delegate completion, exactly one return
+with clearing requested, and initialized count. Observation timeout does not end
+write ownership. Pool compliance, relinquishment on Task completion, stable caller
+inputs and external progress remain assumptions. Machine receipts cannot record
+human acceptance; review the PR source revision separately.
diff --git a/verification/payload-lease-ownership.md b/verification/payload-lease-ownership.md
new file mode 100644
index 0000000..baf7b64
--- /dev/null
+++ b/verification/payload-lease-ownership.md
@@ -0,0 +1,59 @@
+# P3-B: sender frame leases
+
+Based on release `e810f72` containing P3-A PR #114, whose final reviewed delivery
+and owner-authorized merge are recorded in that PR. The specification is P3-B in
+`docs/pdd-phase-3-plan.md` at planning commit `78966de` (still on its planning branch).
+G's accepted post-merge baseline remains run 42408136157, artifact 13588159091;
+see the retained receipt and exact hashes in `docs/p3-a-validation.md`.
+
+The sender rents before frame admission and owns storage until the awaited send
+settles. A waiting message has no lease yet. A cancelled frame waiter returns its
+lease without invoking the writer. A suppressed queued Pong likewise returns
+without writer use. A write failure, including after a prefix is transferred,
+releases its lease only after the delegate Task settles. Invalid UTF-16 is rejected
+by strict byte counting before rent, including validation of all text-list entries.
+The production five-second Close observation timeout ends observation only: the
+original delegate deliberately stays pending, and its lease remains held until
+explicit settlement in the harness. Cleanup releases and drains controlled work;
+fifteen-second waits are diagnostics, not public deadlines.
+
+`PayloadLeaseTests` uses the existing write delegate plus an internal optional
+`ArrayPool<byte>` constructor argument defaulting to Shared. A delegate alone
+cannot reliably observe Shared's Return or reuse. The deterministic pool allocates
+19 extra sentinel bytes, records identities/counts/clear requests and poisons only
+when ownership is returned. Every harness read checks ownership first; last reads
+occur before completing the write Task. Success, failure, cancellation, suppression
+and timeout check one Return per successful Rent. Wire expectations independently
+encode headers and scalar XOR against the generated random key; sizes 0, 125, 126,
+65535 and 65536 cross header boundaries. F's fixed masking vectors and invalid
+Decode adapter cases remain required and unchanged.
+
+Binary arrays are borrowed through completion of SendBinary, including every array
+in a binary list. Snapshotting the enumerable captures references, not bytes.
+Repeated references to stable input arrays are supported and tested; the caller's
+bytes are unchanged. Concurrent caller mutation remains unsupported. No copy policy,
+public ownership API, queue memory limit or new dependency is introduced. Invalid
+pool behavior (such as renting caller-owned storage) is not a supported aliasing
+case. Return requests clearing; the ArrayPool contract only promises clearing if
+the pool retains the array, not universal zeroization.
+
+Safety assumes pool contract compliance and that a stream delegate stops accessing
+the array when its returned Task settles. Progress additionally assumes runnable
+continuations, returning callbacks/cleanup and eventual external settlement. These
+are tested C# boundaries, not proofs of the allocator, runtime, Rx, I/O, arbitrary
+schedules or wire delivery. The production change adds one pool reference and uses
+virtual Rent/Return on that reference; allocation/performance impact is unbenchmarked.
+
+`lease-defects` executes a clean baseline then three independent exact edits in
+temporary copies: Return after starting but before awaiting the writer, omitted
+Return, and capacity in place of initialized count. Each must fail its named
+lease/count assertion, with exit 1 and matching runtime/TRX/execution/source records.
+Timeout, compilation, missing evidence and unrelated failures cannot count as
+assertion detection. Controlled capture and aggregate require these experiments;
+`LEASE-001-TEST` also requires every theory row on five library targets. No G/A gate
+or budget changes. `lease-probe` repeats all 14 cases plus runtime in 50 processes,
+including the real five-second timeout; it is manual, not a per-PR repeat cost.
+
+Human semantic acceptance belongs to revision-specific PR review. Revisit on pool,
+write completion or copying-policy changes and when recurring CI exceeds the plan's
+provisional cost allowances. No later Phase 3 increment is included.
diff --git a/verification/requirements.json b/verification/requirements.json
index ea88984..956fd82 100644
--- a/verification/requirements.json
+++ b/verification/requirements.json
@@ -1036,6 +1036,81 @@
         "No FIFO, starvation-freedom, arbitrary interleaving, network delivery or wall-clock completion guarantee.",
         "In-flight delegates and callbacks must settle; synchronous abort can interrupt a write already admitted. Buffer lease instrumentation belongs to P3-B."
       ]
+    },
+    {
+      "id": "LEASE-001",
+      "intent": "Selected sender paths retain each rented frame until its write Task settles and return it exactly once with clearing requested; only initialized bytes reach the delegate. Tested C# ownership, not a Dafny proof.",
+      "origin": [
+        "Library policy: P3-B sender buffer lifetime"
+      ],
+      "contracts": [],
+      "production_paths": [
+        {
+          "reference": {
+            "file": "src/main/WebsocketClientLite/Service/WebsocketSenderHandler.cs",
+            "symbol": "WebsocketClientLite.Service.WebsocketSenderHandler.ComposeFrameAndSendCoreAsync"
+          },
+          "responsibility": "Own rented frame through queued or in-flight send and return in finally."
+        }
+      ],
+      "assumptions": [
+        "PAYLOAD-OWNERSHIP",
+        "MASK-ADAPTER",
+        "WRITE-PROGRESS"
+      ],
+      "obligations": [
+        {
+          "id": "LEASE-001-TEST",
+          "kind": "test",
+          "delivery": "existing",
+          "description": "Require named schedules on five targets and three isolated assertion detections; pool identity/count/clearing and independent wire bytes are tested.",
+          "references": [
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.PausedWriteRetainsLeaseUntilCompletion"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.InitializedCountMatchesIndependentWireBytes"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.StableAliasedListInputsRemainUnchanged"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.GateCancellationReturnsOnlyAcquiredLeases"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.FailedOrPartialWriteReturnsAfterSettlement"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.InvalidTextIsRejectedBeforeRent"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.SuppressedQueuedPongReturnsWithoutDelegateUse"
+            },
+            {
+              "file": "src/main/WebsocketClientLiteTest/PayloadLeaseTests.cs",
+              "symbol": "WebsocketClientLiteTest.PayloadLeaseTests.SendObservationTimeoutRetainsPendingLease"
+            }
+          ]
+        },
+        {
+          "id": "LEASE-001-REVIEW",
+          "kind": "review",
+          "delivery": "existing",
+          "description": "Review ownership, default-preserving pool seam, caller borrowing and trusted delegate completion against the PR revision. Machine evidence is not acceptance.",
+          "references": []
+        }
+      ],
+      "exclusions": [
+        "No concurrent caller mutation safety, universal zeroization, delivery or arbitrary schedule claim.",
+        "Pool and stream contracts, scheduling progress and finite callbacks remain trusted; delegates must not use buffers after Task completion."
+      ]
     }
   ],
   "boundaries_file": "verification/boundaries.json"
diff --git a/verification/requirements.schema.json b/verification/requirements.schema.json
index c6acdc8..0b69938 100644
--- a/verification/requirements.schema.json
+++ b/verification/requirements.schema.json
@@ -13,7 +13,7 @@
         "properties": {
           "id": {
             "type": "string",
-            "pattern": "^(CLOSE|REASSEMBLY|MASK|WRITE)-[0-9]{3}$"
+            "pattern": "^(CLOSE|REASSEMBLY|MASK|WRITE|LEASE)-[0-9]{3}$"
           },
           "intent": {
             "type": "string",
````


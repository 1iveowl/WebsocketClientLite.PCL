# PDD verification receipt

Machine evidence gate: **failed**

Machine obligations, controlled ordering experiment, recorded Stryker dispositions and existing CI gates; PR review remains separate and unsatisfied.

Tested commit: `f3d5ed4d336c2c7f1df88643fb100db76acb0cc4`
PR source head: ``

Five library builds use the actual hosts recorded below; they are not five independently tested runtimes.

- netstandard2.0: passed; host: .NET 10.0.14
- netstandard2.1: passed; host: .NET 10.0.14
- net8.0: passed; host: .NET 10.0.14
- net9.0: passed; host: .NET 10.0.14
- net10.0: passed; host: .NET 10.0.14

| Obligation | Status |
| --- | --- |
| CLOSE-001-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| CLOSE-001-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| CLOSE-001-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |
| CLOSE-002-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| CLOSE-002-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| CLOSE-002-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |
| CLOSE-003-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| CLOSE-003-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| CLOSE-003-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |
| CLOSE-004-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| CLOSE-004-CONTROLLED | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx), [controlled/defect/results.json](controlled/defect/results.json) |
| CLOSE-005-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| CLOSE-005-CONTROLLED | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| REASSEMBLY-001-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| REASSEMBLY-001-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| REASSEMBLY-001-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |
| REASSEMBLY-002-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| REASSEMBLY-002-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| REASSEMBLY-002-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |
| REASSEMBLY-003-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| MASK-001-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| MASK-001-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| MASK-001-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |
| MASK-002-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| MASK-002-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| MASK-002-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |
| MASK-003-PROOF | passed [protocol/proof.log](protocol/proof.log) |
| MASK-003-TEST | passed [tests/tests/netstandard2.0/results.trx](tests/tests/netstandard2.0/results.trx), [tests/tests/netstandard2.1/results.trx](tests/tests/netstandard2.1/results.trx), [tests/tests/net8.0/results.trx](tests/tests/net8.0/results.trx), [tests/tests/net9.0/results.trx](tests/tests/net9.0/results.trx), [tests/tests/net10.0/results.trx](tests/tests/net10.0/results.trx) |
| MASK-003-MUTATION | passed [protocol/mutations/results.json](protocol/mutations/results.json) |

Review evidence is separate and not-run; no requirement is claimed satisfied without it.
Stryker: failed; controlled ordering experiment: passed.

Receipts are traceability records, not signed attestations.

- Stryker: Untriaged Stryker outcome: 590 Timeout 2948746ba70d8f2b5bac5cdec0abba0701a3f0e7d3d648082ffffedb6253dd93
